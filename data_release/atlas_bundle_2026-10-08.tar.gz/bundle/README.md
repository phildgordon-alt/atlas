# Atlas open-data bundle (draft, 2026-10-08)

Certificates, replay code and the Lean formalization for the Atlas results: zero-list-free certification that the zeros of ζ and of
several degree-2 L-functions in given height ranges lie on the critical line (and are simple), via the explicit formula with sech
kernels, rigorously discovered sign changes of Z(t), and a linear-programming dual certificate checked in Arb interval arithmetic.

Everything here is a byte-identical copy of the working tree (`CODE_PROVENANCE.tsv`: original path, bundle path, sha256, MATCH for
every one of the 11,683 copied files), plus a few bundle-only wrappers in `tools/`, this README, `quick_verify.sh`, `requirements.txt`
and `SHA256SUMS`. No copied file was edited; hard-coded host paths are handled by the wrappers (see "Paths").

## Layout

```
README.md  quick_verify.sh  requirements.txt  SHA256SUMS  CODE_PROVENANCE.tsv
tools/                 bundle-only wrappers (replay_v4.py, replay_deg2.sh, run_crosscheck.py, export_certs_bundle.py, boot/sitecustomize.py)
external/              exact_tiling_check.py (sha 0868990e…, pinned by atlas_v4) + SLIVER_CHECK.md (from the 2026-10-04 audit dir)
atlas_mark2/           mirror of the original tree (code AND run data at their original relative paths)
  frequency_localized_sweep.py, precision_and_l70_analysis.py, frequency_localized_frozen_carriers.json, requirements.lock
  diagnostic/
    certify_sech_interferometer.py, integer_mechanism.py      sech-row engine E_comp, far bound, Trudgian count (trusted, see below)
    CORRECTIONS_2026-10-06.md, SCALING_FINDINGS.md, zsign/THEORY_ZSIGN.md
    usefulness_tests/  T1/T2/T4 results + PREDICTIONS/AMENDMENT_1; argprinciple/zeta_argprinciple.py (pinned counter, sha cc5079d8…)
    atlas_v4/          code, docs, V4_FREEZE.sha256, controls/, runs/ (acceptance V1–V4, lehmer_full_pair, T4 runs)
    new_territory/     TARGETS, PRIOR_VERIFICATION, CONTIG_RESULTS, PREDICTIONS*
      deg2/            L(s,11.a), L(s,23.1.b.a): code, THEORY/RESULTS, runs/ (val, targets, contig/ 30 chunks [0,300] + UNION_0_300.json, nc/)
      crosscheck_11a/  argument-principle count of Λ(s,11.a) on [0,300]: code, runs/full (result.json, compare.json, patches.jsonl), controls
      ec37a/           37.a1: code, a_p table, logs (central, union), runs/ (val_0_10, chunks/, nc/)
      ec389a/          389.a1: code, a_p table, logs (modsym/ certificate, central, argcount, union), runs/ (val_0_10, chunks/, nc/)
      tollis/          ζ_K/ζ for all 25 complex cubic fields of Tollis's Table 6.2: code, types/ (25 verified tables), logs,
                       runs/{core,contig,val,nc}; ADDENDUM 2 launcher fields_ext2.py + run_ext2.py (+ TYPES_SHA256_ADDENDUM2.json,
                       run_targets_ext2.sh, post_field_ext2.sh), PREDICTIONS_ADDENDUM2.md, PLAN_ADDENDUM2.txt
lean/                  the Lean 4 + Mathlib project (formal/ without .lake): Atlas/, AtlasAudit/, audit/ (incl. exported data/*.txt), export/, scripts/
```

## Claims and where their certificates are

All claims are rigorous given the trust base below. "Simple" uses **Lemma 2** (parity of sign changes ⇒ simplicity), which is
machine-checked in Lean as logic (`Cert.lemma2_parity`) but has not had an independent expert review; where a claim (B) is reported it
holds without Lemma 2. Novelty statements are "not found in the published literature or LMFDB as of October 2026, to our knowledge"
(moderate confidence, pending expert confirmation; see `atlas_mark2/diagnostic/new_territory/PRIOR_VERIFICATION.md`).

**Endpoint caveat (binary64).** Every target is exactly tiled for its endpoints *as stored*, i.e. binary64 values. When a stated decimal
endpoint is not dyadic (e.g. 7005.06, 6820050.98, 91.81), the claim holds for [fl(lo), fl(hi)]; the exact decimal interval can miss a
sub-ulp sliver (6e−16 … 4.5e−10) at an end (`lean/audit/RESULTS.md`, finding 1). Every contiguous headline claim has integer endpoints
and is unaffected.

| # | claim | data (under `atlas_mark2/diagnostic/`) |
|---|---|---|
| Z1 | ζ: every zero with height in [9000, 9010] is on the line and simple (A); simple also without Lemma 2 (B). 10 main + 11 S-layer certificates | `atlas_v4/runs/w9000.00/v1_9000` |
| Z2 | ζ: **Lehmer's pair** — every zero with height in [7005.0, fl(7005.2)] (both 7005.0629 and 7005.1006) on the line and simple, (A) and (B). The upper end 7005.2 is not dyadic: like the other decimal targets, the claim is for the stored binary64 endpoint (a fresh Lean audit of this run, made for this bundle: 0 violations, binary64 target covered, decimal version not) — immaterial for the pair, which lies 0.1 inside | `atlas_v4/runs/w7000.00/lehmer_full_pair` |
| Z2′ | the pre-registered acceptance target [7005.06, 7005.10] contains only the FIRST zero of Lehmer's pair (7005.0629); the second (7005.1006) lies just outside. Do not cite it as "Lehmer's pair" | `atlas_v4/runs/w7000.00/lehmer` |
| Z3 | ζ: [7002.48, 7002.49] (zero-free control, closed); [663318.4, 663318.6] (closest pair in Odlyzko's first 2·10⁶ zeros); Rosser target [6820050.98, 6820052.15]: all on the line and simple, (A) and (B) | `w7000.00/c7002`, `w663310.00/t2_663318`, `w6820046.00/rosser` |
| Z4 | ζ, T4 height scaling: [T, T+2] for T = 1e4, 1e5, 1e6, 1e7 closed, (A) and (B), 3.8–6.3 s in process | `atlas_v4/runs/w1*/t4v4_*` |
| E1 | L(s, 11.a): every zero with 0 ≤ t ≤ 300 is on the line and simple; 388 sign changes; 30 chunks × 20 certificates | `new_territory/deg2/runs/contig/c_*` |
| E1x | independent cross-check: argument principle (no explicit formula, no sign-change credit, no Lemma 2) gives exactly 388 zeros of Λ(s,11.a) for 0 ≤ t ≤ 300, all in N = 1 boxes symmetric about the line ⇒ on the line and simple | `new_territory/crosscheck_11a/runs/full/{result,compare}.json` |
| E2 | L(s, 37.a1) (rank 1): every zero with \|Im s\| ≤ 200 is on the line and simple; the central zero is simple (Λ′(1) ≠ 0, `central.py`) | `new_territory/ec37a/runs/{val_0_10,chunks/}` |
| E3 | L(s, 389.a1) (rank 2): every zero with \|Im s\| ≤ 200 on the line; all simple except s = 1 (analytic 1/2), multiplicity exactly 2: L(E,1) = 0 by an exact modular-symbol certificate, Λ″(1) ≠ 0 in Arb; cross-checks X1 (certificate) and X2 (argument principle, count 2 for \|t\| ≤ 2.5) | `new_territory/ec389a/runs/chunks/`, `logs/modsym/389.a1.json`, `logs/central_final.out`, `logs/argcount_*.json` |
| E4 | L(s, 23.1.b.a): [93.5, 104] (deg2 η-product run), and [0, 18] validation | `new_territory/deg2/runs/{t_23_93.5_104,val_23_0_18}` |
| K1 | ζ_K/ζ for the complex cubic fields d_K = −23, −31, −44, −59, −76, −83, −87, −104, −107, −108 (Tollis 1997, Table 6.2): every zero with \|Im s\| ≤ 110 on the line and simple (−23: ≤ 200); with Platt–Trudgian (RH for ζ to 3·10¹²), **GRH for ζ_K to \|Im s\| ≤ 110 (−23: 200)**, independently of Tollis. Simplicity of ζ_K's zeros is not claimed | `new_territory/tollis/runs/{core,contig,val}/K*` |
| K2 | the 15 remaining fields of Table 6.2, d_K = −116, −135, −139, −140, −152, −172, −175, −199, −200, −204, −211, −212, −216, −231, −239 (tollis/RESULTS.md ADDENDUM 2; pre-registered in PREDICTIONS_ADDENDUM2.md, sha 90cb62e3…0ee2): every zero with \|Im s\| ≤ 110 on the line and simple; with Platt–Trudgian, **GRH for ζ_K to \|Im s\| ≤ 110**, independently of Tollis. 180/180 runs closed, 3,660 certificates, min hardened margin 1.791; zero counts in (0, 92] = Tollis Nb − 25 for all 15. Simplicity of ζ_K's zeros is not claimed. Run through the launcher `run_ext2.py` (see "Full replays") | `new_territory/tollis/runs/{core,contig}/K{116,…,239}*`, `logs/union_K*_{core,0_110}.json`, `logs/tollis_compare_addendum2.json` |

Certificate counts in this bundle: v4 acceptance runs 15 main + 17 S-layer (Lean audit `v4_acceptance`), lehmer_full_pair 1 + 2, T4 runs
2 main each; deg2 737;
ec37a 400; ec389a 420; tollis 6,400 (1,764 for the six pre-registered fields incl. 120 validation-window files + 976 = 4 × (24 + 220) for −87/−104/−107/−108
+ 3,660 = 15 × (24 + 220) for −116 … −239). The ADDENDUM of tollis/RESULTS.md says "1104/1104"; that is a miscount, corrected in the
"Correction" section of the same file (976). Negative-control runs
(`runs/nc/`) are included because they are small; they are NOT claims (several are designed to fail).

## Environment

```
python3.12 -m venv .venv && .venv/bin/python -m pip install -r requirements.txt   # python-flint 0.9.0 bundles FLINT/Arb
export PY=$PWD/.venv/bin/python
```
Tested: CPython 3.12.13, macOS arm64. HiGHS (via SciPy) is used only by the untrusted generators, never by a replay.

## Quick verification (a few minutes)

```
PY=$PY ./quick_verify.sh          # writes only to quick_verify_out/ (incl. a scratch copy of the replayed degree-2 run) and to new <v4 run>/replay_bundle/ dirs; exit code = number of failures
```
It checks SHA256SUMS; replays the v4 runs lehmer_full_pair, c7002, rosser and 663318 (each ≲ 2 s; expected
`{"passed": true, "passed_B_simple_without_lemma2": true, …}` and the engine modules reported from the bundle); replays 11.a chunk [0, 10]
in a fresh process (expected `closed: true`, 20/20; about 1–2 min, ≈ 200 MB); re-verifies the 389.a1 modular-symbol certificate
(`L_E_1_IS_ZERO_PROVED`), Λ″(1) ≠ 0 for 389.a1 and Λ′(1) ≠ 0 for 37.a1; recomputes the exact unions (11.a [0,300], 37.a [0,200],
389.a [0,200], each of the 25 Tollis fields [0,110], K23 [0,200]) from the stored replay records and compares them with the stored union
logs (for 11.a, field by field with `deg2/runs/contig/UNION_0_300.json`, which has its own format); replays tollis K239 [100, 110] in a
fresh process through the ADDENDUM 2 launcher (expected `closed: true`, 20/20; about 1–2 min); runs
the Lean audit binary if `lean/` has been built.

## Full replays (per dataset)

All replays are independent of the generators: they rebuild every row/measurement from scratch and run the pinned verifier plain and
hardened (2 ulps outward). Run them at `nice -n 19`; never pass the default record names (`replay_check`, `replay.json`).

**ζ, atlas_v4** (per run: < 1 s to ≈ 3 s, ≤ 0.15 GB):
```
$PY tools/replay_v4.py atlas_mark2/diagnostic/atlas_v4/runs/w9000.00/v1_9000 replay_bundle
```
Expected last line: `{"passed": true, "passed_B_simple_without_lemma2": true, "np": "11/11", "certs": "10/10", "seams": [0, 0, 0], …}`
(exit 0 iff claim (A) passes). Output: `<run>/replay_bundle/replay_check.json`. Compare with the stored `<run>/replay_check/`.

**Degree 2 (deg2 / ec37a / ec389a / tollis)** (per 10-unit chunk: gen not needed; replay ≈ 1–3 min, ≤ 0.2 GB):
```
sh tools/replay_deg2.sh deg2   runs/contig/c_100_110      100 110
sh tools/replay_deg2.sh ec37a  runs/chunks/c_190_200      190 200
sh tools/replay_deg2.sh ec389a runs/chunks/c_0_10         0 10      # window contains 0: also re-runs the central proofs (modsym, Λ″(1))
sh tools/replay_deg2.sh tollis runs/contig/K23/c_190_200  190 200
sh tools/replay_deg2.sh tollis runs/core/K31_92.11_104.11 92.11 104.11
sh tools/replay_deg2.sh tollis+ext2 runs/contig/K239/c_100_110 100 110     # the 15 ADDENDUM-2 fields: via run_ext2.py
sh tools/replay_deg2.sh tollis+ext2 runs/core/K140_91.35_103.35 91.35 103.35
```
Expected final summary line with `"closed": true` and `"passed_both": 20` (24 for a core window). The wrapper replays a scratch copy
(`${TMPDIR:-/tmp}/atlas_replay/<pipeline>/<run>/replay.json`), because the deg2 version of replay_deg2.py always writes `RUNDIR/replay.json`.
Then the exact union (Fractions) over a chunk list, e.g. from `atlas_mark2/diagnostic/new_territory/tollis`:
`$PY -B union.py 0 110 runs/contig/K31/c_0_10 … runs/contig/K31/c_100_110` → `"covered": true, "gaps": []` (it reads each run's `replay.json`;
run it in the scratch tree to take the union of your own replays). Full-dataset replay cost
(from the RESULTS files): deg2 contig ≈ 30 × 1 min; ec37a 23 min; ec389a 36 min; tollis 75 min (six fields) + ≈ 4 × 11 min (extras)
+ 180 min (the 15 ADDENDUM-2 fields, ≈ 12 min each).

**The 15 ADDENDUM-2 fields (−116 … −239) and the launcher.** The frozen tollis registry (`cubic.FIELDS`, `TYPES_SHA256.json`) lists only
the first ten fields, and no frozen file was edited (`CODE_SHA256_FROZEN.txt`; `logs/code_sha_check_addendum2_{before,after}.txt`).
`fields_ext2.py` (data only) adds the 15 entries in memory, refuses to overwrite an existing one, checks disc(P) = d_K, and points the
table-sha check at `TYPES_SHA256_ADDENDUM2.json` (the 10 frozen entries verbatim, checked at load, + the 15 new ones). `run_ext2.py
SCRIPT.py ARGS…` installs that and runs the frozen script unchanged as `__main__`. So, from `atlas_mark2/diagnostic/new_territory/tollis`:
```
$PY -B run_ext2.py verify_cubic.py K239                                  # re-prove a type table (≈ 19 s); VERIFIED
$PY -B run_ext2.py replay_deg2.py SCRATCH_COPY_OF/runs/contig/K239/c_100_110 100 110   # or tools/replay_deg2.sh tollis+ext2 … (copies first)
$PY -B union.py 0 110 runs/contig/K239/c_0_10 … runs/contig/K239/c_100_110        # → logs/union_K239_0_110.json
$PY -B run_ext2.py diag_tollis.py K239 runs/contig/K239/c_* runs/core/K239_91.83_103.83   # diagnostic vs Tollis's row
```
(`run_targets_ext2.sh` / `post_field_ext2.sh` are the scripts that made the runs; they hard-code the host interpreter
`/Users/kiosk/projects/atlas-rerun/.venv/bin/python` and the host path, so use the commands above.) Regression check made before the
pre-registration: K23 [0, 10] regenerated through `run_ext2.py` gave certificates field-for-field identical to `runs/contig/K23/c_0_10`.

**389.a1 central zero:** `cd atlas_mark2/diagnostic/new_territory/ec389a && $PY -B modsym.py verify 389.a1 logs/modsym/389.a1.json`
(→ `L_E_1_IS_ZERO_PROVED`, cert sha 593d1a0e…); `$PY -B central.py` (→ Λ″(1) = 4.76702868626780955739539698012 ± 3.6e−30);
argument-principle cross-check `$PY -B argcount.py 1` (→ count 2, cf. `logs/argcount_T1.json`, 9 s).

**11.a cross-check (argument principle):** `$PY tools/run_crosscheck.py 0 300 /tmp/cc_full` reproduces `runs/full/result.json`
(N = 388, 416 leaves); it took 7,284 s. The `--perturb-a2` / `--theta0` controls are in `crosscheck_11a/RESULTS.md`.

**Degree-2 a_p / type tables:** `ec37a/verify_ap.py`, `ec389a/verify_ap.py` (≈ 19 s each) and `tollis/verify_cubic.py` (≈ 19 s per field)
re-prove the tables; `forms.py` refuses a table whose sha differs from the frozen value.

## Lean (certificate logic + certificate-file audit)

```
cd lean
curl -sSfL https://raw.githubusercontent.com/leanprover/elan/master/elan-init.sh -o elan-init.sh
sh elan-init.sh -y --no-modify-path --default-toolchain none
~/.elan/bin/lake update            # mathlib v4.34.1, toolchain leanprover/lean4:v4.34.1 (this may download the FULL Mathlib cache, ~7.6 GB)
~/.elan/bin/lake exe cache get Mathlib.Data.Complex.Basic Mathlib.Algebra.Order.BigOperators.Group.Finset \
  Mathlib.Algebra.Order.BigOperators.Group.Multiset Mathlib.Data.Finsupp.Basic Mathlib.Tactic.Linarith \
  Mathlib.Tactic.Positivity Mathlib.Tactic.Ring Mathlib.Order.Interval.Set.Basic \
  Mathlib.Algebra.BigOperators.Ring.Finset Mathlib.Data.Set.Finite.Basic       # only the ≈1.0k oleans actually imported
nice -n 19 ~/.elan/bin/lake build                                   # 17 s for the Atlas files; no sorry, no axiom
nice -n 19 ~/.elan/bin/lake env lean scripts/PrintAxioms.lean       # expected: only propext, Classical.choice, Quot.sound
nice -n 19 ~/.elan/bin/lake build atlas_audit
nice -n 19 .lake/build/bin/atlas_audit audit/data/{deg2,ec37a,ec389a,tollis,tollis_extra,tollis_ext_unions,v4_acceptance,v4_other}.txt \
     audit/data/{deg2,ec37a,ec389a,tollis}_nc.txt                    # exit 0; 0 violations in every real dataset; ec389a_nc: 39 (by design)
nice -n 19 python3 audit/mutation_test.py                           # 12/12 single-fault mutations caught
```
Disk: ≈ 2.7 GB toolchain + ≈ 1.8 GB `.lake` after the selective cache get (the README in `lean/` describes a transient peak).
Expected outputs are stored in `lean/audit/{audit_output.txt,mutation_output.txt}` and `lean/scripts/PrintAxioms.out`.
Re-exporting the data from the bundled certificates: `python3 tools/export_certs_bundle.py /tmp/audit_data` (the original exporter,
with only its hard-coded DIAG path redirected), then `python3 tools/export_tollis_unions.py /tmp/audit_data` (bundle-only driver: loads
the same exporter source unchanged and adds the dataset `tollis_ext_unions`, i.e. the `tollis_extra` certificates plus the union [0, 110]
of each of the 19 fields beyond the pre-registered six, which the exporter itself does not emit). Checked after the 2026-10-08 re-run
(all 25 Tollis fields): every dataset except `v4_other` reproduces `lean/audit/data/*.txt` byte for byte, including `tollis_extra`
(4,636 certificates) and `tollis_ext_unions`; `v4_other` holds only the runs bundled here (4 T4 runs + lehmer_full_pair, 25 files; the
original has 102). Stored audit (`lean/audit/RESULTS.md`): 8,091 distinct real certificate files, every target covered (incl. the 25
Tollis unions [0, 110] and K23 [0, 200]), 0 violations.

## Trust base

Trusted, not proved here: Arb/FLINT via python-flint 0.9.0 (every enclosure, (R), (C), Z signs); the sech-row explicit-formula engine
`certify_sech_interferometer.E_comp` and `integer_mechanism.far_bound/count_upper` (Trudgian's S(T) bound) for ζ; for degree 2 the
proved-in-THEORY lemmas (Λ tail, explicit formula, Gauss–Legendre bound, zero-count Lemma N) plus classical inputs: modularity
(11.a, 37.a1, 389.a1; Hecke/Aramata–Brauer for ζ_K/ζ), Hasse/Deligne–Serre, Rosser–Schoenfeld, Trefethen's quadrature bound,
Dedekind–Kummer, classical modular-symbol facts (389.a1), and for ζ_K Platt–Trudgian. Lemma 1 (sign change ⇒ odd on-line multiplicity)
is classical; Lemma 2 is ours (Lean-checked logic, no external review yet). The certificate logic (theorem, Lemma 2, all-open model,
assembly, S-layer, local count, central reduction) is machine-checked in `lean/` with analytic facts as explicit hypotheses.
Untrusted: all generators, HiGHS, sign-change searches, measurement caches.

## Paths (why `tools/` exists)

The copied code contains host paths that were not edited: `atlas_v4.py` (`PY`, the venv interpreter), `replay_target4.py` (`TILING`,
outside atlas_mark2 → `external/`), `lib/model4.py` (fallback `/Users/kiosk/atlas_mark2/diagnostic`, used whenever model4 runs from a
`replay_check/` copy, i.e. on every replay), `crosscheck_11a/ap_lambda.py` (`AP_DIR`) and `compare.py` (deg2 glob), `lib/lp.py`
(generator only), `lean/export/export_certs.py` (`DIAG`). `tools/replay_v4.py` patches `PY`/`TILING` in memory and starts the replay
subprocess with `tools/boot` on PYTHONPATH, whose `sitecustomize.py` pre-imports the bundled engine modules (it prints
`[bundle] engine modules: …` into `replay4.log`), so the bundled copies are used even on the original host. The other wrappers execute
the unmodified source with only the one path literal replaced. `crosscheck_11a/compare.py` is diagnostic and not wrapped.

## Not included

Generator scratch (`work/`, `controls_work/`), `__pycache__`, measurement caches beyond those stored inside run directories, v4 dev/val/
pathtest runs (exported in `lean/audit/data/v4_other.txt` only), plant-test and earlier-pipeline (v3, ladder) data, the zeta 10⁶-band
audit bundle, `EXPERT_QUESTION_DRAFT.md`. The 11.a [0, 300] union record `deg2/runs/contig/UNION_0_300.json` was written on 2026-10-08
from the stored per-chunk replay records (the original run checked the union but stored no file); it is re-derived by the Lean audit
target "union [0,300]" and by `quick_verify.sh`.

## Disclosure of AI assistance
The Atlas concept (zero-list-free certification of zeros on the critical line from the explicit formula) and the research programme are
Philip Gordon's, who proposed the guiding directions and hypotheses (super-resolution with automatic escalation, testing on historical
failure cases, the planted-zero test, resolving all open regions, pursuing unverified L-functions, the scaling question, adopting Lean
and Weil-form ideas), set the verification standards, and reviewed the results. The work was carried out with extensive use of Claude
(Anthropic) via Claude Code, including concurrently running sub-agents: within those directions Claude derived the specific technical
results, wrote essentially all code (pipelines, verifiers, cross-checks, Lean formalization and audit), ran all computations and
literature searches, and drafted the paper. Project history: Atlas Mark I (~/atlas, sealed 2026-09-23) and Mark II (~/atlas_mark2, from 2026-09-23); the core sech explicit-formula engine (certify_sech_interferometer.py + replay, 2026-09-26) and the propagation mechanism with its verifier (2026-09-26/27) were written by Claude (Claude Opus, Claude Code session 2026-09-23..10-04) under the author's design direction; the pipelines and results in this bundle were developed from 2026-10-04, also with Claude. Other AI systems were also used: Google's Gemini (late Aug - early Oct 2026) as an analytical reviewer and methodological critic (Mark I statistics evaluation, statistical interpretation, Trudgian +0.2/T placement, audit criteria, restraint in claims; no production code, computations or core mathematics — its own account is in disclosure_questions/ANSWERS_FROM_Gemini.md), and OpenAI's Codex (2026-09-23 to 10-04): mathematical/literature review, experiment design, numerical experiments, analysis and reporting, and substantial Mark II software downstream of the core engine (adaptive witness repair, sweeps, closure/joins, replay and bundle verification, earlier 10^6 bottom-layer runs); its account is in disclosure_questions/ANSWERS_FROM_Codex.md. Philip Gordon takes full responsibility for the content. The new mathematical arguments have not yet been reviewed by independent human experts. Everything
needed to re-check the results without trusting the AI or the author is in this bundle (replays, exact tiling, Lean proofs and audit).
