# What actually limits Atlas — findings 2026-10-06

## 1. Every recent "hard" stall was the memory watchdog, not mathematics
All 7 ladder stalls since the pole-guard fix (hybrid_v1 g7142 ×4, guard_v2 g6866 + g6910, crowded_v2_narrow c7700.17) are
4 GB watchdog kills (`ladder_*.jsonl`: watchdog_kill=true, peak 4.0–4.2 GB). In each, the LP was still converging (sampled
margin mu ≈ 25, cutting-plane rounds adding cuts) when it was killed. The pre-guard stalls (crowded_ladder, rc=0) were the pole artifact.
So: the ablation, the guard-factor test and the "hardness" signals since the pole fix measured LP memory on an 8 GB Mac, not proof difficulty.

Cause: scipy/HiGHS peaks at ~25x the dense LP matrix (benchmarked in lp_memory/bench.py: dense, sparse, simplex, IPM, presolve
off — all 22–27x). The matrix is ~99% dense (Lorentzian 1/r² tails), so sparsifying doesn't help (lp_memory/sparsity.py).
Fix: column generation (lslab.py, LP_CG=1). Exact same LP optimum; HiGHS only sees the active columns (~230 of 1850).
First case (g6866 [0.005,0.01], GF 1.1): identical round-by-round trajectory, CERTIFIED at round 9, peak 0.92 GB (was killed >4 GB),
41.6 s; hardened replay with the unmodified verify.py: CERTIFIED. Pre-registered test on the other 6: lp_memory/PREDICTIONS.md.

## 2. The base sech layer has a height ceiling (explains Rosser)
For h(r) = sech(a r), the background part of E(x) averages density × ∫h = (log(T/2π)/2π)·(π/a) = log(T/2π)/(2a).
The exclusion threshold is 2, and strip positivity forces a < π, so the base layer can only work on average while
log(T/2π) < 4a, i.e. T < 2π·e^{4a}: about 4.6e5 for a = 2.8 and 1.8e6 even as a → π.
Measured (ledger node means vs prediction):
| T | a=2.8 mean E (pred) | fraction of nodes E<2 |
|---|---|---|
| 8000 | 1.43 (1.28) | 0.91 |
| 6.82e6 | 2.44 (2.48) | 0.12 |
At 6.82e6 the off-centre unions cover 2.3 of 10 units even at d ≥ 0.2, so the Rosser column sits in a neighbourhood open to cap 0.5
and no ladder tier can start (NONPOSITIVE_SAMPLED, then an unhandled LP failure). T4 at 1e6/1e7 will hit the same wall.
This is a resolution statement: the sech kernel's width is bounded below (a < π) while the zero spacing 2π/log(T/2π) shrinks.

## 3. Correction to the T4 hypothesis
Only the sech rows use the arithmetic side at Re s > 1 (height-insensitive cost). Lorentzian rows evaluate ζ'/ζ at 1/2+ε+it
with Arb (lp.py Phi), whose cost grows with height like any on-line ζ evaluation — same as direct evaluation and the
argument principle. So "Atlas scales better because its arithmetic side is height-free" does not hold for the ladder.
T4 still measures the real ratios; the expectation should not be that the ladder's evaluation cost is height-free.

## What follows for the design (large heights)
- Fix the LP memory (column generation) — removes every current stall; re-test the guard factor under it.
- Above ~5e5: the sech base layer can't carry the top of the strip. Lorentzian rows have no width floor (ε can be small) but need
  ε ≥ 2·cap, i.e. they are wide exactly where d is large. Direct ζ evaluation is cheap at large d (far from the line).
  Natural large-height pipeline: direct evaluation for the top layer, Lorentzian/LP ladder near the line and at near-collisions.
- Within the zero-list-free explicit-formula family, the open question is a kernel/row family whose resolution improves with height
  for the top layer: e.g. sech rows at shifted centres combined in the LP (already super-resolution), or Lorentzian rows with
  ε < cap whose pole contributions are modelled rather than excluded.

## 4. Literature + a kernel-independent ceiling (literature_scaling/LIT_REVIEW.md, 2026-10-06)
Lemma (derived in the review; I checked it): if h is even, integrable, real on R and Re h >= 0 on |Im r| < 1/2, then Re h is a
positive harmonic function on the strip, h(x) = ∫ P(x-t) dmu(t) with P(x) = (1/2) sech(pi x) the centre-line Poisson kernel
(per boundary, mass 1/2), so h(0) <= (1/2)|mu| = ∫h, equality iff h = c·sech(pi r). An off-line pair with delta -> 0 contributes
-> 2 h(0), the background is density·∫h >= density·h(0), so a single positive kernel needs density < 2:
T < 2 pi e^{4 pi} ≈ 1.8e6 FOR ANY KERNEL. (A near-line off-line pair looks like a double zero on the line.)
Scope: this bounds the single-kernel threshold test (base layer). It does NOT bound the LP layer, which uses signed combinations
with on-line mass as variables.
Published methods all remove the background with a LOWER bound on on-line zeros (sign changes of Z / Turing-type counts)
(Büthe 2015; Hiary-Ireland-Kyi 2024 subtracts LMFDB zeros; Booker; Platt-Trudgian).
Top actionable item: rigorous Arb sign changes of Hardy's Z(t) as LP constraints ("on-line mass >= 1 in bin") — list-free
(discovered, not input), removes the background; cost O(sqrt T) per evaluation.
LP scaling: column generation (done, LP_CG); rigorous locality truncation; continuous (gamma, delta) exchange / sliding Frank-Wolfe.

## 5. Results (2026-10-06 evening)
- Column generation: pre-registered test MET — all 7 former stalls certify at t0, 0.5-0.9 GB, hardened replays pass (lp_memory/).
- Z(t) sign-change constraints (zsign/, THEORY_ZSIGN.md): Rosser column [6820051.73, 6820052.16] — where the old pipeline could not
  start — CERTIFIED for 0 < d <= 0.5 in one level per column, 0.6-2.5 s, <= 0.25 GB; pre-registered (PREDICTIONS sha d76a5d49) MET;
  hardened replays re-run by me 5/5 PASS. Low height: same columns in one level instead of 8 (1-18 s vs 300-2800 s).
  Claim scope: excludes off-line zeros (d > 0); does NOT by itself prove simplicity at d = 0 (old bottom level did).
  Framing: Turing/Büthe-type subtraction of discovered zeros, but zero-list-free and LP-certified.
- Latent gap found in the old verify.check: it does not reject negative y (all existing witnesses have y >= 0; no result affected).
