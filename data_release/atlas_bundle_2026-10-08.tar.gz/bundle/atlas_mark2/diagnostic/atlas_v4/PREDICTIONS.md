# atlas_v4 acceptance — pre-registered predictions (2026-10-07, written before any acceptance run)

Code frozen in `V4_FREEZE.sha256` (sha256 of every code file). This file's sha256 is in `PREDICTIONS.sha256`.
The acceptance runs are started by `run_acceptance.sh` only after `usefulness_tests/t4.done` exists, serially, < 2.5 GB per process.

**Disclosure — what I had already seen.** During development (light processes while T4 ran) I ran the final pipeline, or a prototype of it,
on: c7002 [7002.48, 7002.49] (closed, 1.95 s), the Rosser target [6820050.98, 6820052.15] (closed, 5.39 s, with an earlier tier-1 row
set: every 0.1 instead of 0.25), the 663318 target (closed, 2.71 s), the Lehmer column (prototype only, 1.6 s), a 2-unit piece
[9001, 9003] of V1 (3.2 s), the full windows [9100, 9110] (8.9 s) and [9200, 9210] (8.9 s), and 2-unit windows at 1e5, 1e6, 1e7
(4.6–5.2 s). V1 as a whole has **not** been run. The predictions below are therefore informed, not blind, for V2–V4.

Baselines (from atlas_v3/RESULTS.md and usefulness_tests/T1, T2): v3 V1 3686 s; v3 Lehmer 10.1 s, c7002 10.0 s; v3 Rosser 428 s;
v3 663318 883 s. Argument principle: [9000, 9010] map-free 2.6 s (certifies only |Re s − 1/2| ≤ 0.2); Lehmer map-placed 0.33 s, window
[7000, 7010] map-free 2.7 s; 663318 map-placed 24 s, map-free 39 s.

| | prediction (point) | pre-registered bound (counts as MET if inside) |
|---|---|---|
| P1 V1 [9000, 9010] closed | yes, 10 pieces, ≥ 9 closed at tier 1 | closed, replay plain + hardened 100%, 0 seams (hull, target, d = 0) |
| P1 wall | 9 s | ≤ 30 s |
| P1 speedup vs v3 (3686 s) | ~400× | ≥ 120× |
| P1 ratio v4 / arg principle (2.6 s) | v4 slower, ~3.5× | between 1.5× and 12× slower |
| P2 Lehmer [7005.06, 7005.10] | closed, 1 piece, 2.5 s | closed, ≤ 8 s (v3 10.1 s) |
| P2 c7002 [7002.48, 7002.49] | closed, 1 piece, 2 s | closed, ≤ 8 s (v3 10.0 s) |
| P3 Rosser [6820050.98, 6820052.15] | closed, 2 pieces, 5 s | closed, ≤ 20 s, speedup vs v3 (428 s) ≥ 20× |
| P4 663318 [663318.4, 663318.6] | closed, 1 piece, 3 s | closed, ≤ 10 s, speedup vs v3 (883 s) ≥ 88×, faster than the map-placed arg principle (24 s) |
| P5 peak memory | ≤ 0.2 GB | ≤ 0.5 GB every process |
| P6 independent `replay_target4.py` (no generator) | passes all 5 | passes all 5 |
| P7 controls | | C2 fake sign change accepted: 0; C3 tampered w accepted: 0; C4 drop-one without seams: 0 (targets with ≥ 2 certificates); C1 no-parity rejects d ≥ 1e-9: 0, and rejects d = 0 in ≥ 1 certificate over the set (Lemma 2 load-bearing somewhere); C5: ≥ 1 Rosser piece fails without sign changes |

Failure of any bound is reported as such in RESULTS.md. A target that does not close is a failure of v4, not a reason to re-tune and re-run
silently; any re-run after a code change is reported separately with the new code shas.

## Amendment 1 (2026-10-07, before any acceptance run; original text above had sha256 6ca7455425c5f05ea576d004a61393e3956700224ee16608a28b34bd33d7f48b)

Change: the S-layer and claim (B), simplicity without Lemma 2 (THEORY_V4 §10), were added to the generator, the replay and the summary;
controls C6 added. The main-certificate path (claim A) is unchanged in behaviour (the parity-free code paths are off for main pieces).
Re-measured on the same dev/validation targets with the amended code: [9100, 9110] 10.9 s (S-layer 11 zeros, all at tier z1),
Rosser target 4.1 s, 663318 2.2 s, c7002 1.6 s, [1e7, 1e7+2] 5.9 s. Code re-frozen in V4_FREEZE.sha256.

- The wall-time bounds P1–P4 above now include the S-layer; they are **not** changed. Point estimates: V1 11 s, Lehmer 2.5 s, c7002 1.6 s,
  Rosser 4.5 s, 663318 2.5 s.
- **P8** claim (B) holds for all 5 targets (every interval of every main certificate covered by a no-parity certificate that passes plain
  and hardened).
- **P9** controls C6: tampered no-parity certificates accepted 0; drop-one no-parity certificate leaving everything covered 0.
