# atlas_v4 — lean Atlas pipeline (2026-10-07)

Same certified claim as atlas_v3, much less machinery. For a target [tlo, thi], v4 proves: **every zero of ζ with height in the hull (the
smallest run of 0.01 bins e(k) = T0 + k·0.01 containing the target) lies on the critical line and is simple**, with hull × [0, 1/2] and
target × [0, 1/2] exactly tiled by replay-passed certificates. No zero list is used. Sign changes of Hardy's Z are discovered.
Every certificate is replayed plain and hardened by code that shares nothing with the generator except the dual certificate.

Claim (A) uses Lemma 2 (parity) for simplicity, exactly like v3. v4 also checks a second claim **(B): simplicity without Lemma 2**, via a
small parity-free certificate per discovered zero (the S-layer, THEORY_V4 §10). (B) is reported separately; the exit code reflects (A).

Theory, with every change justified before it was coded: `THEORY_V4.md`. Results: `RESULTS.md`. Pre-registration: `PREDICTIONS.md`.

## What changed from v3, and why it is faster

| v3 stage | v4 | why it is allowed |
|---|---|---|
| base sech ledgers (57–246 s) | **removed** | the all-open model (every bin: on box + off box [0, 1/2]) satisfies (H_model) by 0 < β < 1 alone (THEORY_V4 §1) |
| off-centre unions (17 s) | **removed** | same |
| propagation (115–536 s) | **removed** | same |
| make_cases: 6 kernels × 51 sech centres per 0.1 piece (482 s at 9000) | tier 1: kernels 1.6 and 2.8 every 0.25 (≈ 10 measurements per unit), escalate only on failure | rows are free to choose; the LP uses 2–6 of them |
| Lorentzian rows (Arb ζ'/ζ near the line) | **not used** | sech rows + sign changes suffice; also avoids a latent farL flaw (THEORY_V4 §9) |
| ~0.1-wide open/bottom pieces, ladder levels, phase-2 dependencies | one certificate per ≤ 1-unit piece, region piece × [0, 1/2]; no levels, no dependencies | each certificate stands alone (§1, §6) |
| separate bottom-level simplicity certificates | same certificate (Lemma 2 at d = 0 inside the region) | §6 |
| sign changes per ladder process, recomputed per replay | once per target (adaptive: dips of \|Z\| refined), verified per certificate by verify_zs | Lemma 1 needs only the Arb sign check (§4) |
| replay: 2 fresh processes per certificate; trusts case files + measurement cache | one replay process per target; model and every row rebuilt (fresh E_comp) | §5 |

## Pipeline

```
atlas_v4.py T0 tlo thi --name NAME [--pw 1.0] [--wm 2.0] [--zs-step 0.005]
```
1. **Pieces** (driver): hull bins; pieces of at most PW; window = piece ± WM (bins).
2. **Generator** (`lib/gen_target.py`, one fresh process, 2.5 GB watchdog, nice 19; NOT trusted): sign changes once over the union of the
   windows (`lib/zs4.py`), then per piece the sign-change LP (`lib/gen4.py`, derived from v3 `lslab_zs.py`: same LP, column generation,
   cutting-plane exchange) with sech rows measured by the unchanged `certify_sech_interferometer.E_comp`. Escalation per piece: t1 (1.6, 2.8
   every 0.25) → t2 (+2.2, every 0.05) → t3 (Z re-sampled 5× finer in the window) → split in two (down to 0.05).
   Then the S-layer: for every sign-change interval met by a main region, a certificate on [t1 − 0.001, t2 + 0.001] × {0} aimed at the
   parity-free condition (`gen4.certify(..., noparity=True)`), reusing the measured rows first (`certs_np/`).
3. **Replay** (`replay_target4.py` → `lib/replay4.py`, fresh process, no generator code): rebuilds each model (`lib/model4.py`) and every row
   (fresh E_comp, `im.far_bound`, `im.count_upper`), rejects any non-sech row, runs the sha-pinned `verify_zs.check` (`ed5bc621…`) plain and
   hardened (2 ulps outward), checks that every region is inside its window and on the hull's bin edges, then the exact tiling
   (`exact_tiling_check.check`, sha `0868990e…`) of hull × [0, 1/2] and target × [0, 1/2], and a 1-D exact sweep of the d = 0 line.
   S-layer certificates are checked by the **no-parity verifier**: the pinned `verify_zs.py` source with exactly one line changed (the
   d = 0 candidate is charged f·Σw of the intervals its box meets), built in memory by `replay4.noparity_check`; claim (B) requires them to
   cover, exactly, every interval of every main certificate inside its region.

Outputs `runs/w{T0}/{NAME}/`: `pieces.json`, `zs.json`, `certs/cert_*.json`, `gen.jsonl` (every attempt, timings), `gen_measurements.json`
(generator cache, never read by the replay), `replay_check/` (replay records, tiling), `summary.json`, `drive.jsonl`. Exit code 0 iff closed.

## What is proved (per certificate, and assembled)

Per certificate with region R = [x0, x1] × [0, 1/2] inside its window: no off-line zero (d > 0) with height in [x0, x1] (THEORY_ZSIGN
Theorem, all-open model), and no multiple zero on the line with height in [x0, x1] (v3 Lemma 2, parity). Assembled (THEORY_V4 §6): the
regions tile the hull exactly, so every zero with height in the hull is on the line and simple — claim (A). No ordering or dependency
between certificates.

Claim (B) (THEORY_V4 §10): a main certificate excludes a multiple zero *outside* its own sign-change intervals without parity; inside an
interval (width ≤ 1e-4) a per-zero certificate, passed by the no-parity verifier, excludes it without parity. If every interval is covered,
simplicity in the hull follows from the Theorem's argument and Lemma 1 alone.

## What is trusted

- `certify_sech_interferometer.E_comp` (sech-kernel explicit formula, Arb, zeta-series evaluator with certified remainder) and the
  inherited row argument for sech rows; `integer_mechanism.far_bound`, `count_upper` (Trudgian's S(T) bound). Same functions as v3.
- 0 < β < 1 for every nontrivial zero.
- THEORY_ZSIGN Theorem and Lemma 1; **Lemma 2 (parity ⇒ simplicity) — new in v3, checked only by us, needs independent review.** In v4
  every simplicity claim uses it (see the no-parity control in RESULTS.md).
- Arb/python-flint, Python `fractions`, the exact-tiling script, `verify_zs.py` (byte-identical to zsign/atlas_v3, sha-pinned).
- **Not trusted:** the generator (LP, its check, its sign-change search, its measurements).
- **No longer in the trust base (vs v3):** base ledgers, off-centre unions, propagation certificates, the measurement caches, case files,
  `lp.Phi`, `farL`.

## How to run / replay

```
P=/Users/kiosk/projects/atlas-rerun/.venv/bin/python; cd diagnostic/atlas_v4
$P -u -B atlas_v4.py 9000 9000 9010 --name v1_9000                 # V1
$P -u -B atlas_v4.py 7000 7005.06 7005.10 --name lehmer              # V2
$P -u -B atlas_v4.py 7000 7002.48 7002.49 --name c7002
$P -u -B atlas_v4.py 6820046 6820050.98 6820052.15 --name rosser     # V3
$P -u -B atlas_v4.py 663310 663318.4 663318.6 --name t2_663318       # V4
$P -B replay_target4.py runs/w9000.00/v1_9000                        # independent re-check (no generator), exit 0 iff passed
(cd SCRATCH && $P -B .../controls/controls4.py runs/w9000.00/v1_9000)  # controls C1-C6 -> RUN/controls.json
```
`run_acceptance.sh` runs V1–V4, the independent replays and the controls serially (it waits for `usefulness_tests/t4.done`);
`make_acceptance_results.py` then scores them against PREDICTIONS.md into `RESULTS_ACCEPTANCE.md`.
Test hooks (path coverage only, recorded in `summary.json`): `V4_TEST_SKIP_TIERS=t1,t2`, `V4_TEST_SPLIT=1`.

## Known limitations

- Lemma 2 needs independent review. Claim (A) uses it in almost every main certificate (no-parity control C1). Claim (B) does not use it,
  but rests on the no-parity verifier (one changed line of the pinned verifier) and on THEORY_V4 §10, which is also mine and unreviewed.
- Escalation tiers t2/t3/split were exercised only by test hooks (`runs/w7000.00/pathtest`), unless RESULTS.md says otherwise.
- Height scaling: the cost per unit is dominated by E_comp (0.03 s at 9e3, 0.1 s at 6.6e5–6.8e6 per measurement) and Z evaluations; both
  grow with height. The sech kernel needs a < π, so at much larger heights the zero spacing falls below the kernel width and more sign
  changes per kernel must be credited; whether one-unit pieces still close there is untested.
- A close pair missed by the Z sampling only costs credit; the escalation re-samples Z, but a pair closer than the finest sampling
  (about 1e-4 near a same-sign dip of |Z|) may still be missed, making the piece fail (never a false pass).
