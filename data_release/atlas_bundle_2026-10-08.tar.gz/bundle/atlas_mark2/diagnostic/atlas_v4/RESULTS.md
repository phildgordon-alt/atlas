# atlas_v4 results (2026-10-07)

## 0. Status

- **Acceptance runs V1–V4: NOT RUN YET.** They are pre-registered (`PREDICTIONS.md`, sha in `PREDICTIONS.sha256`, Amendment 1 made before
  any acceptance run) and queued: `run_acceptance.sh` is running in the background and waits for `usefulness_tests/t4.done` (T4 was still at
  height 1e4 at 07:17). When T4 finishes it runs V1, Lehmer, c7002, Rosser, 663318 serially, then the independent `replay_target4.py`
  and the controls for each, logging to `runs/acceptance.log`; `make_acceptance_results.py` then writes `RESULTS_ACCEPTANCE.md` scored
  against the predictions. Everything below is development and validation (light processes, nice 19, ≤ 0.25 GB, while T4 ran).
- Code frozen: `V4_FREEZE.sha256`. `lib/verify_zs.py` is byte-identical to zsign/atlas_v3 (sha `ed5bc621…`); `zfun.py`, `verify.py`,
  `lp.py` are byte-identical to atlas_v3/lib.

## 1. What v4 is (one paragraph)

One LP certificate per ≤ 1-unit piece, region piece × [0, 1/2], in an **all-open model** (every bin may hold an off-line pair up to
d = 1/2; justified by 0 < β < 1 alone), with **sech rows** (2–6 E_comp measurements used per certificate) and **sign-change credit**.
No base ledgers, no unions, no propagation, no Lorentzian rows, no levels, no dependencies between certificates. Simplicity from the same
certificate (Lemma 2), plus a parity-free S-layer (one tiny certificate per zero) giving claim (B): simplicity without Lemma 2. The replay
rebuilds every model and every row (fresh measurements) and runs the sha-pinned verifier plain + hardened; exact tiling.

## 2. Validation runs (final code; not acceptance targets unless marked "dev on acceptance target")

| target | v4 wall | gen (Z / measurements / main done) | replay | certs (plain+hardened) | S-layer (B) | min cand. lower | peak | v3 | arg principle |
|---|---|---|---|---|---|---|---|---|---|
| [9100, 9110] full window | **10.9 s** | 8.2 s (1.2 s / 82 in 2.6 s / 5.9 s) | 2.7 s | 10/10, all tier 1 | 11/11 zeros, all z1 | 1.053 | 0.15 GB | 4357 s | 2.7 s (|δ| ≤ 0.2 only) |
| [9200, 9210] full window | **11.1 s** | 8.4 s (1.2 s / 82 / 6.0 s) | 2.7 s | 10/10, tier 1 | 12/12 | 1.052 | 0.15 GB | 4127 s | 3.3 s (|δ| ≤ 0.2) |
| [9001, 9003] (2 units of V1) | 3.5 s | 2.4 s | 1.1 s | 2/2 | 2/2 | 1.049 | 0.14 GB | — | — |
| [1e5, 1e5+2] (T4-like) | 5.2 s | 3.5 s | 1.6 s | 2/2 | 2/2 | 1.035 | 0.14 GB | (T4 pending) | (T4 pending) |
| [1e6, 1e6+2] (T4-like) | 6.0 s | 4.1 s | 1.9 s | 2/2 | 4/4 | 1.025 | 0.13 GB | (T4 pending) | (T4 pending) |
| [1e7, 1e7+2] (T4-like) | 5.9 s | 3.8 s | 2.2 s | 2/2 | 5/5 | 1.012 | 0.15 GB | (T4 pending) | (T4 pending) |
| c7002 (dev on acceptance target) | 1.6 s | 1.1 s | 0.6 s | 1/1 (1 row!) | no zero in hull | 1.519 | 0.09 GB | 10.0 s | — |
| Rosser target (dev on acceptance target) | 4.1 s | 2.7 s | 1.4 s | 2/2 | 3/3 | 0.799 | 0.13 GB | 428 s | — |
| 663318 target (dev on acceptance target) | 2.2 s | 1.4 s | 0.8 s | 1/1 | 2/2 | 1.385 | 0.11 GB | 883 s | 24 s map-placed / 39 s map-free |
| Lehmer, path test (hooks: skip t1, t2, z1; force split) | 8.1 s | 7.3 s | 0.8 s | 2/2 at t3 (fine Z) after split | 2/2 at z2 | 1.066 | 0.23 GB | 10.1 s (column only) | 0.33 s / 2.7 s |

Every run: exact tiling of hull × [0, 1/2] and target × [0, 1/2] with 0 seams, d = 0 line with 0 gaps, independent replay passed.
The arg-principle runs certify only |Re s − 1/2| ≤ 0.2; v4 certifies the whole strip.

**Reading.** On full 10-unit windows at 9000–9200 v4 is ~400× faster than v3 (≈ 11 s vs ≈ 4100–4400 s) and ~3–4× slower than the
map-free argument principle. Near collisions (663318 pair) v4 is ~10× faster than the argument principle and ~400× faster than v3.
Cost per unit is now dominated by E_comp measurements (0.03 s each at 9e3, 0.1 s at 1e6–1e7), the Z grid (0.005 step) and Python
process start-up (~0.5 s per process, 3 processes); the LPs take 0.1–0.3 s per piece and the rigorous checks ≤ 0.05 s.

## 3. The ideas, measured (development, light processes)

| idea | measurement | verdict |
|---|---|---|
| 1. bigger pieces | v3 state + Lorentzian rows, [9001, 9002] d = 0 in ONE certificate: 42 s gen (93k boxes) with the v3 ±3 window; 20 s after var-box compaction (36k boxes); 6 s with a ±1 window (1.6k boxes, but margin only 0.0017). All-open sech: 1 unit in 0.3–0.8 s; 4 units in one LP worked (16 rows, margin 0.17, 7 s LP, 1.2 GB because of 34k candidate rows). | adopted at 1 unit (LP cost and margin are best there) |
| 2. simplicity once per region | Lemma 2 inside the piece certificate; the S-layer needs one 0.1–0.2 s certificate per zero (parity-free certificates cannot cover two zeros, THEORY_V4 §10) | adopted (both) |
| 3. skip ledgers / unions / propagation | at 9000 the unions alone close 968/1000 bins to level 0 and propagation only tightens 28 bins (115 s); at Rosser propagation changes 3 bins. The all-open model needs none of them: Rosser full target in one LP with 4 rows (0.56 s), 663318 with 2 rows, [9001, 9002] with 4 rows. With the v3 state, dropping the sech rows changed nothing (the LP used Lorentzian rows only); in the all-open model only sech rows are usable (Lorentzian poles), and they suffice. | all three stages dropped (they cost 189 s at 9000 and 782 s at 663318 in v3) |
| 4. adaptive Z sampling | grid 0.005 + extra samples at same-sign dips of |Z| + bisection to 1e-4; tier t3 re-samples 5× finer. No dips were triggered in any validation window; Z costs 0.3–1.2 s per target. Negative control: without sign changes the Rosser open part fails (sampled margin −0.057) — the credit is load-bearing there. | adopted; coarser grids not pursued (Z is cheap) |
| 5a. measurements | v3 measured 6 kernels × 51 centres per 0.1 piece (5208 new at 9000, 482 s). v4 tier 1: kernels 1.6, 2.8 every 0.25 (82 per 10 units). Sparser (every 0.5) also certified. | adopted |
| 5b. var-box compaction | the v3 case models list 8 nested slab boxes per open bin; the verifier checks each from d = 0: 93k → 36k boxes on the same certificate | (needed only for state models; v4 has 2 boxes per bin) |
| 5c. one process per target | generator and replay each one process (v3: 3 processes per certificate) | adopted |
| 5d. replay rebuilds rows itself | only the 1–6 rows with nonzero multipliers are emitted and re-measured | adopted |

## 4. Controls (validation runs; `controls/controls4.py`)

| run | C1 no-parity rejects d = 0 | C1 rejects d ≥ 1e-9 | C2 fake interval accepted | C3 tampered w accepted | C4 drop-one w/o seams | C5 pieces certifying without sign changes | C6 tampered S-layer accepted / drop-one still covered |
|---|---|---|---|---|---|---|---|
| [9100, 9110] | 9/10 | 0/10 | 0/10 | 0/10 | 0/10 | 2/10 | 0/11, 0/11 |
| [9200, 9210] | 8/10 | 0/10 | 0/10 | 0/10 | 0/10 | 5/10 | 0/12, 0/12 |
| Rosser target | 1/2 | 0/2 | 0/2 | 0/2 | 0/2 | 1/2 | 0/3, 0/3 |
| 663318 | 1/1 | 0/1 | 0/1 | 0/1 | (1 cert) | 0/1 | 0/2, 0/2 |
| [1e7, 1e7+2] | 2/2 | 0/2 | 0/2 | 0/2 | 0/2 | 0/2 | 0/5, 0/5 |
| c7002 | 0/1 | 0/1 | 0/1 | 0/1 | (1 cert) | 0/1 | (no zero) |

C1: **claim (A)'s simplicity rests on Lemma 2 in almost every v4 main certificate** (9/10 at 9100 vs 6/27 in v3, because v4 regions hold
many zeros). That is why the S-layer exists: claim (B) holds in every run above without Lemma 2. C5: at 9100/9200, 2 and 5 of 10 pieces close even
without any sign change (the sech base layer works at low height); at 663318, 1e7 and in the Rosser open part, sign changes are needed.

## 5. Soundness notes and findings

1. **Lemma 2 is still unreviewed.** Claim (A) depends on it heavily (C1). Claim (B) avoids it but depends on THEORY_V4 §10 and the
   no-parity verifier (the pinned verifier with one changed line, built in memory and recorded), both also mine and unreviewed.
2. **v3's d = 0 tiling check is vacuous** (`exact_tiling_check.check` with a degenerate [a, b] × [0, 0] rectangle has no strips and
   always returns 0 seams). v3's claim is not affected: its hull × [0, 0.5] check forces the bottom strip to be covered by ladder slabs with
   d_lo = 0. v4 uses its own exact 1-D sweep.
3. **farL latent flaw** (THEORY_V4 §9): the open-run correction uses the distance to the run's ends, which is too large when one open run
   contains a whole window. Audit of all 352 v3 certificates (`dev/farL_audit.py`, `dev/farL_audit.json`): 19 have straddling runs, all
   with an end inside the window (conservative); recomputing with split runs changes no F used with a nonzero multiplier (ΔK = 0). No v3
   result is affected. v4 does not use farL or Lorentzian rows (its replay rejects them).
4. **The candidate region must lie inside the window** (the Theorem needs the candidate to be a window atom); `verify_zs.check` does not
   test this. v3 guaranteed it by construction; v4's replay checks it explicitly.
5. v4's trust base is smaller than v3's: no ledgers, unions, propagation, measurement caches, case files, `lp.Phi`, `farL`. It still
   trusts E_comp and the sech-row argument, `far_bound`, `count_upper` (Trudgian), Arb, and the verifier.
6. Not exercised by real failures yet: tiers t2/t3/split and S-layer tiers z2–z4 ran only under test hooks (path test above).
