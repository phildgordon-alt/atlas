"""atlas_v4 controls on a finished run (light).  CLI: controls4.py RUN_DIR   (cwd = a scratch dir; writes RUN_DIR/controls.json)
C1 no-parity verifier: verify_zs with the d = 0 candidate charged f * SUM w of the intervals its box meets (n_i >= 1 only, no parity).
   Rejections show where the simplicity claim rests on Lemma 2.  The d >= 1e-9 part must still pass.
C2 fake sign change: one extra interval [m, m + 1e-4] between two certified intervals (no sign change there), w = 0.05 -> must FAIL.
C3 tampered dual: w multiplied by 10 -> must FAIL.
C4 tiling drop-one: removing any single certificate must leave seams in hull x [0, 1/2].
C5 no sign changes at all (generator, tier-2 rows, intervals = []) per piece: how many pieces still certify (credit not needed there).
C6 S-layer: each no-parity certificate with w multiplied by 10 must FAIL; dropping any one must leave an interval of claim (B) uncovered."""
import sys, os, json, glob, shutil, copy, importlib.util, types
from fractions import Fraction as Fr
from pathlib import Path
V4 = Path(__file__).resolve().parents[1]; RUN = Path(sys.argv[1]).resolve()
for f in ('verify_zs.py', 'model4.py', 'replay4.py', 'gen4.py', 'verify.py', 'lp.py', 'zfun.py'): shutil.copy(V4 / 'lib' / f, f)
open('farL.py', 'w').write('def far_L(*a, **k):\n    raise RuntimeError("disabled")\n')
os.environ['VERIFY_ZS_SHA'] = 'ed5bc62159b8438700fa8674037204dbc7d431adc0b9b7ef8600603e5f36ac66'; os.environ['EPS'] = ''
sys.path.insert(0, os.getcwd())
import replay4, model4 as M
NP = types.SimpleNamespace(check=replay4.NPCHECK)
from zfun import sgn
certs = sorted(glob.glob(str(RUN / 'certs' / 'cert_*.json'))); out = dict(run=str(RUN), C1=[], C2=[], C3=[], C4=[], C5=[])
for f in certs:
    c = json.load(open(f))
    r1 = replay4.replay(f, False, checker=NP.check)
    c9 = copy.deepcopy(c); c9['regions'] = [[r[0], r[1], 1e-9, r[3]] for r in c['regions']]
    r1b = replay4.replay(f, False, c=c9, checker=NP.check)
    out['C1'].append(dict(cert=Path(f).name, no_parity_d0=r1['passed'], detail=[(q['status'], q.get('box'), q.get('value')) for q in r1['regions']][-1:],
                          no_parity_d_ge_1e9=r1b['passed']))
    iv = c['zs_intervals']; j = len(iv) // 2
    m = (iv[j - 1][1] + iv[j][0]) / 2 if len(iv) >= 2 else (c['window'][0] + 0.01)
    fake = [m, m + 1e-4]; same_sign = sgn(fake[0]) * sgn(fake[1]) > 0
    c2 = copy.deepcopy(c); c2['zs_intervals'] = iv + [fake]; c2['w'] = c['w'] + [0.05]
    r2 = replay4.replay(f, False, c=c2)
    out['C2'].append(dict(cert=Path(f).name, fake=fake, z_same_sign_at_ends=same_sign, passed=r2['passed'], status=[q['status'] for q in r2['regions']]))
    c3 = copy.deepcopy(c); c3['w'] = [10 * x for x in c['w']]
    r3 = replay4.replay(f, False, c=c3)
    out['C3'].append(dict(cert=Path(f).name, passed=r3['passed'], status=[q['status'] for q in r3['regions']]))
    print(json.dumps(dict(cert=Path(f).name, C1=out['C1'][-1]['no_parity_d0'], C1b=out['C1'][-1]['no_parity_d_ge_1e9'], C2=r2['passed'], C3=r3['passed'])), flush=True)
sp = importlib.util.spec_from_file_location('tl', '/Users/kiosk/atlas/workbench/math_ablation_20260928/audit_20261004/exact_tiling_check.py')
TL = importlib.util.module_from_spec(sp); sp.loader.exec_module(TL)
P = json.load(open(RUN / 'pieces.json')); H = P['hull']; rd = Path('rects'); shutil.rmtree(rd, ignore_errors=True); rd.mkdir(); rects = []
for f in certs:
    q = rd / Path(f).name; json.dump(dict(region=json.load(open(f))['regions'][0]), open(q, 'w')); rects.append(q)
_, s_all = TL.check('all', [(Fr(H[0]), Fr(H[1]), Fr(0), Fr(0.5))], rects)
for q in rects:
    _, s = TL.check('drop', [(Fr(H[0]), Fr(H[1]), Fr(0), Fr(0.5))], [x for x in rects if x != q]); out['C4'].append(dict(dropped=q.name, seams=len(s)))
out['C4_all_seams'] = len(s_all)
import gen4
gl = [json.loads(l) for l in open(RUN / 'gen.jsonl')]; meas = json.load(open(RUN / 'gen_measurements.json'))
for f in certs:
    c = json.load(open(f)); ka, kb = c['piece_bins']; k0, k1 = c['bins']
    rows = [(k, *meas[k]) for k in sorted(meas) if M.centre(P['T0'], ka - 10) <= float(k.split('|')[1]) <= M.centre(P['T0'], kb + 9)]
    mm = M.model(P['T0'], k0, k1, rows); r = gen4.certify(mm, c['regions'], [], log=lambda s: None)
    out['C5'].append(dict(cert=Path(f).name, rows=len(rows), status_without_sign_changes=r['status']))
    print(json.dumps(out['C5'][-1]), flush=True)
npc = sorted(glob.glob(str(RUN / 'certs_np' / 'cert_*.json'))); out['C6'] = []
segs = {f: [(Fr(r[0]), Fr(r[1])) for r in json.load(open(f))['regions']] for f in npc}
need = []
for f in certs:
    c = json.load(open(f)); x0, x1 = c['regions'][0][:2]
    need += [(Fr(max(t1, x0)), Fr(min(t2, x1))) for t1, t2 in c['zs_intervals'] if t1 <= x1 and t2 >= x0]
def covered(a, b, ss):
    cur = a
    for u, v in sorted(ss):
        if u <= cur: cur = max(cur, v)
    return cur >= b
for f in npc:
    c = json.load(open(f)); c6 = copy.deepcopy(c); c6['w'] = [10 * x for x in c['w']]; r6 = replay4.replay(f, False, c=c6)
    rest = [s_ for g, v in segs.items() if g != f for s_ in v]
    out['C6'].append(dict(cert=Path(f).name, tampered_passed=r6['passed'], still_all_covered_without_it=all(covered(a, b, rest) for a, b in need)))
s = dict(C6_np_tampered_accepted=sum(x['tampered_passed'] for x in out['C6']), C6_dropone_np_still_covered=sum(x['still_all_covered_without_it'] for x in out['C6']),
         np_certs=len(npc), C1_rejected_at_d0=sum(not x['no_parity_d0'] for x in out['C1']), C1_rejected_d_ge_1e9=sum(not x['no_parity_d_ge_1e9'] for x in out['C1']),
         C2_fake_accepted=sum(x['passed'] for x in out['C2']), C2_fake_ends_same_sign=sum(x['z_same_sign_at_ends'] for x in out['C2']),
         C3_tampered_accepted=sum(x['passed'] for x in out['C3']), C4_dropone_without_seams=sum(x['seams'] == 0 for x in out['C4']),
         C4_all_seams=s_all.__len__(), C5_certify_without_sign_changes=sum(x['status_without_sign_changes'] == 'CERTIFIED' for x in out['C5']), certs=len(certs))
out['summary'] = s; json.dump(out, open(RUN / 'controls.json', 'w'), indent=1); print(json.dumps(s), flush=True)
