"""atlas_v4 all-open case model and row data (THEORY_V4.md sections 1-2).  Used by the generator driver AND by the replay.

Model for a window [e(k0), e(k1)], e(k) = T0 + k*H (H = 0.01, the v3 bin expression):
  vars  = per bin ['on', lo, hi, 0, 0] and ['off', lo, hi, 0, 0.5]        (no state: every zero has |beta - 1/2| < 1/2)
  Nwin  = integer_mechanism.count_upper(wlo, whi) rounded up                (Trudgian S(T); as propagation.build)
Rows:
  sech row 'a|t'   : Elo/Ehi = outward-rounded ends of the Arb enclosure E_comp(t) of certify_sech_interferometer (kernel a,
                     --evaluator zeta, series target 1e-6; exactly as v3 make_cases.ensure_meas / propagation), F = im.far_bound(a,t,wlo,whi)
  (no Lorentzian rows in v4: THEORY_V4 section 2)
No zero data is used anywhere."""
import sys, math
from pathlib import Path
DIAG = Path(__file__).resolve().parents[2] if (Path(__file__).resolve().parents[2] / 'integer_mechanism.py').exists() else Path('/Users/kiosk/atlas_mark2/diagnostic')
sys.path.insert(0, str(DIAG))
import integer_mechanism as im                      # noqa: E402
H = 0.01; CAP = 0.5


def edge(T0, k): return T0 + k * H                 # identical float expression to v3 (propagation.build / make_cases)


def centre(T0, m): return T0 + (m + 0.5) * H       # identical to propagation.centre (sech measurement centres)


def model(T0, k0, k1, sech_rows=()):
    """all-open model on bins k0..k1-1; sech_rows = [(id, Elo, Ehi)] (F computed here)."""
    wlo, whi = edge(T0, k0), edge(T0, k1)
    vars_ = []
    for k in range(k0, k1):
        lo, hi = edge(T0, k), edge(T0, k + 1)
        vars_.append(['on', lo, hi, 0.0, 0.0]); vars_.append(['off', lo, hi, 0.0, CAP])
    Nwin = im.up(im.count_upper(wlo, whi).upper())
    ids, Elo, Ehi, F = [], [], [], []
    for key, lo, hi in sech_rows:
        a, t = float(key.split('|')[0]), float(key.split('|')[1])
        ids.append(key); Elo.append(lo); Ehi.append(hi); F.append(im.far_bound(a, t, wlo, whi))
    return dict(window=[wlo, whi], vars=vars_, Nwin=Nwin, ids=ids, Elo=Elo, Ehi=Ehi, F=F)


_ENG = {}


def measure(key):
    """(Elo, Ehi) for sech id 'a|t': E_comp(t) enclosure, rounded outward exactly as propagation.build does (im.dn / im.up)."""
    import certify_sech_interferometer as eng
    from flint import arb, ctx
    a, t = float(key.split('|')[0]), float(key.split('|')[1])
    if _ENG.get('a') != a:
        eng.configure(a=a, x=1e7, band=(math.floor(t) - 5.0, math.floor(t) + 5.0), evaluator='zeta', target='1e-6')
        eng._init((a, 1e7, (math.floor(t) - 5.0, math.floor(t) + 5.0), str(eng.TABLE), eng.BB, 'zeta', '1e-6')); _ENG['a'] = a
    old = ctx.prec; ctx.prec = 256
    try: E = eng.E_comp(arb(t))
    finally: ctx.prec = old
    E = arb(E.str(30))                                   # same decimal round trip as the v3 measurement cache (str(30) -> arb)
    return im.dn(E.lower()), im.up(E.upper())
