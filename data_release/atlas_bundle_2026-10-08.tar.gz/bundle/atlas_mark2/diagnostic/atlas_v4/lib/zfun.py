"""Rigorous sign changes of Hardy's Z(t) (Arb, python-flint).  No zero list is used.
Z(t) = Re( exp(i*theta(t)) * zeta(1/2+it) ),  theta(t) = Im lgamma(1/4+it/2) - (t/2) log pi.
find_sign_changes(wlo,whi): grid step STEP, then bisection of each bracket down to length <= REFINE.
Returns disjoint open intervals (t1,t2) (binary64 endpoints, exact in Arb) with Z(t1), Z(t2) of strictly opposite sign."""
import os
from flint import arb,acb,ctx
def Z(t,prec=96):
    """Arb enclosure of Z(t) at the exact binary64 t."""
    old=ctx.prec;ctx.prec=prec
    try:
        T=arb(t);th=(acb(arb(1)/4,T/2).lgamma()).imag-T/2*arb.pi().log()
        z=acb(arb(1)/2,T).zeta();v=(acb(th.cos(),th.sin())*z).real
    finally:ctx.prec=old
    return v
def sgn(t):
    for p in (96,160,256):
        v=Z(t,p)
        if v.lower()>0:return 1
        if v.upper()<0:return -1
    return 0
def find_sign_changes(wlo,whi,step=None,refine=None):
    step=step or float(os.environ.get('ZS_STEP','0.005'));refine=refine or float(os.environ.get('ZS_REFINE','1e-4'))
    n=int((whi-wlo)/step);ts=[wlo+k*step for k in range(n+1)]+[whi]
    pts=[(t,sgn(t)) for t in ts];pts=[(t,s) for t,s in pts if s!=0]   # undecided points are dropped (only loses brackets)
    out=[];evals=len(ts)
    for (t1,s1),(t2,s2) in zip(pts,pts[1:]):
        if s1*s2>=0:continue
        while t2-t1>refine:
            m=(t1+t2)/2;sm=sgn(m);evals+=1
            if sm==0:break
            if sm==s1:t1=m
            else:t2=m
        out.append((t1,t2,s1,s2))
    return out,evals
if __name__=='__main__':
    import sys,time,json
    a,b=float(sys.argv[1]),float(sys.argv[2]);t0=time.time();iv,ev=find_sign_changes(a,b)
    print(json.dumps(dict(window=[a,b],count=len(iv),evals=ev,seconds=round(time.time()-t0,1),intervals=[[x,y] for x,y,_,_ in iv])))
