#!/bin/bash
# atlas_v4 acceptance V1-V4 (serial, one process at a time, 2.5 GB watchdog inside the driver). Waits for T4 to finish.
P=/Users/kiosk/projects/atlas-rerun/.venv/bin/python; V=/Users/kiosk/atlas_mark2/diagnostic/atlas_v4; U=/Users/kiosk/atlas_mark2/diagnostic/usefulness_tests
while [ ! -f $U/t4.done ]; do sleep 60; done
cd $V; LOG=$V/runs/acceptance.log; echo "start $(date)" >> $LOG
run() { s=$(python3 -c 'import time;print(time.time())'); $P -u -B atlas_v4.py "$@" > /dev/null 2>&1; rc=$?
        e=$(python3 -c "import time;print(round(time.time()-$s,2))"); echo "$5 rc=$rc outer_wall=${e}s" >> $LOG; }
run 9000 9000 9010 --name v1_9000
run 7000 7005.06 7005.10 --name lehmer
run 7000 7002.48 7002.49 --name c7002
run 6820046 6820050.98 6820052.15 --name rosser
run 663310 663318.4 663318.6 --name t2_663318
for t in w9000.00/v1_9000 w7000.00/lehmer w7000.00/c7002 w6820046.00/rosser w663310.00/t2_663318; do
  s=$(python3 -c 'import time;print(time.time())'); $P -B replay_target4.py runs/$t replay_check_independent > runs/$t/replay_target_independent.log 2>&1; rc=$?
  echo "replay_target4 $t rc=$rc $(python3 -c "import time;print(round(time.time()-$s,2))")s $(tail -1 runs/$t/replay_target_independent.log)" >> $LOG
  C=$V/runs/$t/controls_work; mkdir -p $C; (cd $C && $P -B $V/controls/controls4.py $V/runs/$t > controls.log 2>&1); echo "controls $t $(tail -1 $C/controls.log)" >> $LOG
done
echo "done $(date)" >> $LOG; touch $V/runs/acceptance.done
