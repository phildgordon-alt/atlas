# L(s, 11.a) contiguous coverage of [0, 300] — RESULTS (2026-10-07), scored against PREDICTIONS_CONTIG.md (sha fea32933…)
30/30 chunks [10k, 10k+10] closed; every chunk 20/20 certificates pass replay plain + hardened (fresh process, all rows recomputed,
sign-change endpoints re-verified with the A=1.2 series); per-chunk exact tiling 0 gaps; chunk union covers [0, 300] with 0 gaps
(exact rationals). Distinct sign-change intervals inside the targets: 388 (main-term estimate (T/π)log(√11·T/(2πe)) ≈ 388).
K1: MET — every zero of L(s, 11.a) with 0 <= t <= 300 lies on the critical line and is simple (simplicity via Lemma 2; Lemma 2
being formalized in Lean, formal/). K2 (diagnostic): the sign changes in [0, 20.38] match LMFDB's 10 listed zeros.
Status vs literature (PRIOR_VERIFICATION.md): no published rigorous verification found above t ≈ 32 (CMF paper's b unstated; code
suggests 32). Claim wording until experts confirm: "not found in the published literature or LMFDB as of October 2026, to our knowledge".
