# Pre-registered predictions for the degree-2 Atlas target runs (written 2026-10-07, before any target run)

Code: `deg2/` (gen_cert.py generator, replay_deg2.py + replay_verify.py independent replay). Theory: `deg2/THEORY_DEG2.md`.
Validation already done before this file was written: 11.a, t in [0, 20] closed (40/40 cells, plain + hardened replay, min margin 1.88);
sign changes matched LMFDB's 10 listed zeros (diagnostic only). Negative controls were running when this was written.

Fixed protocol (no tuning after seeing target data; any change gets logged as an amendment):
- window W = target +/- 6, scan step 0.02, bisection to width 1e-9; cells of width 0.5; d in [0, 1/2] in one level;
- rows: sech a in {0.8, 1.0, 1.25} (P = 3e5, 1e6, 2e6) at t = target_lo - 2 + k/4, Lorentzian eps = 1.5 (P = 1e6) every 1.0;
- replay: P x 1.5, 24-node quadrature, A = 1.2 split for Z, plain + hardened.
- A window is CLOSED only if every cell passes both replays and the exact tiling has no gap.

| target | expected zeros (Riemann-von Mangoldt main term) | prediction |
|---|---|---|
| 11.a, t in [100, 110] | about 13 (12-14) | CLOSED, all cells certified in round 0-2, min hardened margin > 0.5, generator < 15 min, replay < 15 min |
| 11.a, t in [200, 210] | about 15 (14-16) | CLOSED, same criteria; Z cost about 3x that at 100 |
| L(s, 23.1.b.a) (eta(z)eta(23z), weight 1), t in [93.5, 104] (stretch, only after its own validation on [0, 18] against LMFDB) | about 14-15 | CLOSED; together with Platt-Trudgian for zeta this gives RH for zeta_K, K = Q(x^3 - x - 1), disc -23, for 93.5 <= gamma <= 104, overlapping Tollis's 93.81 |

Probability I assign to closure: 11.a [100,110] 0.9; [200,210] 0.85; 23.1.b.a 0.8.
Failure modes I expect if any: a missed close pair of sign changes (credit lost; cell fails, conservative), or the weight-1 archimedean
quadrature (narrower analyticity strip, H = 0.3) giving wider row radii.
Novelty basis (TARGETS.md): no published rigorous RH verification of 11.a above roughly 20-30 (Best et al. 2021 section 10.3 unstated b;
LMFDB zeros end at 20.38; Hiary-Ireland-Kyi only 37.a1 |t| <= 10); Tollis 1997 stops at 93.81 for disc -23. Moderate confidence only.
