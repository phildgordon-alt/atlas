# Contiguous coverage of L(s, 11.a) on t in [0, 300] — pre-registered 2026-10-07 (before any run of the uncovered chunks)
Code: new_territory/deg2 as frozen in deg2/SHA256SUMS (code files; RESULTS.md excluded). gen_cert.py 11.a in 30 chunks [10k, 10k+10],
k = 0..29 (fresh runs, also of the already-certified [0,20], [100,110], [200,210]), defaults (--margin 6 --cell 0.5 --step 0.02);
each chunk replayed with replay_deg2.py (plain + hardened); then an exact union check that [0, 300] is covered with 0 gaps.
Prediction K1: all 30 chunks closed; the union covers [0, 300] (every zero of L(s, 11.a) with 0 <= t <= 300 on the line and simple;
simplicity via Lemma 2). Prediction K2: total sign changes found in [0, 300] equals the diagnostic count from LMFDB/known asymptotics
within +-0 where LMFDB has data (t <= 20.38) — diagnostic only.
Falsifier: any chunk not closed (reported with its location), or a replay failure.
