# Prior verification check: RH for L(s, 11.a) and L(s, 23.1.b.a)

Compiled 2026-10-07 from primary sources: PDFs fetched and text-extracted, the LMFDB API (JSON), and source code cloned from GitHub. Labels used below:
**STATED** means the source says it explicitly. **IMPLIED** means it follows from what is stated, or is inferred from code or data and is not stated. **NOT FOUND** means no source located says it.

---

## Verdicts

| Question | Verdict |
|---|---|
| Q1: RH for L(s, 11.a) on 0 <= t <= 300 | **NOT FOUND** for any height above about 32. No published rigorous verification for t in [100,110], [200,210], or anywhere up to 300 was found. What is published: (a) LMFDB/CMF paper, RH "up to height b" for every CMF L-function, with b never stated (STATED, b unspecified). (b) LMFDB lists 10 zeros, complete up to t = 20.379 (STATED via reliability page). (c) Platt's code fixes b = 64/degree = 32 for degree 2 (IMPLIED from code comments). |
| Q2: RH for L(s, 23.1.b.a) on [93.5, 104] | **Partly published.** Tollis (1997) proved GRH for zeta_K, K = Q(x^3 - x - 1) with disc -23, up to height **93.81** (STATED in table 6.2; the abstract says "height 92"). Because L(s, 23.1.b.a) = zeta_K(s)/zeta(s), RH for L on [0, 93.81] follows (IMPLIED, immediate). So [93.5, 93.81] is covered. **[93.81, 104] is NOT FOUND.** No later published height for this zeta_K was found, and 2025 papers still cite Tollis as the state of the art. |

---

## Q1: L(s, E), E = 11.a (newform 11.2.a.a; L-function 2-11-1.1-c1-0-0)

### 1. Best–Bober–Booker–Costa–Cremona–Derickx–Lee–Lowry-Duda–Roe–Sutherland–Voight, "Computing classical modular forms", arXiv:2002.04717 (v4). Published in *Arithmetic Geometry, Number Theory, and Computation* (Springer, Simons Symposia, 2021/22), pp. 131–213.

- §10.3 "Data reliability", p. 43 of the arXiv PDF (STATED, but no value for b):
  > "As a consistency check for our L-function computations, after computing a provisional list of all non-trivial zeros on the critical line up to a chosen height bound b we confirmed that no zeros are missing, in other words, that the Riemann Hypothesis holds for each L-function up to height b. We use the method described in [17] based on the Weil–Barner explicit formula."
  - [17] is J. Büthe, "A method for proving the completeness of a list of zeros of certain L-functions", Math. Comp. 84 (2015) 2413–2431.
  - **b is not given anywhere in the paper**, neither per form nor globally. I checked the arXiv text and Voight's later "scrubbed" version (cmfs-mf-101222), and the sentence is identical in both.
  - The paper calls this "a consistency check". §10.3 opens by saying all modular form data was computed "using rigorous algorithms that do not depend on any unproved assumptions or conjectures".
- §9.2, p. 36: the rigorous method "builds on several improvements and extensions of the algorithm from [11]" (Booker 2006), "the details of which will appear in future work [9]". [9] is Bober, Booker, Costa, Lee, Platt, Sutherland, "Computing motivic L-functions", *in preparation*. I found no published version. The library is "due originally to Dave Platt [28]" (Costa–Platt, github.com/edgarcosta/lfunctions).
- §9.2 lists what is computed: root number, "the imaginary part of the first few zeros", the rank bound, the leading Taylor coefficient, and a plot. It does not mention zeros up to t ~ 100.

### 2. The height b, inferred from code (IMPLIED, not published)
Both repositories contain the same comments:
- `src/turing.c`: "Use Booker's generalisation of Turing's method to confirm RH to height B/(OUTPUT_RATIO*degree) ... B is hard wired to 512 in g.c so height is 64/degree"
- `src/buthe.c`: "We use Buthe's method to verify our list of zeros ... use the zeros up to height 96/r to check the list to height buthe_b=64/r"; `include/glfunc_internals.h`: `#define OUTPUT_RATIO (8)`.

So for degree 2, the RH-confirmed height in this code is **64/2 = 32**. It cannot reach t ~ 100 without changing B.
- Caveats: this is current code (edgarcosta/lfunctions, last commit 2026-06-05; djplatt/glfunc, 2026-09-16). The 2019 LMFDB run may have used other constants. The stored plot for 11.a extends to t of about 45, and for 23.1.b.a to about 28.
- Code docs (`doc/api.md`): "When the rank is 0 or 1 and the RH check succeeded ... the list is complete up to the height reached".

### 3. LMFDB (API checked 2026-10-07; https://www.lmfdb.org/api/lfunc_lfunctions/?label=2-11-1.1-c1-0-0)
- `positive_zeros`: **10 zeros**, from 6.36261389471308870138602900887905 up to **20.37926046435010943649954977728340**. Also `z1`, `z2`, `z3`, and `accuracy: 100`.
- `plot_delta` = 0.17578125 with 257 `plot_values`, so the Z-plot covers t in [0, about 45].
- `load_key: "CMFs-workshop"`, `origin: ModularForm/GL2/Q/holomorphic/11/2/a/a`, `instance_types: ['ECQ','CMF','CMF']`.
- There is **no field** named `rigorous`, `rh_height`, `verified_to` or similar. No database field records b.
- Reliability page /L/2/11/1.1/c1/0/0/Reliability. Plain curl is captcha-blocked, so this text came through WebFetch and its wording may be slightly re-rendered:
  > "L-functions of classical, Hilbert, and Bianchi modular forms in the database have been precomputed using rigorous precision bounds and interval arithmetic [to] ensure that zeros and special values are accurate to the displayed precision ..., and that the list of zeros is complete (within the region covered by the list, including the lowest zero)."
  > "Each zero is known to lie within a disc whose radius is determined by the displayed precision, but note that this is not sufficient to prove that the[y] lie on the critical line."
- Source page: "All L-functions of classical, Hilbert, and Bianchi modular forms in the database were computed by Edgar Costa using source code provided by David Platt."
- Knowl `lfunction.zeros` gives only definitions and makes no verification claim.
- **Net:** LMFDB publicly asserts completeness only up to t of about 20.38 for 11.a.

### 4. Hiary–Ireland–Kyi, "A method for verifying the generalized Riemann hypothesis", arXiv:2408.00187 (v1 only, 31 Jul 2024; no journal reference on arXiv)
- §7.4, pp. 19–20, covers **37.a1 only**:
  > "We applied Theorem 7 with δ = −1, τ = 90, to verify the RH for the elliptic curve E with minimal Weierstrass equation (18) E : y^2 + y = x^3 − x. According to [LMFDB, 37.a1], E has conductor 37 ..." ... "Theorem 7 succeeded in verifying the RH for L(s,E) for η = 10, a window which contains 5 zeros with nonnegative ordinates."
- Their input zeros came from LMFDB and lcalc. §7: "Our working assumption is that the zeros ordinates from [LMFDB] and [Zet] are accurate within ±10^−10, and the zeros ordinates obtained using [Rub] and [The24] are accurate to within ±10^−8".
- The only other examples are zeta, the real Dirichlet character d = −1159523, and Ramanujan Delta (η = 84, 46 zeros).
- **11.a does not appear in the paper (NOT FOUND).** It cites Booker 2006, Bober 2013 (conditional rank bounds), Turing and Trudgian, but not the CMF paper's height-b check.

### 5. Büthe, Math. Comp. 84 (2015) 2413–2431 (arXiv:1308.6704v4)
- Gives the method for elliptic curves over Q (Theorem 4.7, §4.3) and says: "As far as the author knows, the Turing method has not been adapted to the latter families of L-functions before" (p. 2).
- It contains **no numerical verification for any specific elliptic curve** (NOT FOUND for 11.a).

### 6. Booker, "Artin's conjecture, Turing's method, and the Riemann hypothesis", Exp. Math. 15 (2006) 385–407 (arXiv:math/0507502)
- Its examples are splitting fields of S5 and A5 quintics (Table 6.1, "Tested polynomials"). It does not cover 11.a or 23.1.b.a (NOT FOUND).

### 7. Other sources
- Rubinstein's lcalc is non-rigorous: it uses no interval arithmetic and certifies no RH. 11.a zeros to large height have surely been computed with it, but that is not a verification.
- I found no paper titled anything like "verification of GRH for elliptic curve L-functions" by Platt, Booker, Bober, Sutherland, Ireland or Kyi. Searches turned up only HIK and the CMF paper.
- Farmer–Koutsoliotas–Lemurell: their published degree-2/3 work found so far is non-rigorous or about different families. I did not read it in depth.

---

## Q2: L(s, 23.1.b.a) = zeta_K(s)/zeta(s), K = Q[x]/(x^3 − x − 1), disc −23 (LMFDB L-function 2-23-23.22-c0-0-0)

### 1. Tollis, "Zeros of Dedekind zeta functions in the critical strip", Math. Comp. 66 (1997), no. 219, 1295–1321 (PDF fetched via the Wayback Machine)
- Abstract, p. 1295:
  > "In this paper, we describe a computation which established the GRH to height 92 (resp. 40) for cubic number fields (resp. quartic number fields) with small discriminant. ... we take care of accumulated roundoff error to obtain results which are mathematically rigorous, and we generalize Turing's criterion to prove that there is no zero off the critical line."
- p. 1317, end of §5: "For each field, we have proved the GRH (height 92 for degree 3 and 40 for degree 4) ... (the complete list of zeros is available upon request from the author)."
- §6, p. 1317: "For number fields of degree 3 and 4, we have proved the GRH up to a certain height. For each field, we give this height, ..."
- **Table 6.2 (degree 3, signature (1,1)), p. 1318.** Columns: P(x), D_K, GRH Height, Nb <= 92, First Zero, gaps.
  > `x3 + x2 − 1   −23   93.81   121   5.11568   0.04081   2.04357   0.25629   2.04357`
  - x^3 + x^2 − 1 defines the same field as x^3 − x − 1, the unique cubic field of disc −23.
  - The first zero 5.11568 matches LMFDB z1 = 5.11568332881... for 23.1.b.a. Here zeta has no zero below 14.13, so the first zero belongs to L.
  - The "121" counts zeros of zeta_K, which include zeta's zeros, up to height 92.
- Method note, p. 1318: verification by Gram blocks satisfying Rosser's rule ("we needed between 9 and 13 Gram blocks satisfying Rosser's rule, to check the GRH").
- **Consequence (IMPLIED):** the nontrivial zeros of L(s, 23.1.b.a) are a subset of those of zeta_K, so RH for L holds for 0 < t <= 93.81. If one cites only the abstract, the safe figure is 92.

### 2. Later literature
These 2025 papers still cite Tollis as the latest verification for small cubic fields:
- Das–Gaba–Lee–Savalia–Wong, arXiv:2506.19319 (2025), p. 1:
  > "Tollis [19] has verified that the GRH is true for ζL(σ+it) in the region |t| ≤ 92 for number fields L with nL = 3 and dL ≤ 239 ... In general, computations verifying the GRH are limited and only available in some special cases."
- Das–Kadiri–Ng, arXiv:2508.09480 (2025), Remark 6, p. 7:
  > "Unfortunately, we do not have access to similar calculations for the Dedekind zeta function for extensive families of number fields L. ... Tollis [57] verified GRH for a small number of cubic, quartic, and quintic number fields and Booker [9] verified GRH for a few fields of small discriminant."
  - The Booker reference is to his S5/A5 fields, not disc −23.
- Other checks, none of which is a zeta_K(disc −23) verification above 93.81:
  - Omar's papers (Acta Arith. 95, 2000; lowest zeros) and arXiv:2401.10936 (lowest zero of zeta_K, 2024) only cite Tollis.
  - Platt, Math. Comp. 85 (2016), covers Dirichlet L-functions only.
- **Verdict:** no published height beyond 93.81 for this zeta_K was found (NOT FOUND).

### 3. The CMF/LMFDB route for 23.1.b.a
- CMF paper Example 9.2.1 (p. 36) computes ε, L(f,1/2) and "approximate values for the imaginary part of the first ten zeros" (5.11568..., up to 18.0807). The same §10.3 "height b" sentence applies, with b unspecified.
- LMFDB API: 10 positive zeros up to 18.08066174344421407705280597228646, `plot_delta` 0.109375 with 257 points (t up to about 28), no rigor or height field.
- Costa–Platt `examples/cmf_23.1.b.a.cpp` prints the first 10 zeros with ball radii of about 1e-53 to 1e-46.
- By the code-implied b = 32 for degree 2, nothing here goes near t = 93.5.

---

## Gaps and caveats
1. The value of **b** in CMF §10.3 is unpublished. The figure of 32 is my inference from current code comments, not a statement by the authors. Asking Costa or Platt would settle it, including whether the 2019 run used other constants.
2. The "Computing motivic L-functions" paper (Bober–Booker–Costa–Lee–Platt–Sutherland) was still "in preparation" as cited. I found no arXiv version. If one exists, it would be the most likely place for per-form heights.
3. Tollis's full zero lists exist "upon request" only.
4. Tollis's table gives 93.81 while the abstract and running text say 92. A conservative citation would say "to height 92, and 93.81 per Table 6.2".

---

## People best placed to confirm
1. **David Platt** (University of Bristol, School of Mathematics). Wrote the generic rigorous L-function calculator (djplatt/glfunc, edgarcosta/lfunctions), including the Turing/Booker and Büthe RH checks and the hard-wired height. Co-author of "Computing motivic L-functions". He would know whether anyone has pushed degree-2 checks to t ~ 100–300.
2. **Edgar Costa** (MIT). Ran all LMFDB CMF/EC L-function computations (per the LMFDB Source page) and maintains the lfunctions repo. Best placed to say what b was in the 2019 run and whether per-form heights were logged.
3. **Andrew R. Booker** (University of Bristol). Author of the generalized Turing method (Exp. Math. 2006) and co-author of the CMF paper and the motivic L-functions paper. He would know about unpublished or in-progress verifications for small-conductor degree-2 L-functions and Artin L-functions such as 23.1.b.a.
4. **Ghaith Hiary** (Ohio State University). Lead author of arXiv:2408.00187, the most recent paper on GRH verification for elliptic curves (37.a1, η = 10). He would know whether his group, including Ireland and Kyi, has extended this to 11.a or to larger heights.
5. **Jonathan Bober** (University of Bristol). Co-author of the CMF paper and the motivic L-functions paper, author of mflib, and did conditional and rigorous analytic-rank and L-function computations for LMFDB. He is a second source on the CMF zero-completeness checks.
   - Also useful for Q2: **Habiba Kadiri** (Lethbridge) or **Ethan S. Lee** (Bristol). Both surveyed Dedekind-zeta GRH verifications in 2025 and would know of any post-Tollis computation.
