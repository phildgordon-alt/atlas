# Atlas: where RH/GRH verification is not yet published but is reachable on this machine

Survey date 2026-10-07. Notation: **[S]** means the cited paper says it. **[I]** means it is my inference. **[M]** means I measured it on this Mac with python-flint 0.9.0 (`/Users/kiosk/projects/atlas-rerun/.venv`) at the stated precision. The measurements are single runs, not benchmarks.

## 0. Honest framing first

- **Everything Atlas has certified so far lies inside published verified ranges.**
  - Zeta: the 6.8e6 run is far below the Platt–Trudgian height of 3·10^12.
  - Dirichlet: Platt's height H_q = max(10^8/q, …) is about 2·10^7 for q=5, 1.4·10^7 for q=7, 7.7·10^6 for q=13 and 2.5·10^7 for q=4. So the q=5 window at 10^4 and the q=7/13/4 windows at 10^3 are all already covered. [S, I]
  - The Atlas results therefore show that the method works. They do not give new verification coverage.
- **Prior art very close to the Atlas method.**
  - **Hiary–Ireland–Kyi, "A method for verifying the generalized Riemann hypothesis", arXiv:2408.00187 (2024).** [S] They:
    - evaluate one logarithmic derivative L'/L in the region of absolute convergence (e.g. at s = 2);
    - compare it with a sum of Lorentzian/Poisson-kernel weights over isolated sign-change intervals, e.g. the terms 12/(9+4γ²);
    - use mpmath interval arithmetic plus FLINT polygamma.
    - Their results:
      - zeta near 10^28, about 1.4·10^6 zeros;
      - the real character χ_d with **d = −1159523**, for |t| ≤ 32 (74 zeros);
      - Ramanujan Δ for |t| ≤ 84;
      - **elliptic curve 37.a1 for |t| ≤ 10**.
  - **Büthe, "A method for proving the completeness of a list of zeros of certain L-functions", Math. Comp. 84 (2015) 2413–2431, arXiv:1308.6704.** This uses the Weil–Barner explicit formula. [S]
  - Atlas's distinct features are: no zero list is needed as input, the LP certificate, and the multi-row Lorentzian design. Any write-up must cite and contrast with both papers.

## 1. Zeta (out of reach, confirmed)

- **Rigorous:** Platt & Trudgian, "The Riemann hypothesis is true up to 3·10^12", Bull. LMS 53 (2021) 792–797. doi:10.1112/blms.12460, arXiv:2004.09765. All zeros with 0 < γ ≤ 3·10^12 are on the line and simple, verified with interval arithmetic. [S]
- **Earlier rigorous run:** Platt, 3.061·10^10 (cited as h_3(1) in BMOR, below). [S]
- **Non-rigorous:** Gourdon (2004), first 10^13 zeros. [S]

## 2. Dirichlet L-functions

**Platt, "Numerical computations concerning the GRH", Math. Comp. 85 (2016) 3009–3027, arXiv:1305.3087.** [S]
- GRH is verified for **all primitive χ mod q, 3 ≤ q ≤ 400 000**, up to height H_q = max(10^8/q, c_q·10^7/q + 200), with c_q = 7.5 for even q and 3.75 for odd q.
- That is 29 565 923 837 L-functions and about 3.8·10^13 zeros.
- Separately, L(1/2, χ) ≠ 0 is verified for q ≤ 2·10^6. That result is about the central point only, not GRH.
- Platt's thesis ("Computing degree 1 L-functions rigorously", Bristol 2011) did q ≤ 100 000 with qT ≥ 10^8. [S]

**Bennett–Martin–O'Bryant–Rechnitzer, "Explicit bounds for primes in arithmetic progressions", Illinois J. Math 62 (2018) 427–532, arXiv:1802.00085.** [S]
- Prop. 2.7 states: conductor d ≤ 10^5 gives GRH up to 10^8/d.
- They note Platt's data go through q = 4·10^5, and they use only q ≤ 10^5.

**Lu–Zaman–Zhao, arXiv:2602.03626 (2026).** [S]
- Only real zeros, σ ≥ 1 − 1/(5 log q), for quadratic χ with q ≤ 10^10. This is not GRH on the line.

**What is uncovered** [I]:
- (a) Every primitive χ with q > 400 000, at any height. The one exception I found is Hiary et al.'s real character d = −1159523 for |t| ≤ 32.
- (b) For q ≤ 400 000, only heights above H_q. Because q·H_q ≈ 10^8 everywhere at the frontier, a single evaluation there costs several seconds.

**Cost [M].** `acb_dirichlet_l` uses Hurwitz decomposition, which is O(q).

| q | T | s/eval |
|---|---|---|
| 10007 | 100 | 0.24 |
| 10007 | 10^4 | 3.5 |
| 100003 | 100 | 1.0 |
| **400009** | **10** | **1.6** |
| 400009 | 295 | 3.6 |
| 1000003 | 10 | 3.4 |
| 4000037 | 10 | 10.9 |
| 1009 | 10^5 | 13.9 |
| 101 | 10^6 | 12.9 |

So nothing unverified among Dirichlet L-functions runs at ≲ 0.1 s/eval with stock Arb. Your own smoothed approximate functional equation (O(√(qT)) terms, about 630 for q ≈ 4·10^5 at small T) would probably cut this by about 10×. [I]

## 3. Degree 2 (elliptic curves, modular forms)

- **Booker, "Artin's conjecture, Turing's method, and the Riemann hypothesis", Exp. Math. 15 (2006) 385–408.** [S]
  - The rigorous Turing method for general L-functions.
  - GRH and Artin's conjecture for |t| ≤ 100 for the Artin L-functions of 3 S5 and 5 A5 quintic fields. The largest conductor is 36 081 072.
  - No elliptic curves.
- **Best, Bober, Booker, Costa, Cremona, Derickx, Lee, Lowry-Duda, Roe, Sutherland, Voight, "Computing classical modular forms", arXiv:2002.04717 (2021).**
  - §10.3 [S]: for every LMFDB classical modular form L-function, they "confirmed that no zeros are missing … that the Riemann Hypothesis holds for each L-function up to height b", using Büthe's method. They compute rigorously with Platt's interval-arithmetic `lfunc` library.
  - **b is not stated.**
  - The LMFDB API for 11.a (`2-11-1.1-c1-0-0`) stores zeros only up to t = 20.38. [M] My guess is that b is of that order, around 20–30. [I]
  - LMFDB reliability pages [S]: the zero lists are complete. The genus-2 knowl does not claim RH. https://www.lmfdb.org/L/2/11/1.1/c1/0/0/Reliability
  - Elliptic curves over Q are weight-2 newforms, so conductors in the LMFDB modular-forms range are presumably covered to the same low height. [I]
- **Hiary–Ireland–Kyi** (§0): 37.a1 for |t| ≤ 10, and Δ for |t| ≤ 84. [S]
- **Rubinstein's `lcalc` and Pari `lfun`** are not rigorous.
- I found **no published rigorous RH verification for any elliptic-curve L-function above roughly 20–30** in height. [I, moderate confidence: the Bristol group could do it easily and may have unpublished runs.]

**Arb route.** FLINT has no modular-form or elliptic-curve L-functions [S, FLINT `acb_dirichlet` docs]. However, the exact Lavrik/Cohen series is easy to implement with `acb.gamma_upper`:

> Λ(s) = Σ a_n [x_n^{−s} Γ(s, x_n) + ε x_n^{s−2} Γ(2−s, x_n)], with x_n = 2πn/√N.

I prototyped it [M]:
- a_n for 11.a come from η(z)²η(11z)² as an integer power series.
- The working precision is 128 + 2.3T bits, to absorb the e^{−πT/2} cancellation.
- Λ(1 + 6.3626138947i) = −1.3·10^−19 against values around 2.5·10^−4 nearby, so it matches the LMFDB first zero.
- Timings per evaluation: **0.045 s at T=100, 0.12 s at T=200, 0.25 s at T=300.**
- **Caveat:** my cutoff was crude. A rigorous tail bound is still needed. It is standard: |a_n| ≤ d(n)√n, and Γ(s,x) ≤ x^{σ−1}e^{−x}·(1+|s|/x)-type bounds.

## 4. Dedekind zeta functions

- **Tollis, "Zeros of Dedekind zeta functions in the critical strip", Math. Comp. 66 (1997) 1295–1321**, doi:10.1090/S0025-5718-97-00871-5. [S]
  - 50 cubic fields up to height 92 and 30 quartic fields up to height 40, rigorous.
  - The table lists **disc −23 (x³+x²−1) verified to 93.81** (121 zeros).
- **Booker 2006:** S5 and A5 quintic fields for |t| ≤ 100. [S]
- **Abelian fields** factor into Dirichlet L-functions, so they are covered by Platt for conductor ≤ 4·10^5. [I]
- I found nothing newer that extends non-abelian heights. [I, moderate confidence]
- For non-Galois cubic K, ζ_K = ζ · L(s, ρ), where ρ is a dihedral weight-1 newform. For disc −23 that form is 23.1.b.a = η(z)η(23z). [S/standard]

## 5. Recommended targets (ranked)

**1. L(E, s) for E = 11.a (X_0(11), conductor 11, rank 0, ε = +1), windows t ∈ [100, 110], then [200, 210] and [300, 310].**
- *Why unverified:*
  - Published rigorous coverage stops at a low, unstated b. LMFDB zeros end at 20.38 (Best et al. §10.3).
  - Hiary et al. did only 37.a1, |t| ≤ 10.
  - I found no paper reaching 100. [I; moderate confidence]
- *Cost* [M]: 0.05–0.25 s per Λ evaluation. There are about 1.5 zeros per unit at T = 200, so about 15 zeros per window and a few hundred evaluations, i.e. minutes.
- *Prime side:* Λ_E(p^k) = (α_p^k + β_p^k) log p, from a_p via the η-product. This is exact and cheap.
- *Interest:* Atlas's first degree-2 or motivic L-function. It also tests the Γ_C(s)·N^{s/2} archimedean terms.
- Optional follow-up: 37.a1 at t ∈ [10, 20] and above. That extends Hiary et al. directly and shows the method handles a central zero (rank 1).

**2. ζ_K for the cubic field of discriminant −23 (x³ − x − 1), window t ∈ [94, 104], then [100, 200].**
- This is ζ · L(s, 23.1.b.a). The zeta factor at these heights is covered by Platt–Trudgian.
- The new content is the weight-1 form, with Λ(s) = (√23/2π)^s Γ(s) L(s) and s ↦ 1−s.
- *Why unverified:* Tollis's published frontier is 93.81 for this field. LMFDB's b for 23.1.b.a is unstated but presumably low. [I]
- *Cost:* the same code as target 1 with a different gamma shift, about 0.05–0.15 s/eval. [I, based on the 11.a timings]
- *Interest:* the cleanest "beyond a published record" claim, extending Tollis 1997 for the smallest non-abelian number field. It reuses the target-1 code.

**3. L(s, χ) for a complex (non-real) primitive χ mod q = 400 009 (prime, the first prime above Platt's bound), e.g. Conrey index 2, window t ∈ [0, 10], then [0, 30].**
- *Why unverified:* Platt stops at q ≤ 400 000. Hiary et al. treat only one real character. Lu–Zaman–Zhao cover only real zeros of quadratic χ. [S]
- Using a complex character avoids overlap with the quadratic-character literature.
- *Cost* [M]: **1.6 s/eval** with stock `acb_dirichlet_l`. That is above the 0.1 s target. About 21 zeros in [0, 10] means roughly 5–15 min.
- *Interest:* moderate. It is one point just outside a 3·10^10-function census. It does show that Atlas reaches past Platt's modulus box.
- It is only worth scaling to many characters after an O(√(qT)) AFE is written.

**Not recommended now:**
- Zeta, which is out of reach.
- Dirichlet at q ≤ 4·10^5 above H_q: ≥ 3 s/eval at the frontier for marginal novelty.
- Booker's quintic Artin examples: conductor 3.6·10^7 in degree 6, too costly.

## References
- arXiv:2004.09765 / doi:10.1112/blms.12460 (Platt–Trudgian)
- arXiv:1305.3087 / Math. Comp. 85 (2016) 3009 (Platt, GRH)
- https://people.maths.bris.ac.uk/~madjp/thesis5.pdf (Platt thesis)
- arXiv:1802.00085 (BMOR)
- arXiv:2408.00187 (Hiary–Ireland–Kyi)
- arXiv:1308.6704 (Büthe)
- arXiv:2002.04717 (Best et al., §9.2 and §10.3)
- Exp. Math. 15 (2006) 385, https://projecteuclid.org/euclid.em/1175789775 (Booker)
- doi:10.1090/S0025-5718-97-00871-5 (Tollis)
- arXiv:2602.03626 (Lu–Zaman–Zhao)
- https://www.lmfdb.org/L/2/11/1.1/c1/0/0/Reliability
- https://flintlib.org/doc/acb_dirichlet.html

Prototype scripts are in the session scratchpad only (`t*.py`, `ec.py`). They are not in the repo.
