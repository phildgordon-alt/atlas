# crosscheck_11a — pre-registered predictions (2026-10-07, written before the full [0, 300] run)

Method: rigorous argument-principle counter for Lambda(s, 11.a) (ap_lambda.py, lam_rot.py, run.py in this directory), independent of
the Atlas certificate code: own coefficients (point counting on 11a1), own Lambda evaluator (rotated complex-A split, A = e^{i theta}),
own sup bound (Lemma B), discrete-Cauchy Taylor models; piece test = zeta_argprinciple._test_piece (sha-pinned). No zero list is input.
Box: arithmetic Re s in [7/16, 25/16] (analytic [-1/16, 17/16]), t in [0, 300]; bottom edge on the real axis (certified zero-free).
Already run before this file (development tests, allowed to inform the code, not the predictions): [0, 10] -> N = 2; [0, 30] -> N = 18,
18 symmetric leaves with N = 1, Z-sign consistent.

Predictions for run.py 0 300 runs/full:
 P1. Full-box count N = 388 (certified integer enclosure).
 P2. Map-free bisection ends with every leaf N <= 1 (all 388 zeros on the line and simple); sum of leaves = 388; Z-sign check consistent.
 P3. Diagnostic comparison (done only after P1/P2 are recorded): the 388 Atlas sign-change intervals (deg2/runs/contig/c_*/intervals.json,
     restricted to [0, 300], deduplicated) are in 1-1 correspondence with the 388 N = 1 leaves (each leaf contains exactly one interval).
 P4. Negative control (a_2 := -1 instead of -2): over [0, 30] the counter returns a count different from 18, or fails to certify
     (non-integer winding / failed pieces / bisection not ending in N <= 1 / Z-sign inconsistency).
Failure of any of P1–P3 is reported as such, not explained away.
