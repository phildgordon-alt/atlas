# crosscheck_11a — RESULTS (2026-10-07), scored against PREDICTIONS.md (sha 6fa1d591…, verified unchanged)

Independent rigorous argument-principle count for Λ(s, 11.a), box Re s_an ∈ [−1/16, 17/16], 0 ≤ t ≤ 300 (method: THEORY.md).
Code at pre-registration: CODE_AT_PREREG.sha256. ap_lambda.py and lam_rot.py are unchanged since then. run.py gained only the `--theta0`
control flag after the full run.

| | prediction | outcome |
|---|---|---|
| P1 | N = 388 | **MET**: full-box winding enclosure [388.000000 ± 3.0e−7]; all 4 edges certified zero-free (t = 0 real-axis edge included) |
| P2 | every leaf N ≤ 1 | **MET**: 416 symmetric leaves, 388 with N = 1, 28 with N = 0. Additivity held at every cut, with 0 failed cuts. The Z-sign check is consistent on all 416 leaves. Smallest N = 1 leaf: 0.146 |
| P3 | 1–1 with Atlas | **MET**: 854 raw Atlas intervals give 397 distinct, of which 388 lie in [0, 300]. Each N = 1 leaf contains exactly one; each N = 0 leaf contains none; no interval straddles a cut or the range ends (runs/full/compare.json) |
| P4 | negative control fails or differs | **MET**: see below |

Negative control (a_2 := −1), on [0, 30], where the true count is 18:
* Default per-patch rotation: **fails**, non-integer winding −0.151.
* Fixed A = 1 (a single entire function): **differs**, N = 0. 300 grid samples of its Z show no sign change.

The positive control of that fixed-A mode with the true a_n gives N = 18, with 18 leaves of N = 1.

Timings (nice 19, shared machine, one process, max RSS 31 MB):
* full box: 2836 s (302 patches, 14 496 Λ evaluations);
* bisection: 4449 s;
* total: 7284 s (717 patches, 34 416 evaluations, 26 321 certified pieces, 0 inner failures).

Conclusion: an independent method confirms that L(s, 11.a) has exactly 388 zeros with 0 ≤ t ≤ 300 (counted with multiplicity, any real
part), and that all of them are on the critical line and simple. The proof uses no sign-change credits, no explicit formula and no Lemma 2.
Simplicity and on-line-ness come from N = 1 in boxes symmetric about the line.

Trusted:
* Arb/FLINT;
* modularity of 11a1 (level 11, ε = +1);
* Hasse's bound;
* the sha-pinned `_test_piece`.
