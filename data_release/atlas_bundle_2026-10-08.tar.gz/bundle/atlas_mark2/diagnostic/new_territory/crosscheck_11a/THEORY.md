# crosscheck_11a — argument-principle cross-check of "all zeros of L(s, 11.a) with 0 <= t <= 300 are on the line and simple"

Arithmetic normalisation throughout: Λ(s) = (√11/2π)^s Γ(s) L(E, s), E = 11a1 (y² + y = x³ − x² − 10x − 20), Λ(s) = Λ(2 − s)
(root number +1), critical line Re s = 1. Analytic σ_an = σ − 1/2.

## 1. Evaluator (lam_rot.py) — independent of deg2/lfun.py

**Coefficients.** a_p = p − #E_aff(F_p) (p ≠ 11), a_11 = +1, Hecke recursion, multiplicativity. They agree with deg2/forms.py's
η²(z)η²(11z) coefficients for n ≤ 6000. This is a check, not an input.

**Rotated split.** Let F(y) = Σ a_n e^{−x_n y}, with x_n = 2πn/√11. F is analytic on Re y > 0, and by analytic continuation of the Fricke relation, F(1/y) = y² F(y).
Λ(s) = ∫_0^∞ F(y) y^{s−1} dy. F decays exponentially as y → ∞ inside any closed sub-sector |arg y| ≤ θ < π/2. It also decays as y → 0
(via F(1/y) = y²F(y)). So the path can be rotated onto the ray arg y = θ. Split it at A = e^{iθ} and map the (0, A) part by y ↦ 1/y. Then integrate termwise:

  Λ(s) = Σ a_n [ x_n^{−s} Γ(s, A x_n) + x_n^{s−2} Γ(2 − s, x_n/A) ].

Here x^{−s}Γ(s, Ax) = ∫ over the ray from A to ∞ of v^{s−1}e^{−xv} dv, with principal branches. A = 1 is the classical series used by deg2/lfun.py.

We use θ = sign(t)(π/2 − min(π/2, 20/|t|)). For true data the value does not depend on θ. A wrong N, ε or a_n makes it depend on θ.

**Lemma B (bounds).** Put v = Au, u ≥ 1. Then |v^{s−1}| = u^{σ−1}e^{−θt} and |e^{−xv}| = e^{−cxu}, with c = cos θ. Likewise for the second term, along the ray 1/A. Hence:

* (i) Per-term bound: |term_n| ≤ e^{−θt} |a_n| [(cx)^{−σ}Γ(σ, cx) + (cx)^{−(2−σ)}Γ(2−σ, cx)]. This increases in σ (first part) and in 2 − σ (second part), and decreases in t when θ > 0. So taking σ_max, σ_min and t_min over a rectangle gives a rigorous **sup bound M** for |Λ| on any disc. The bound involves only real incomplete gamma functions and no cancellation (`sup_bound`).
* (ii) Tail: ∫_1^∞ u^{a−1}e^{−yu} du ≤ e^{−y}/(y − max(0, a−1)), and |a_n| ≤ d(n)√n ≤ 2n. With a geometric ratio bound, this gives a rigorous tail for n > M_terms. The tail is added as a ball radius (`_tail_bound`).

**Accuracy and cross-checks.** The terms have size about e^{−θt} and Λ has size about e^{−π|t|/2}, so the cancellation is about e^{20}. This needs only about 190 bits at t = 300, against 818 bits for A = 1.

Arb's Γ(s, z) loses accuracy for |z| ≈ |s|. Each such term is therefore recomputed, inputs included, at doubled precision until its relative radius is below 2^{−(prec−40)} (`_term`).

Agreement with deg2/lfun.py (A = 1 and A = 1.2), and with θ built from 12 in place of 20, holds at 1e−23 to 1e−28 relative. It was checked at s = 1+5i, 1.3+50.5i, 0.5+100i, 1+300i, 1.5625+300i, 0.4375+150.3i, 1−20i and 1. All the balls overlap.

## 2. Counter (ap_lambda.py)

The zeta counter takes Taylor jets from Arb's ζ series. No such series exists for Λ, so jets are replaced by a **discrete-Cauchy Taylor model** on each patch {m + ux : |x| ≤ r}, with R = 4r:

* Take M ≥ sup_{D(m,R)}|Λ| from Lemma B.
* Take NS = 48 samples f_j = Λ(s_j*), where s_j* is the float midpoint of m + r ω^j. Then |Λ(m + rω^j) − f_j| ≤ |δ_j| · M/((R−r)/2), by Cauchy on D(m, (R+r)/2). This radius is added.
* Set ĉ_k = (1/NS) Σ f_j ω^{−jk} r^{−k}. Then ĉ_k = c_k + Σ_{l≥1} c_{k+l·NS} r^{l·NS}, so |ĉ_k − c_k| ≤ (M/R^k) q^{NS}/(1−q^{NS}) with q = 1/4. This radius is added.
* Truncate at K = 40, which gives the tail ε = M q^{K+1}/(1−q).

Pieces are then certified by `zeta_argprinciple._test_piece`, imported read-only with its sha pinned. On a piece, the image is contained in a segment plus a disc. If that set misses 0, then Λ ≠ 0 on the piece and the continuous arg change equals the principal Arg(f(b)/f(a)), which is enclosed by Arb.

Patches:
* vertical edges at σ = 7/16 and σ = 25/16: fixed grid of width 2 (r = 1);
* each horizontal line t = c: one patch over [7/16, 25/16] (r = 9/16).

Sub-segments are computed exactly. The endpoints are dyadic, so arb differences are exact at 160 bits, and the contour closes exactly. The count of a box is (ΔH(a) + ΔV_right − ΔH(b) − ΔV_left)/2π. It is accepted only if the enclosure contains exactly one integer.

Each patch uses a single θ, for its sup bound and for all its samples. The model is therefore a rigorous model of one function f_θ, and for the true coefficients f_θ = Λ.

## 3. Why the box catches every zero, and the edges

* For σ_an > 1, the Euler product converges absolutely (Hasse: |α_p| = |β_p| = 1), and Γ has no zeros. So Λ ≠ 0 there.
* For σ_an < 0, Λ ≠ 0 by the functional equation.
* The box σ_an ∈ [−1/16, 17/16] therefore contains every zero with 0 ≤ t ≤ 300.
* The edges σ_an = −1/16 and 17/16 are zero-free by the above.
* The bottom edge is the real-axis segment t = 0. The counter certifies it zero-free, so there is no real zero in the strip; this is consistent with L(E, 1) ≠ 0 and root number +1.
* The top edge t = 300 is certified zero-free. The count is therefore exactly #{zeros with 0 ≤ t ≤ 300}, with multiplicity.

## 4. On the line and simple

Real coefficients and ε = +1 give Λ(2 − s̄) = conj Λ(s). So ρ ↦ 2 − ρ̄ maps zeros to zeros, at the same ordinate and with the same multiplicity.

Every bisection box is [7/16, 25/16] × [a, b], which is symmetric about Re s = 1. In a box with N = 1:
* the unique zero is fixed by the reflection, so Re ρ = 1;
* N counts multiplicity, so the zero is simple.

Bisection is map-free: cuts are placed at midpoints, with fixed offsets if a cut cannot be certified, and N(lo) + N(hi) = N(parent) is asserted.

**Consistency check (not needed for the proof).** For every leaf, the signs of Z(t) = e^{πt/2}Λ(1 + it) at its ends must be opposite if N = 1 and equal if N = 0.

## 5. Trusted

* Arb/FLINT (python-flint 0.9.0): gamma_upper, exp, arithmetic.
* 11a1 is modular, with L(E, s) = L(f, s), level 11, functional equation as stated with ε = +1.
* Hasse's bound.
* zeta_argprinciple._test_piece (sha-pinned).
