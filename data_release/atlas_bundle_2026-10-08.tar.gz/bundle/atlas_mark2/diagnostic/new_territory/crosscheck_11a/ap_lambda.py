"""Rigorous argument-principle zero counter for Lambda(s, 11.a) (THEORY.md).

Arithmetic normalisation: Lambda(s) = Lambda(2 - s), critical line Re s = 1, critical strip 1/2 <= Re s <= 3/2.
Count box: Re s in [S0, S1] = [7/16, 25/16] (analytic -1/16 .. 17/16), exact dyadics, symmetric about Re s = 1.

Patch model (replaces the zeta counter's Arb jet, which does not exist for Lambda):
  disc D(m, R), R = 4r, segment piece {m + u x : |x| <= r}.  M >= sup_{D(m,R)} |Lambda| from lam_rot.sup_bound (Lemma B, real
  incomplete-gamma sums, no cancellation).  Samples f_j = Lambda(m + r w^j), w = e^{2 pi i/NS}, j < NS (Arb balls containing the
  exact sample points; lam_rot.Lam with one rotation angle theta per patch).  Discrete Cauchy coefficients
      chat_k = (1/NS) sum_j f_j w^{-jk} r^{-k} = c_k + sum_{l>=1} c_{k+l NS} r^{l NS},  |c_j| <= M / R^j,
  so |chat_k - c_k| <= (M / R^k) q^NS / (1 - q^NS), q = r/R; this radius is added to chat_k.  Taylor tail beyond K:
  |sum_{k>K} c_k (u x)^k| <= M (r/R)^{K+1} / (1 - r/R) =: eps.  So Lambda(m + u x) = sum_{k<=K} a_k x^k + E(x), |E| <= eps, with
  a_k = chat_k u^k (balls).  Pieces are then certified by the zeta counter's own _test_piece (imported, sha-pinned), which
  proves Lambda != 0 on the piece and returns the continuous arg change.
"""
import sys, os, math, json, time, hashlib
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
AP_DIR = '/Users/kiosk/atlas_mark2/diagnostic/usefulness_tests/argprinciple'
AP_SHA = 'cc5079d8f2e48841f244177e64e2dbb0c5c311c56d4df201514e3c74c18128d6'
assert hashlib.sha256(open(AP_DIR + '/zeta_argprinciple.py', 'rb').read()).hexdigest() == AP_SHA
sys.path.insert(0, AP_DIR); sys.path.insert(0, HERE)
import zeta_argprinciple as ZA      # only _shift and _test_piece are used
from flint import arb, acb, ctx
import lam_rot as L

S0, S1 = 0.4375, 1.5625            # 7/16, 25/16
WORK_PREC = 160
K_ORD = 40
NS = 48
R_FAC = 4
INNER_DEPTH = 20
INNER_MAX = 4000


def ser(x):
    """rigorous serialisation of an arb (decimal mid/rad/exp; the reconstruction encloses x)."""
    m, r, e = x.mid_rad_10exp(70)
    return [str(m), str(r), int(e)]


def deser(v):
    m, r, e = v
    old = ctx.prec; ctx.prec = 400
    try:
        b = (arb(int(m)) + arb(0, int(r))) * arb(10) ** int(e)
    finally:
        ctx.prec = old
    return b


class Stats:
    def __init__(self):
        self.evals = 0; self.patches = 0; self.pieces = 0; self.inner_fail = 0; self.t0 = time.time(); self.eval_s = 0.0

    def d(self):
        return dict(evals=self.evals, patches=self.patches, pieces=self.pieces, inner_fail=self.inner_fail,
                    eval_s=round(self.eval_s, 1), wall_s=round(time.time() - self.t0, 1))


def patch_theta(tc, R):
    return 0.0 if tc - R <= 0 else L.theta_for(tc)


class PatchModel:
    """Taylor model of g(x) = Lambda(m + u x), |x| <= r, real x. m = (mr, mi) exact floats, u in {1, i}."""

    def __init__(self, C, mr, mi, u, r, stats, theta=None):
        self.key = (mr, mi, u, r)
        R = R_FAC * r
        th = patch_theta(mi, R) if theta is None else theta
        self.theta = th
        prec = max(WORK_PREC, L.prec_for(abs(mi) + R, theta=th) + 24)
        Mb = L.sup_bound(C, mr - R, mr + R, mi - R, mi + R, th)
        old = ctx.prec; ctx.prec = prec
        try:
            m = acb(arb(mr), arb(mi))
            ws = [acb(arb(2 * j) / NS).exp_pi_i() for j in range(NS)]
            f = []
            t0 = time.time()
            Mx0 = arb(Mb)
            for j in range(NS):
                sj = m + arb(r) * ws[j]                       # ball containing the exact sample point
                sm = acb(sj.real.mid(), sj.imag.mid())         # exact point (midpoint)
                dlt = abs(sj - sm).upper()                     # |exact - midpoint| <= dlt
                v = L.Lam(C, sm, th, prec)
                # |Lambda(exact) - Lambda(mid)| <= dlt * sup_{D(m, (r+R)/2)} |Lambda'| <= dlt * M / ((R - r)/2)  (Cauchy)
                e = (arb(dlt) * Mx0 / ((arb(R) - arb(r)) / 2)).upper()
                f.append(v + acb(arb(0, e), arb(0, e)))
            stats.evals += NS; stats.eval_s += time.time() - t0
            Mx = arb(Mb)
            q = arb(r) / arb(R)
            alias = Mx * q ** NS / (1 - q ** NS)
            uu = acb(1) if u == 1 else acb(0, 1)
            a = []
            uk = acb(1); rk = arb(1); Rk = arb(1)
            for k in range(K_ORD + 1):
                s = acb(0)
                for j in range(NS):
                    s += f[j] * ws[(-j * k) % NS]
                ck = s / NS / rk
                er = (alias / Rk).upper()
                ck = ck + acb(arb(0, er), arb(0, er))
                a.append(ck * uk)
                uk *= uu; rk *= r; Rk *= R
            eps = (Mx * q ** (K_ORD + 1) / (1 - q)).upper()
        finally:
            ctx.prec = old
        self.a = a; self.eps = eps; self.r = r; self.M = Mb
        # diagnostic: |c_0| vs eps
        self.rel_eps = float(eps / abs(a[0]).mid()) if abs(a[0]).mid() != 0 else float('inf')
        stats.patches += 1

    def to_json(self):
        return dict(key=list(self.key), theta=self.theta, eps=ser(arb(self.eps)), M=ser(arb(self.M)),
                    a=[[ser(c.real), ser(c.imag)] for c in self.a])

    @staticmethod
    def from_json(d):
        p = PatchModel.__new__(PatchModel)
        p.key = tuple(d['key']); p.theta = d['theta']; p.r = p.key[3]
        p.eps = deser(d['eps']).upper(); p.M = deser(d['M'])
        p.a = [acb(deser(re), deser(im)) for re, im in d['a']]
        p.rel_eps = None
        return p

    def delta_arg(self, x0, x1, stats):
        """certified arg change of g along x0 -> x1 (x0 < x1 within [-r, r]); None on failure."""
        old = ctx.prec; ctx.prec = WORK_PREC
        try:
            tot = arb(0); stack = [(arb(x0), arb(x1), 0)]; cnt = 0
            while stack:
                y0, y1, dep = stack.pop(); cnt += 1
                yr = (y1 - y0) / 2; ym = y0 + yr
                b = ZA._shift(self.a, ym)
                d = ZA._test_piece(b, yr, self.eps)
                if d is not None:
                    tot += d; stats.pieces += 1; continue
                if dep >= INNER_DEPTH or cnt > INNER_MAX:
                    stats.inner_fail += 1
                    return None
                stack.append((y0, ym, dep + 1)); stack.append((ym, y1, dep + 1))
            return tot
        finally:
            ctx.prec = old


class Counter:
    def __init__(self, C, T_lo, T_hi, ckpt=None, vr=0.5, log=print):
        self.C = C; self.vr = vr; self.T_lo = T_lo; self.T_hi = T_hi
        self.stats = Stats(); self.models = {}; self.log = log
        self.ckpt = ckpt
        if ckpt and os.path.exists(ckpt):
            for line in open(ckpt):
                d = json.loads(line); p = PatchModel.from_json(d); self.models[p.key] = p
            log(f'loaded {len(self.models)} patch models from checkpoint')

    def model(self, mr, mi, u, r):
        key = (mr, mi, u, r)
        if key not in self.models:
            p = PatchModel(self.C, mr, mi, u, r, self.stats)
            self.models[key] = p
            if self.ckpt:
                with open(self.ckpt, 'a') as fh: fh.write(json.dumps(p.to_json()) + '\n')
        return self.models[key]

    def vert(self, sig, a, b):
        """certified arg change of Lambda along sig + i t, t: a -> b (a < b), via the fixed patch grid of width 2 vr."""
        w = 2 * self.vr
        j0 = int(math.floor((a - self.T_lo) / w)); j1 = int(math.ceil((b - self.T_lo) / w))
        tot = arb(0)
        for j in range(j0, j1):
            c = self.T_lo + (j + 0.5) * w
            lo = max(a, c - self.vr); hi = min(b, c + self.vr)
            if hi <= lo: continue
            p = self.model(sig, c, 'i', self.vr)
            d = p.delta_arg(arb(lo) - arb(c), arb(hi) - arb(c), self.stats)   # exact (dyadic) at WORK_PREC
            if d is None: return None
            tot += d
        return tot

    def horiz(self, t):
        """certified arg change along S0 + i t -> S1 + i t (rightwards)."""
        r = (S1 - S0) / 2
        p = self.model(1.0, t, 1, r)
        return p.delta_arg(-r, r, self.stats)

    def count(self, a, b):
        hb = self.horiz(a)
        if hb is None: return None, 'bottom'
        ht = self.horiz(b)
        if ht is None: return None, 'top'
        vr = self.vert(S1, a, b)
        if vr is None: return None, 'right'
        vl = self.vert(S0, a, b)
        if vl is None: return None, 'left'
        w = (hb + vr - ht - vl) / (2 * arb.pi())
        n = round(float(w.mid()))
        if w.rad() < 0.5 and w.contains(n) and not w.contains(n - 1) and not w.contains(n + 1):
            return n, str(w)
        return None, 'nonint ' + str(w)
