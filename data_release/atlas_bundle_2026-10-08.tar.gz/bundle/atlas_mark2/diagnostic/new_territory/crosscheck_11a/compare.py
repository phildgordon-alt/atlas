"""Diagnostic comparison (run only after the count/bisection are recorded): Atlas sign-change intervals vs the N = 1 leaves."""
import json, glob, sys, os
HERE = os.path.dirname(os.path.abspath(__file__))
res = json.load(open(sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, 'runs/full/result.json')))
T_LO, T_HI = res['T_LO'], res['T_HI']
iv = []
for f in sorted(glob.glob('/Users/kiosk/atlas_mark2/diagnostic/new_territory/deg2/runs/contig/c_*/intervals.json')):
    iv += [tuple(x) for x in json.load(open(f))['intervals']]
iv.sort()
dedup = []
for a, b in iv:
    if dedup and a <= dedup[-1][1] + 1e-6: dedup[-1] = (min(dedup[-1][0], a), max(dedup[-1][1], b)); continue
    dedup.append((a, b))
inside = [x for x in dedup if x[0] >= T_LO and x[1] <= T_HI]
edge = [x for x in dedup if not (x[0] >= T_LO and x[1] <= T_HI) and x[1] >= T_LO and x[0] <= T_HI]
leaves = res['leaves']
ones = [l for l in leaves if l[2] == 1]
per_leaf = [[x for x in inside if l[0] < x[0] and x[1] < l[1]] for l in leaves]
straddle = [x for x in inside if not any(l[0] < x[0] and x[1] < l[1] for l in leaves)]
bad = [(l, p) for l, p in zip(leaves, per_leaf) if len(p) != l[2]]
out = dict(atlas_raw=len(iv), atlas_distinct=len(dedup), atlas_in_range=len(inside), atlas_straddling_range_ends=edge,
           counter_N=res['N_total'], counter_N1_leaves=len(ones), leaves=len(leaves),
           leaves_with_mismatch=bad, atlas_intervals_straddling_a_cut=straddle,
           one_to_one=(not bad and not straddle and len(inside) == len(ones)),
           min_leaf_width_N1=min(l[1] - l[0] for l in ones) if ones else None)
json.dump(out, open(os.path.join(os.path.dirname(sys.argv[1]) if len(sys.argv) > 1 else os.path.join(HERE, 'runs/full'), 'compare.json'), 'w'), indent=1)
print(json.dumps({k: v for k, v in out.items()}, indent=1))
