"""Independent evaluator of Lambda(s, 11.a) for the argument-principle cross-check (crosscheck_11a).

Coefficients: a_n computed HERE by point counting on E: y^2 + y = x^3 - x^2 - 10x - 20 (Cremona 11a1, conductor 11),
a_p = p - #E_aff(F_p) for p != 11, a_11 = +1 (split multiplicative), a_{p^{j+1}} = a_p a_{p^j} - p a_{p^{j-1}} (good p),
a_{11^j} = 1, multiplicative.  (Cross-checked against deg2/forms.py's eta-product coefficients in selftest.)

Arithmetic normalisation (weight k = 2, N = 11, eps = +1):
  Lambda(s) = (sqrt N / 2pi)^s Gamma(s) L(E, s) = Lambda(2 - s);  analytic centre Re s = 1.

Rotated split (complex A = e^{i theta}, |theta| < pi/2):  with x_n = 2 pi n / sqrt N,
  Lambda(s) = sum_n a_n [ x_n^{-s} Gamma(s, A x_n) + eps x_n^{s-k} Gamma(k - s, x_n / A) ]                      (R)
Proof sketch (THEORY.md section 1): F(y) = sum a_n e^{-x_n y} is analytic on Re y > 0 with F(1/y) = eps y^k F(y); rotate the Mellin
integral Lambda(s) = int_0^inf F(y) y^{s-1} dy onto the ray arg y = theta, split at y = A, invert the (0, A) part; termwise
  x^{-s} Gamma(s, A x) = int_{ray A}^{inf} v^{s-1} e^{-x v} dv   (principal branches; x > 0).
With v = A u (u >= 1): |v^{s-1}| = u^{sigma-1} e^{-theta t},  |e^{-x v}| = e^{-c x u},  c = cos theta.  Hence for every n (Lemma B):
  |x^{-s} Gamma(s, A x)|          <= e^{-theta t} int_1^inf u^{sigma-1} e^{-c x u} du   = e^{-theta t} (cx)^{-sigma} Gamma(sigma, cx)
  |x^{s-k} Gamma(k-s, x/A)|       <= e^{-theta t} (cx)^{-(k-sigma)} Gamma(k - sigma, cx)
and, when c x > c1 = max(0, sigma - 1) (resp. c2 = max(0, k - sigma - 1)), int_1^inf u^{a-1} e^{-y u} du <= e^{-y} / (y - max(0, a-1)).
theta = sign(t)(pi/2 - phi), phi = min(pi/2, PHI / |t|): the terms are ~ e^{-theta t}, Lambda ~ e^{-pi |t|/2}, so the cancellation is only
~ e^{PHI} (PHI = 20 by default), instead of e^{pi t/2} for A = 1.  The value of (R) does not depend on theta (true form); a wrong N, eps
or a_n makes it theta-dependent, which the evaluator cross-check (selftest) detects.
"""
import math
from flint import arb, acb, ctx

N_LEVEL = 11
K_WT = 2
EPS = 1
PHI = 20.0
SQN = math.sqrt(N_LEVEL)


def point_count_coeffs(M):
    """a_1..a_M for 11a1 by point counting (independent of the eta product)."""
    sieve = bytearray([1]) * (M + 1); sieve[0:2] = b'\x00\x00'
    for i in range(2, int(M ** 0.5) + 1):
        if sieve[i]: sieve[i * i::i] = bytearray(len(sieve[i * i::i]))
    primes = [i for i in range(M + 1) if sieve[i]]
    ap = {}
    for p in primes:
        if p == 11: ap[p] = 1; continue
        # count affine solutions of y^2 + y = f(x) mod p
        if p == 2:
            cnt = sum(1 for x in range(2) for y in range(2) if (y * y + y - (x ** 3 - x * x - 10 * x - 20)) % 2 == 0)
        else:
            # y^2 + y = f  <=>  (2y+1)^2 = 4f + 1 ; number of y = 1 + legendre(4f+1)
            cnt = 0
            for x in range(p):
                d = (4 * (x ** 3 - x * x - 10 * x - 20) + 1) % p
                if d == 0: cnt += 1
                else: cnt += 2 if pow(d, (p - 1) // 2, p) == 1 else 0
        ap[p] = p - cnt
    a = [0] * (M + 1); a[1] = 1
    # prime powers
    pp = {}
    for p in primes:
        q = p; prev2, prev1 = 1, ap[p]; j = 1
        while q <= M:
            pp[q] = prev1
            if p == 11: nxt = prev1 * ap[p]
            else: nxt = ap[p] * prev1 - p * prev2
            prev2, prev1 = prev1, nxt; q *= p; j += 1
    spf = list(range(M + 1))
    for p in primes:
        for m in range(p * p, M + 1, p):
            if spf[m] == m: spf[m] = p
    for n in range(2, M + 1):
        p = spf[n]; q = p; m = n // p
        while m % p == 0: m //= p; q *= p
        a[n] = pp[q] * a[m]
    return a


def theta_for(t, phi_const=PHI):
    if abs(t) < 1e-300: return 0.0
    phi = min(math.pi / 2, phi_const / abs(t))
    return math.copysign(math.pi / 2 - phi, t)


def prec_for(t, phi_const=PHI, theta=None):
    th = theta_for(t, phi_const) if theta is None else theta
    canc = (math.pi / 2 - abs(th)) * abs(t)          # log of cancellation factor
    return 128 + int(1.45 * canc) + 32


def nterms(t, theta, sig_lo, sig_hi, extra=60):
    c = math.cos(theta); x0 = 2 * math.pi / SQN
    target = (math.pi / 2 - abs(theta)) * abs(t) + extra * math.log(2) + 12 + 2 * max(0.0, -sig_lo) + 2 * max(0.0, sig_hi)
    return int(target / (c * x0)) + 5


class Coeffs:
    def __init__(self, M, a=None):
        self.a = point_count_coeffs(M) if a is None else a
        self.M = len(self.a) - 1


def _tail_bound(M, theta, sig_lo, sig_hi, t_lo_abs):
    """Lemma B tail: sum_{n>M} 2 n e^{-|theta| |t|_min} [e^{-c x}/(c x - c1) + e^{-c x}/(c x - c2)] (|a_n| <= d(n) sqrt n <= 2n), arb."""
    k = K_WT; c = math.cos(theta); x0 = 2 * math.pi / SQN
    c1 = max(0.0, sig_hi - 1); c2 = max(0.0, k - sig_lo - 1)
    m = M + 1
    assert c * x0 * m > max(c1, c2) + 1
    q = (1 + 1.0 / m) * math.exp(-c * x0)
    assert q < 0.95
    X = arb(2) * arb.pi() / arb(N_LEVEL).sqrt() * m * arb(c)       # c rounded: (c rounding is ~1e-16 relative; absorbed below)
    X = X * (1 - arb(2) ** -40)                                       # lower it slightly (safe direction for e^{-X}/(X - c))
    e = (-X).exp()
    term = 2 * arb(m) * (e / (X - c1) + e / (X - c2))
    Q = arb(q) * (1 + arb(2) ** -30)
    return term / (1 - Q) * (-arb(abs(theta)) * arb(t_lo_abs) * (1 - arb(2) ** -40)).exp()


def _term(s, theta, n, prec):
    """x^{-s} Gamma(s, A x) + eps x^{s-k} Gamma(k - s, x / A), x = 2 pi n / sqrt N, A = e^{i theta}, as an Arb ball.
    Everything (A, x, s-derived quantities) is recomputed at a raised precision whenever Arb's incomplete gamma loses accuracy
    (this happens for |A x| ~ |s|); the result is accepted at the first precision giving relative radius < 2^-(prec-40)."""
    p = prec; tgt = arb(2) ** (-(prec - 40))
    while True:
        old = ctx.prec; ctx.prec = p
        try:
            th = arb(theta); A = acb(th.cos(), th.sin()); Ai = acb(th.cos(), -th.sin())
            x = acb(2 * arb.pi() * n / arb(N_LEVEL).sqrt())
            ss = acb(s); ks = K_WT - ss
            g = (A * x).gamma_upper(ss) * x ** (-ss) + EPS * (Ai * x).gamma_upper(ks) * x ** (-ks)
        finally:
            ctx.prec = old
        if g.is_finite():
            ag = abs(g)
            if ag.rad() < tgt * ag.mid() or p >= 16 * prec: return g
        elif p >= 16 * prec: return g
        p *= 2


def Lam(C, s, theta, prec, M=None):
    """acb enclosure of Lambda(s) for s an acb (point or tiny ball), using the rotated split with A = e^{i theta}."""
    old = ctx.prec; ctx.prec = prec
    try:
        s = acb(s)
        sig_lo = float(s.real.lower()); sig_hi = float(s.real.upper())
        t_abs_lo = max(0.0, float(abs(s.imag).lower()))
        tm = float(s.imag.mid())
        if theta != 0: assert math.copysign(1, theta) == math.copysign(1, tm) or abs(tm) < 1e-300
        if M is None: M = nterms(tm, theta, sig_lo, sig_hi)
        assert M <= C.M, ('need more coefficients', M, C.M)
        th = arb(theta)
        A = acb(th.cos(), th.sin()); Ai = acb(th.cos(), -th.sin())
        x0 = 2 * arb.pi() / arb(N_LEVEL).sqrt()
        ks = K_WT - s
        tot = acb(0)
        a = C.a
        for n in range(1, M + 1):
            if a[n] == 0: continue
            tot += a[n] * _term(s, theta, n, prec)
        tb = _tail_bound(M, theta, sig_lo, sig_hi, t_abs_lo).upper()
        tot = tot + acb(arb(0, tb), arb(0, tb))
    finally:
        ctx.prec = old
    return tot


def _upper_gamma_real(a, y):
    """arb upper bound of int_1^inf u^{a-1} e^{-y u} du = y^{-a} Gamma(a, y) (y > 0, real a)."""
    v = acb(arb(y)).gamma_upper(acb(arb(a))).real * arb(y) ** (-arb(a))
    return v


def sup_bound(C, sig_lo, sig_hi, t_lo, t_hi, theta, prec=96):
    """Rigorous upper bound (arb) for sup |Lambda(s)| over sigma in [sig_lo, sig_hi], t in [t_lo, t_hi] (Lemma B), for the
    rotated split with this theta (theta must have the sign of every t in the rectangle, or be 0)."""
    old = ctx.prec; ctx.prec = prec
    try:
        if theta > 0: assert t_lo >= 0
        if theta < 0: assert t_hi <= 0
        tmin = t_lo if theta > 0 else (-t_hi if theta < 0 else 0.0)
        c = math.cos(theta)
        cA = arb(c) * (1 - arb(2) ** -40)      # lower bound of cos theta (smaller c -> larger bound: safe)
        x0 = 2 * arb.pi() / arb(N_LEVEL).sqrt()
        M = nterms(0.5 * (t_lo + t_hi), theta, sig_lo, sig_hi, extra=40)
        M = min(M, C.M)
        tot = arb(0)
        a = C.a
        s_hi = arb(sig_hi); ks_hi = arb(K_WT) - arb(sig_lo)
        for n in range(1, M + 1):
            if a[n] == 0: continue
            y = cA * x0 * n
            g1 = acb(y).gamma_upper(acb(s_hi)).real * y ** (-s_hi)
            g2 = acb(y).gamma_upper(acb(ks_hi)).real * y ** (-ks_hi)
            tot += abs(a[n]) * (g1 + g2)
        tot = tot + _tail_bound(M, theta, sig_lo, sig_hi, 0.0)   # tail at e^{0}, rescaled below
        tot = tot * (-arb(abs(theta)) * arb(tmin) * (1 - arb(2) ** -40)).exp() if theta != 0 else tot
        # (the tail bound above was computed with t = 0 and multiplied by e^{-|theta| tmin} together with the main sum)
    finally:
        ctx.prec = old
    return tot.upper()


def Z(C, t, theta=None, prec=None):
    """real arb containing Z(t) = e^{pi t/2} Lambda(1 + i t) (real for eps = +1); its sign is the sign of Lambda(1 + it)."""
    if theta is None: theta = theta_for(t)
    if prec is None: prec = prec_for(t, theta=theta)
    old = ctx.prec; ctx.prec = prec
    try:
        T = arb(t)
        v = Lam(C, acb(arb(1), T), theta, prec)
        r = v.real * (arb.pi() * T / 2).exp()
    finally:
        ctx.prec = old
    return r
