"""Driver: certified zero count of Lambda(s, 11.a) in [S0, S1] x [T_LO, T_HI] and map-free bisection into symmetric boxes.

usage: run.py T_LO T_HI OUTDIR [--perturb-a2 V] [--vr R]
No zero list is read.  Output: OUTDIR/result.json, OUTDIR/log.txt, OUTDIR/patches.jsonl (checkpoint of patch models).
"""
import sys, os, json, time, math, resource
sys.dont_write_bytecode = True
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import ap_lambda as AP
import lam_rot as L
from flint import arb


def main():
    T_LO = float(sys.argv[1]); T_HI = float(sys.argv[2]); OUT = sys.argv[3]
    args = sys.argv[4:]
    pert = None; vr = 1.0
    if '--perturb-a2' in args: pert = int(args[args.index('--perturb-a2') + 1])
    if '--vr' in args: vr = float(args[args.index('--vr') + 1])
    theta0 = '--theta0' in args
    if theta0:   # control mode: one fixed split A = 1 everywhere (a single entire function even for wrong coefficients)
        AP.patch_theta = lambda tc, R: 0.0
        L.theta_for = lambda t, phi_const=L.PHI: 0.0
    os.makedirs(OUT, exist_ok=True)
    logf = open(os.path.join(OUT, 'log.txt'), 'a')
    def log(*a):
        s = time.strftime('%H:%M:%S ') + ' '.join(str(x) for x in a)
        print(s, flush=True); logf.write(s + '\n'); logf.flush()
    C = L.Coeffs(4000)
    if pert is not None:
        log(f'NEGATIVE CONTROL: a_2 := {pert} (true {C.a[2]}); a_n for even n NOT re-derived (only a_2 changed)')
        C.a[2] = pert
    log(f'theta0={theta0} box Re s in [{AP.S0}, {AP.S1}] (arith; analytic [-1/16, 17/16]), t in [{T_LO}, {T_HI}], vr={vr}, NS={AP.NS}, K={AP.K_ORD}')
    cnt = AP.Counter(C, T_LO, T_HI, ckpt=os.path.join(OUT, 'patches.jsonl'), vr=vr, log=log)
    t_start = time.time()
    n_tot, enc = cnt.count(T_LO, T_HI)
    log(f'FULL BOX count N = {n_tot}  enclosure {enc}  stats {cnt.stats.d()}')
    res = dict(T_LO=T_LO, T_HI=T_HI, perturb_a2=pert, theta0=theta0, N_total=n_tot, enclosure=enc, full_box_s=round(time.time() - t_start, 1))
    if n_tot is None:
        res['certified'] = False
        json.dump(res, open(os.path.join(OUT, 'result.json'), 'w'), indent=1); return
    # Z signs at cut heights (consistency check, independent of the count)
    zs = {}
    def zsign(t):
        if t not in zs:
            v = L.Z(C, t)
            zs[t] = 1 if v.lower() > 0 else (-1 if v.upper() < 0 else 0)
        return zs[t]
    leaves = []; queue = [(T_LO, T_HI, n_tot)]; failed = None; min_h = 1e-6
    t_b = time.time()
    while queue:
        a, b, n = queue.pop()
        if n <= 1:
            leaves.append((a, b, n)); continue
        if b - a < min_h:
            failed = ('too small', a, b, n); leaves.append((a, b, n)); break
        done = False
        for off in (0.0, 0.0625, -0.0625, 0.15625, -0.15625, 0.28125, -0.28125, 0.03125, -0.03125):
            c = a + (b - a) * (0.5 + off)
            c = float(arb(c).mid())       # an exact float
            lo, elo = cnt.count(a, c)
            if lo is None:
                log(f'  cut {c} failed ({elo}); trying another offset'); continue
            hi, ehi = cnt.count(c, b)
            if hi is None:
                log(f'  cut {c} failed ({ehi}); trying another offset'); continue
            if lo + hi != n:
                failed = ('ADDITIVITY VIOLATION', a, c, b, n, lo, hi); log(failed); break
            queue.append((c, b, hi)); queue.append((a, c, lo)); done = True
            log(f'[{a:.6f},{b:.6f}] N={n} -> [{a:.6f},{c:.6f}] {lo} + [{c:.6f},{b:.6f}] {hi}   leaves={len(leaves)} {cnt.stats.d()}')
            break
        if failed: break
        if not done:
            failed = ('no cut certified', a, b, n); leaves.append((a, b, n)); break
    leaves.sort()
    # sign consistency check on leaves
    zcheck = []
    for a, b, n in leaves:
        if n > 1: continue
        sa, sb = zsign(a), zsign(b)
        ok = (sa != 0 and sb != 0 and ((n == 1 and sa == -sb) or (n == 0 and sa == sb)))
        zcheck.append(ok)
    res.update(dict(certified=(failed is None and all(l[2] <= 1 for l in leaves)), failure=failed,
                    leaves=leaves, n_leaves=len(leaves), n_one=sum(1 for l in leaves if l[2] == 1),
                    sum_leaves=sum(l[2] for l in leaves),
                    z_sign_consistent=all(zcheck), z_sign_checked=len(zcheck),
                    bisection_s=round(time.time() - t_b, 1), total_s=round(time.time() - t_start, 1), stats=cnt.stats.d(),
                    maxrss_MB=round(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 2 ** 20, 1)))
    log(f"DONE certified={res['certified']} N={n_tot} leaves N=1: {res['n_one']} / {len(leaves)}  Z-sign consistent={res['z_sign_consistent']}  "
        f"total {res['total_s']} s  maxrss {res['maxrss_MB']} MB")
    json.dump(res, open(os.path.join(OUT, 'result.json'), 'w'), indent=1)


if __name__ == '__main__':
    main()
