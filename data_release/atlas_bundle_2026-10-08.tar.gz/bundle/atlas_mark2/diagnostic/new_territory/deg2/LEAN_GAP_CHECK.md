# Lean-gap check of the degree-2 verifier (2026-10-07)

This checks the deg2 verifier against the three load-bearing conditions that the Lean formalization surfaced
(formal/README.md, "Findings", items 1-3; CORRECTIONS_2026-10-06.md, last section). It was a read-only audit: no code or certificate was changed.
Script: `lean_gap_check/check.py`, which reads the certificate JSON only, uses exact `Fraction`s of the stored floats and needs no Arb.

## Verdict

| condition | enforced by the acceptance code (replay_verify.py) | certificates violating it (737 real + 1 NC) |
|---|---|---|
| (1) (C) checked on the closed box with d0 = 0 | **yes** | **0** |
| (2) candidate cell inside the window | **yes** | **0** |
| (3) every sign-change interval inside the window | **yes** | **0** |

No claim is affected.

## Code (acceptance = `replay_deg2.py` calling `replay_verify.run`; sha 82b38196545e…, the same sha as recorded in every replay summary)

1. **(C) at d = 0.**
   * `replay_verify.py:29` rejects any certificate with `d_range != [0.0, 0.5]` (BAD_DRANGE).
   * `:58` seeds the candidate queue with the hard-coded box `('C', x0, x1, 0.0, 0.5)`, so the box does not come from certificate data.
   * `_iv` (`:9-11`) is an Arb ball that contains the closed interval [lo, hi].
   * Bisection (`:75-78`) splits at a midpoint that both children share, so the leaves cover the closed box, including d = 0.
   * `:72-73` accepts only if the lower bound of g is > 0 on every leaf.
   * Tiling (`replay_deg2.py:77-78`) also counts a cell only if `d_range == [0.0, 0.5]`.
   * The trusted generator-side verifier does the same: `verify_deg2.py:86` (`('cand', x0, x1, 0.0, 0.5)`) and `:95-97`.
2. **Cell inside the window.**
   * `replay_verify.py:32` checks `wlo <= x0 < x1 <= whi`, else BAD_CELL. The same check is in `verify_deg2.py:41`.
   * The window here is the one used for the row bounds: `replay_deg2.py:43` (Fa) and `:63` (Nwin) are recomputed from `c['window']`. So (H_rows) and (H_count) refer to the same W that the cell is checked against.
3. **Intervals inside the window.**
   * `replay_verify.py:39` checks `wlo <= t1 < t2 <= whi`, and also that the intervals are sorted and disjoint (else BAD_INTERVALS).
   * The check runs before the sign change is re-verified (`:41`) and before any credit is used.
   * `verify_deg2.py:48-49` does the same check (BAD_INTERVAL).

All comparisons are between IEEE doubles read from the JSON. Python's float comparison is exact, so these checks are the
exact-rational checks.

## Certificate data (exact rationals)

`nice -n 19 python3 lean_gap_check/check.py` scanned 738 `cell_*.json` files and 20,103 intervals:

* target runs: t_11a_100_110 (20), t_11a_200_210 (20), t_23_93.5_104 (21);
* contig: 30 chunks c_0_10 … c_290_300, 20 certificates each (600 in total);
* validation runs: val_11a_0_20 (40), val_23_0_18 (36);
* negative control: nc/fake (1).

For each certificate the script checked:
* (1) `d_range == [0, 1/2]` exactly;
* (2) `wlo <= x0 < x1 <= whi`;
* (3) `wlo <= t1 < t2 <= whi` for every interval.

There were **0 violations** of any of the three conditions.

## Side finding (record-keeping only; no claim affected)

`runs/val_11a_0_20/replay.json` does **not** contain the real replay of that run.
* `negctl.sh` replays the corrupted-data controls *in place* on `runs/val_11a_0_20`.
* `replay_deg2.py:90` writes `replay.json` into the run directory, so each control overwrote it. The last one to run was
  `NC_AP=2:1 NC_ROWS_ONLY=1` (07:37:19).
* The file now shows 40/40 INCONSISTENT and closed = false. `SHA256SUMS` line 118 (`d412a30c…`) hashes that overwritten file.
* The real replay (40/40 plain and hardened, tiling closed, 148.7 s) is preserved in `runs/val_11a_0_20/replay.out` (07:22:51).
  It matches RESULTS.md.
* Suggested fix: regenerate `replay.json` from a clean replay, or point negctl's replays at a copy of the run directory. Then
  update SHA256SUMS. This does not affect the 11.a [100, 110] / [200, 210], 23.1.b.a [93.5, 104] or contig [0, 300] claims.
