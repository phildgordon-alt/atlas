# Degree-2 Atlas: results (2026-10-07)

**Outcome: all three pre-registered target windows closed, plus both validation windows.**
* Pre-registration: `../PREDICTIONS.md`, sha256 3cd5e631…4044, written 07:23, before any target run; file unchanged since.
* Theory: `THEORY_DEG2.md`. Hashes: `SHA256SUMS`.

| run | target | zeros found (sign changes in target) | cells | gen time | replay (plain + hardened) | min hardened margin |
|---|---|---|---|---|---|---|
| validation 11.a | [0, 20] | 9 (LMFDB: 9 in [0,20]; all 10 listed ≤ 20.38 matched) | 40/40 | 2.5 min | 40/40, tiling closed, 149 s | 1.88 |
| validation 23.1.b.a | [0, 18] | 10 (LMFDB list matched to 2.5e-10) | 36/36 | 2.2 min | 36/36, closed, 108 s | 1.89 |
| **target 11.a** | **[100, 110]** | 14 (predicted 12–14) | 20/20 | 2.2 min | 20/20, closed, 52 s | 1.87 |
| **target 11.a** | **[200, 210]** | 15 (predicted 14–16) | 20/20 | 4.9 min | 20/20, closed, 63 s | 1.80 |
| **target L(s, 23.1.b.a)** | **[93.5, 104]** | 14 (predicted 14–15) | 21/21 | 1.6 min | 21/21, closed, 50 s | 1.87 |

**Claim for each closed target.** Every zero of the L-function with ordinate in the target lies on the critical line and is simple. "Simple" rests
on Lemma 2, the parity lemma, which still needs independent review.
* For 23.1.b.a, combine this with RH for ζ up to 3·10^12 (Platt–Trudgian). The result is RH for ζ_K, K = Q(x³ − x − 1), disc −23, for
  93.5 ≤ γ ≤ 104, which overlaps Tollis's 93.81.
* Simplicity of ζ_K's zeros is **not** claimed: a ζ zero could in principle coincide with an L(g) zero.

Zero ordinates (interval midpoints, width ≤ 1e−9; diagnostic):
* 11.a [100,110]: 100.001166, 100.211467, 101.498757, 101.875626, 103.107789, 103.523905, 104.404011, 105.672093, 106.654055, 106.950246, 107.962177, 108.630766, 109.096165, 109.741808
* 11.a [200,210]: 200.046297, 200.678853, 201.147386, 201.954498, 202.731304, 203.576603, 204.312053, 205.047538, 205.929798, 206.366307, 206.951581, 207.572112, 208.391481, 208.892232, 209.464036
* 23.1.b.a [93.5,104]: 94.603843, 95.117974, 96.023828, 96.801034, 97.556711, 98.084083, 98.780038, 99.468664, 100.308321, 100.821134, 101.553858, 102.631241, 102.807661, 103.840854

## Negative controls (11.a [0,20]; `negctl.sh`, outputs in `runs/nc/`)

| control | expected | observed |
|---|---|---|
| fake sign change (12.0, 12.1) injected into the generator | rejected | generator's own check flags 39/40 cells INCONSISTENT (credit exceeds the row upper bound). The 1 cell it emitted is rejected by the replay with NO_SIGN_CHANGE |
| wrong conductor N = 12, rows + Z | fail | 40/40 rejected: the A = 1 and A = 1.2 series disagree (Z = −33.6 vs −25.7 at the first zero) |
| wrong conductor N = 10, rows + Z | fail | 40/40 rejected (series mismatch) |
| N = 10, rows only (true Z) | fail | 40/40 INCONSISTENT |
| a_2 + 1, rows + Z | fail | 40/40 rejected (series mismatch) |
| a_2 + 1, rows only | fail | 40/40 INCONSISTENT |
| generator with a_3 + 1 in rows | no certificate | 0/40 certified (INCONSISTENT) |

**Limits of these controls.**
* A conductor that is too *large* in the rows only (true Z) would not be caught. It makes every row's upper bound larger, which is still a valid upper bound, so it is not a soundness problem.
* Perturbing a_p at a large prime changes the rows by less than their radius and would not be caught either. In that case the rows are still correct enclosures, so this is not a soundness problem.

## Proved vs trusted
See THEORY_DEG2.md §9.

**Proved here:**
* Λ tail (Lemma T);
* the explicit formula adaptation;
* the archimedean quadrature bound;
* the zero-count bound (Lemma N), proved directly from the explicit formula, with no external N(T) theorem;
* the far allowances;
* the certificate theorem, carried over from zsign;
* Lemma 2, carried over and awaiting review.

**Trusted:**
* Arb/FLINT (python-flint 0.9.0);
* modularity and identification of the two η-products (ε = +1, also checked numerically by the A-split);
* Hasse / Deligne–Serre;
* Rosser–Schoenfeld ψ(x) < 1.03883x;
* Trefethen's Gauss–Legendre bound;
* Iwaniec–Kowalski Thm 5.6 (only for the ε = 1.5 Lorentzian rows, which the LP uses with small weight).

HiGHS and the generator are untrusted.

**Deviation from the brief.** Lorentzian rows are implemented only for ε > 1/2, where they are computed from the arithmetic side. In-strip rows
Re Λ'/Λ(1/2 + ε + it) with ε ≤ 1/2 were not ported; a route is sketched in THEORY §5. They were not needed: the sign-change credits leave a
residual of about 1e−2 against candidate contributions of about 2. Most certificates put weight ~0.97 on a single a = 0.8 sech row. This is the
Büthe / Hiary–Ireland–Kyi mechanism, with the zeros discovered by Arb sign changes rather than input.

## Novelty status (basis: ../TARGETS.md; moderate confidence, not a literature guarantee)
* **11.a [100,110] and [200,210]:** outside any published rigorous verification I know of.
  * Best et al. (arXiv:2002.04717 §10.3) verify up to an unstated b; LMFDB zeros end at 20.38.
  * Hiary–Ireland–Kyi did 37.a1 for |t| ≤ 10.
  * These are *windows*: [20.38, 100] and [110, 200] are not verified here.
* **23.1.b.a [93.5, 104]:** extends Tollis (Math. Comp. 1997), which verified ζ_K for disc −23 to 93.81, contiguously to 104.

## Resource use
* Every process was single, run under nice -n 19, with RSS about 50 MB at the one check made. Peak memory was not logged; I estimate it stayed under 0.5 GB, given the 3e6-coefficient list. T4 was still running (no t4.done), so the rule was one light process at a time.
* Total compute was about 30 minutes, including the controls.

## Record fix (2026-10-07)
runs/val_11a_0_20/replay.json had been overwritten by a negative-control replay from negctl.sh (which replays corrupted data in place).
Regenerated by a fresh replay (40/40 plain + hardened, closed, 0 gaps; replay_regen.out); the overwritten file is kept as
replay_OVERWRITTEN_by_negctl.json; SHA256SUMS updated (old list kept as SHA256SUMS.bak_pre_regen). No claim affected.
Lean-surfaced conditions (1)-(3): enforced by replay_verify.py and satisfied by all 737 real certificates (LEAN_GAP_CHECK.md).
