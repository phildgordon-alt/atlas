# Atlas for degree-2 L-functions: theory (2026-10-07)

Forms used. **11.a**: f = η(z)²η(11z)² ∈ S_2(Γ_0(11)), so L(f,s) = L(E,s) for E = X_0(11) (Eichler–Shimura). **23.1.b.a**: g = η(z)η(23z) ∈
S_1(Γ_0(23), χ_{−23}), dihedral, with ζ_K = ζ·L(g,s) for K = Q(x³−x−1) (disc −23). Both have real integer coefficients and root number
ε = +1. Weight k, level N. Coefficients are exact integers from Euler's pentagonal series multiplied in FLINT (`forms.py`). Diagnostics:
Hecke multiplicativity, a_{p²} = a_p² − χ(p)p^{k−1}, Hasse |a_p| ≤ 2p^{(k−1)/2}, and point counts on y² + y = x³ − x² − 10x − 20 for p ≤ 37.
a_11 = 1 and a_23 = 1 (bad primes).

**Normalizations.**
* Arithmetic: Λ(s) = (√N/2π)^s Γ(s) L(f,s), Λ(s) = εΛ(k−s). This is used for the Λ evaluator.
* Analytic: L(s) := L(f, s + (k−1)/2), so the centre is 1/2, the Euler product converges absolutely for Re s > 1, and Λ_an(s) = Λ(s + (k−1)/2) satisfies Λ_an(s) = εΛ_an(1−s).
* Zeros are ρ = 1/2 + iγ_ρ, with γ_ρ = γ − iδ and δ = β − 1/2, |δ| < 1/2. Since Λ_an is entire of order 1 and has no zeros for Re s > 1 (Euler product) or Re s < 0 (FE), the closed range |δ| ≤ 1/2 is always allowed below.
* Symmetry: the coefficients are real and ε = ±1, so ρ ↦ 1 − ρ̄ maps zeros to zeros at the **same ordinate** with the same multiplicity. An off-line zero therefore always comes with a distinct partner at the same height. The "atoms" are then exactly as in `zsign/THEORY_ZSIGN.md`:
  * (x, 0, f=1) for an on-line zero;
  * (x, d, f=2) for a pair, or for a double on-line zero at d = 0;
  * d = |δ| ∈ [0, 1/2].

## 1. The Λ evaluator and its tail (Lemma T)

Let x_n = 2πn/√N, and fix any A > 0. With F(y) = f(iy/√N), the Fricke relation gives F(1/y) = ε y^k F(y). Splitting the Mellin integral
Λ(s) = ∫_0^∞ F(y) y^{s−1} dy at y = A and substituting y ↦ 1/y on (0, A):

    Λ(s) = Σ_n a_n [ x_n^{−s} Γ(s, A x_n) + ε x_n^{s−k} Γ(k−s, x_n/A) ],      using x^{−s}Γ(s, Ax) = ∫_A^∞ v^{s−1} e^{−xv} dv.

A = 1 is the standard Lavrik/Cohen series. **A ≠ 1 is an independent check.** The two values agree only if N, ε and the a_n are right; the
FE itself holds formally for the A = 1 series, so it is *not* a test. The replay requires the A = 1 and A = 1.2 enclosures to overlap at every
sign-change endpoint. In the validation they agree to about 1e−27 relative at t = 100. They also agree off the line, e.g. at s = 1.3 + 50.5i.

**Lemma T (tail).** Let σ = Re s, c_1 = max(0, σ−1) and c_2 = max(0, k−σ−1). For n with A x_n > c_1 and x_n/A > c_2:

    |x_n^{−s} Γ(s, A x_n)| ≤ A^σ e^{−A x_n} / (A x_n − c_1),     |x_n^{s−k} Γ(k−s, x_n/A)| ≤ A^{σ−k} e^{−x_n/A} / (x_n/A − c_2).

*Proof.*
* |∫_A^∞ v^{s−1} e^{−xv} dv| ≤ ∫_A^∞ v^{σ−1} e^{−xv} dv.
* If σ ≤ 1, then v^{σ−1} ≤ A^{σ−1} on [A, ∞).
* If σ > 1, then v^{σ−1} = A^{σ−1}(v/A)^{σ−1} ≤ A^{σ−1} e^{(σ−1)(v−A)/A}.
* Integrating gives A^σ e^{−Ax}/(Ax − c_1).
* The second term is the first with s ↦ k−s and A ↦ 1/A. ∎

Coefficients satisfy |a_n| ≤ d(n) n^{(k−1)/2} ≤ 2n^{k/2}. This uses Hasse (k = 2), or a_p ∈ {0, ±1, 2} with roots of unity (dihedral k = 1),
plus multiplicativity and d(n) ≤ 2√n. Write T_n for the bound on term n. For n ≥ m, the ratio of consecutive term bounds is at most
q = (1 + 1/m)^{k/2} e^{−A·2π/√N} < 1 (and likewise with 1/A). So the omitted part beyond M is at most T_{M+1}/(1 − q), and this is added as a
ball radius (`lfun._tail`).

Every Γ(s, x) is an Arb ball (`acb_hypgeom_gamma_upper`). The working precision is 96 + 2.3|t| + 32 bits, which absorbs the e^{−π|t|/2}
cancellation. The cut-off M only affects efficiency. Cost: 0.04 s per evaluation at t = 100 (115 terms).

**Z.** Z(t) := e^{πt/2} Λ(k/2 + it), and Z is real. Reason: Λ(k/2 + it) = εΛ(k/2 − it), and since the a_n are real, Λ(s̄) is the complex conjugate
of Λ(s). So with ε = +1, Λ(k/2 + it) equals its own conjugate. Z is real-analytic and vanishes exactly at on-line zeros, with the same multiplicity.

## 2. Arithmetic side

Write −L'/L(s) = Σ c(n) n^{−s} (analytic normalization).
* Good p: λ_p = a_p p^{−(k−1)/2} = α + β, αβ = χ(p), and c(p^m) = (α^m + β^m) log p, computed by the recurrence e_m = λ e_{m−1} − χ(p) e_{m−2}.
* Bad p: c(p^m) = λ_p^m log p, where |λ_p| = 11^{−1/2} for 11.a and 1 for 23.1.b.a.

In both cases **|c(n)| ≤ 2Λ(n)**.

Tails use Rosser–Schoenfeld (1962, Thm 12): ψ(x) < 1.03883x for x > 0. By partial summation, for σ > 1:

    Σ_{n>P} Λ(n) n^{−σ} ≤ 1.03883 σ P^{1−σ}/(σ−1).

All sums over prime powers n ≤ P are exact Arb sums.

## 3. Explicit formula with the sech kernel

Let h(r) = sech(a(r − x)) with 0 < a < π, and f(u) = (1/2a) sech(πu/2a) e^{−iux}. Integrate h(−i(s−1/2)) Λ_an'/Λ_an(s) around
Re s ∈ [1−c, c] with c > 1. Use Λ_an'/Λ_an = log(√N/2π) + ψ(s + (k−1)/2) + L'/L(s), and the FE on the left edge. Then shift to Re s = 1/2.
There are no poles, because Λ_an is entire. This is the same computation as `usefulness_tests/lfunction/THEORY.md` §2, with the degree-1 gamma
factor replaced by Γ(s + (k−1)/2) and q/π replaced by N/4π²:

    E_a(x) := Σ_ρ Re sech(a(γ_ρ − x))
            = (1/2a) log(N/4π²) + arch_a(x) − 2 Σ_n c(n) n^{−1/2} (1/2a) sech(b log n) cos(x log n),     b = π/(2a),
    arch_a(x) = (1/2π) ∫ sech(as) · 2 Re ψ(k/2 + i(s+x)) ds.

**Numerical confirmation (diagnostic).** We computed E_a(x) for a ∈ {0.8, 1, 1.25} and x ∈ {0, 4, 8, 11}, and compared it with
Σ over LMFDB's zeros ±γ of sech(a(γ ∓ x)):
* the differences are 2e−9 to 4e−4;
* they are always ≥ −radius;
* they grow as x approaches the unlisted zeros above 20.38 (`diagnostics/val_rows.log`).

**Positivity and the per-atom kernel.** Re sech(a(r − iδ)) = cosh(ar) cos(aδ)/(sinh²(ar) + cos²(aδ)) =: u_a(r, d) > 0, since a|δ| < π/2. This is
the kernel U of a sech row. It is even in δ, so a pair contributes 2u.

**Truncation.** (1/2a) sech(b log n) ≤ (1/a) n^{−b}. So the omitted prime powers n > P contribute at most (4/a)·1.03883 σ P^{1−σ}/(σ−1),
with σ = 1/2 + b. The chosen P are 3e5, 1e6 and 2e6 for a = 0.8, 1, 1.25. The resulting row radii are about 4e−7, 3e−6 and 1.3e−4.
(Small a is needed because the sech prime side decays only like n^{−1/2−b}. Without an Arb-native L'/L, a < π/2 is the practical range.)

**Archimedean term.** arch_a is integrated by composite Gauss–Legendre on [−S, S], S ≈ 46/a.
* Panels have half-width h = 0.5 and 20 nodes. Nodes and weights are Arb balls (`arb.legendre_p_root`).
* The integrand g(s) = sech(as)[ψ(k/2 + i(s+x)) + ψ(k/2 − i(s+x))] is analytic for |Im s| < min(π/2a, k/2). We use H = min(0.6, 0.3k, 0.6π/2a).
* Each panel's error is ≤ (64/15) h M ρ^{−2n}/(ρ² − 1) (Trefethen, ATAP Thm 19.3), with ρ fixed by h(ρ − ρ^{−1})/2 = H. Here M bounds |g| on the rectangle containing the Bernstein ellipse, by adaptive Arb box evaluation (`_boxmax`).
* Tail |s| > S: we use |Re ψ(k/2 + iy)| ≤ log(1+|y|) + 2. The upper bound comes from the Stirling bound |ψ(w) − log w + 1/(2w)| ≤ 1/(6|w|²) for Re w > 0, with |w| ≥ 1/2. The lower bound comes from Re ψ(σ_0 + iy) ≥ ψ(σ_0) ≥ ψ(1/2) > −2 (series with nonnegative terms). This gives tail ≤ (4/π) e^{−aS}(A_0/a + 1/a²), with A_0 = log(1+S+|x|) + 2.

## 4. Zero counting (proved here) and far allowances

**Lemma N.** For every real T, the number of zeros (with multiplicity, any β) with |γ − T| ≤ 1/2 is at most

    Cnt(T) = [ (1/2) log(N/4π²) + log(1+|T|) + 2 + 4G/π + 4(−ζ'/ζ)(1/2 + π/2) ] / sech(1/2),    G = Catalan.

*Proof.* Take a = 1 in §3. Every term of E_1(T) is ≥ 0. Each zero with |γ − T| ≤ 1/2 contributes at least min_{|r| ≤ 1/2, 0 ≤ d ≤ 1/2} u_1(r, d).
* u decreases in |r| (THEORY_DEG2 inherits the proof in `deep/THEORY_DEEP.md` §1).
* As a function of d, u is extremal at the endpoints.
* So the minimum is min(sech(1/2), u_1(1/2, 1/2) = 0.95) = sech(1/2).

For the upper bound on E_1(T):
* arch_1(T) ≤ (1/π)∫ sech(s)(log(1+|T|) + |s| + 2) ds = log(1+|T|) + 2 + 4G/π, using Re ψ ≤ log(1+|y|) + 2 and ∫|s| sech s = 4G.
* The prime side has absolute value at most 4 Σ Λ(n) n^{−1/2−π/2} = 4(−ζ'/ζ)(1/2 + π/2), with ζ'/ζ in Arb. ∎

For 11.a, Cnt(100) = 10.36. The true density is about 1.3 per unit. The bound is wasteful but rigorous, and it is used only for far
allowances and for N_win, which the certificates in practice do not use (y_lo = y_c = 0 in every certificate inspected). No external
zero-counting theorem is cited.

**Far allowances.** These follow `farbound.py`. Zeros outside the window W are summed over unit blocks, with the block count ≤ Cnt(block centre),
plus an explicit geometric (sech) or integral (Lorentzian) remainder.
* Sech per-zero bound: cosh(ar)/sinh²(ar).
* Lorentzian per-zero bound: ε/r² + 1/(16r⁴). This needs every outside zero at distance ≥ ε + 1/2, which is enforced on row placement (THEORY_DEEP §2 lemma).
* N_win = Σ Cnt over unit blocks covering W.

## 5. Lorentzian rows

We use ε > 1/2. With s = 1/2 + ε + it (analytic):

    M_ε(t) = Re Λ'/Λ(s) = log(√N/2π) + Re ψ(k/2 + ε + it) − Re Σ_{n≤P} c(n) n^{−s} ± 2·1.03883 σ P^{1−σ}/(σ−1),  σ = 1/2 + ε,
           = Σ_ρ Re 1/(s − ρ)    (Hadamard; Re B = −Σ Re 1/ρ for self-dual entire L-functions, Iwaniec–Kowalski Thm 5.6).

The per-atom kernel is w_ε(r, d) as in THEORY_DEEP §2. Rows lie at least ε + 1/2 inside W, so outside zeros contribute ≥ 0, and S_W ≤ hi holds
with no allowance. Only ε = 1.5 is used, where the truncation radius is 4e−6 at P = 10⁶.

**Not ported:** in-strip Lorentzian rows (ε ≤ 1/2). They need Λ'(s) inside the strip. A rigorous route exists: a central difference of the
Lemma-T series, with a Cauchy bound on Λ''' from the same integral representation. It was not needed, because the sign-change credits make the
residual tiny (§7), so it was not implemented. This is stated plainly as a deviation from the Dirichlet port.

## 6. Sign changes (Lemma 1)

Suppose Arb gives Z(t_1), Z(t_2) with strictly opposite signs. Then (t_1, t_2) contains on-line zeros of odd total multiplicity
(`zsign/THEORY_ZSIGN.md`, Lemma 1). The scan uses step 0.02 and then bisects to width ≤ 1e−9. All intervals are disjoint and lie inside W.
A missed close pair only removes credit, which is conservative.

## 7. Certificate (port of THEORY_ZSIGN Theorem + atlas_v3 Lemma 2)

**Window, model and rows.**
* W = target ± 6.
* Model: a single var box W × [0, 1/2] with f = 2. There are **no caps and no inherited state**: every atom of W lies in it, and Φ scales with f, so f = 1 atoms are covered.
* Rows j are sech (a, t) and Lorentzian (ε, t), with enclosures lo_j ≤ E_j ≤ hi_j. The window sum satisfies lo_j − Fa_j ≤ S_j ≤ hi_j. Count: N_W ≤ N_win.

**Certificate data and conditions.** The certificate is y_up, y_lo, y_c, w ≥ 0, with c_j = y_up,j − y_lo,j and Φ = y_c + Σ c_j U_j. Then:

    (R)  Φ(x,d) − Σ_{i: d=0, x ∈ [t1_i, t2_i]} w_i ≥ 0      on W × [0, 1/2]     (SUM over intervals, never max),
    (C)  2Φ(x,d) − K − 2y_c + Σ_i w_i > 0                    on cell × [0, 1/2],
    K  = Σ_j [y_up,j hi_j − y_lo,j (lo_j − Fa_j)] + y_c (N_win − 2).

**Conclusions.**
* By the zsign Theorem (proof verbatim; only the kernels changed), no off-line pair has ordinate in the cell (d ∈ (0, 1/2]).
* By Lemma 2 (atlas_v3 README: n_i is odd, so a multiple zero inside I_i forces n_i ≥ 3), the same (C) at d = 0 excludes multiple zeros with ordinate in the cell.

Each certified cell thus proves: **every zero with ordinate in the cell is on the line and simple.**

**Why it closes so easily (honest reading).**
* The W-wide sign changes make the credits Σ w_i essentially equal to the window zeros' exact contributions to a row. This is the
  Büthe / Hiary–Ireland–Kyi mechanism, with the zeros *discovered* rather than input.
* The residual hi_j − Σ w_i is then the far zeros plus the truncation radius, about 1e−2 or less.
* A candidate pair near the row centre adds about 2u ≈ 2.
* So typically one sech row with a ≈ 0.8 near the cell carries the certificate, with sampled margin about 1.9.

**Consistency check (both verifiers).** For every row, Σ_i min_{I_i} U_j(·, 0) ≤ hi_j must hold. Otherwise the inputs contradict each other and the
certificate is rejected as INCONSISTENT. This is what catches corrupted a_p or N in the rows (negative controls).

## 8. Generator, verifiers, replay

* `gen_cert.py` (untrusted): rows, sign changes, HiGHS LP, cutting-plane rounds, internal check with `verify_deg2.py` (Arb, recursive bisection).
* `replay_deg2.py`:
  * recomputes every row with prime cut-offs ×1.5, 24-node quadrature, h = 0.4 and different precision;
  * recomputes the far allowances and N_win;
  * re-verifies every sign-change endpoint with the A = 1.2 series at +40 bits, and requires overlap with the A = 1 value;
  * runs the **separately written** `replay_verify.py`. It uses complex-form kernels and a BFS box queue, and requires the intervals to be sorted and disjoint. It runs plain and hardened (lo, hi, Fa and N_win moved 2 ulps outward).
* Exact `Fraction` tiling of the target by the cells that pass both runs.

## 9. Rigor ledger

**Proved here:**
* Lemma T (Λ tail);
* reality of Z;
* the explicit formula's adaptation (gamma factor and conductor);
* the archimedean quadrature bound (given ATAP Thm 19.3 and the Stirling ψ bound);
* the prime truncation (given Rosser–Schoenfeld);
* Lemma N;
* the far allowances;
* the certificate algebra (zsign Theorem, carried over);
* Lemma 2 (carried over; **still awaiting independent review**, see atlas_v3 README).

**Trusted:**
* Arb/FLINT via python-flint 0.9.0: gamma_upper, digamma, Legendre roots, zeta series, fmpz_poly.
* Classical facts:
  * f = η²η(11·)² is the newform of 11.a and g = η(z)η(23z) the weight-1 form of K, both with ε = +1 (this is also checked numerically by the A-split);
  * Hasse / Deligne–Serre coefficient bounds;
  * Rosser–Schoenfeld ψ(x) < 1.03883x;
  * Iwaniec–Kowalski Thm 5.6 (Lorentzian rows only);
  * Trefethen Thm 19.3 for Gauss–Legendre.
* For ζ_K: RH for ζ up to 3·10^12 (Platt–Trudgian).
* HiGHS is untrusted.
* LMFDB zero lists are used **only** as diagnostics.
