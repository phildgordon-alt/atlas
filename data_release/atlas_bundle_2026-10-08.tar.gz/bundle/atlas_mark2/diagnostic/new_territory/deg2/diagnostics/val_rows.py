import time,json,math,sys
sys.path.insert(0,'..')
import forms,arith
from flint import arb
F=forms.form('11.a',10**6)
z=[float(v) for v in json.load(open('lmfdb_11a.json'))['data'][0]['positive_zeros']]
t0=time.time();AR=arith.Arith(F,10**5);print('init',time.time()-t0,AR.npp,flush=True)
for a in [0.8,1.0,1.25]:
  for x in [0.0,4.0,8.0,11.0]:
    t0=time.time();E=AR.sech_row(a,x);dt=time.time()-t0
    S=sum(1/math.cosh(a*(g-x))+1/math.cosh(a*(g+x)) for g in z)
    print(a,x,E.mid().str(10),E.rad().str(3),'zeros-sum',round(S,10),'diff',float(E.mid())-S,round(dt,2),flush=True)
t0=time.time();print('arch',AR.arch(1.0,100.0).str(15,radius=True),time.time()-t0)
for e in [0.75,1.5]:
  t0=time.time();M=AR.lor_row(e,8.0);S=sum(e/(e*e+(g-8)**2)+e/(e*e+(g+8)**2) for g in z);print('L',e,M.mid().str(10),M.rad().str(3),'zeros(partial)',S,time.time()-t0)
print('count',arith.count_bound(F,100).str(5),arith.count_bound(F,0).str(5))
