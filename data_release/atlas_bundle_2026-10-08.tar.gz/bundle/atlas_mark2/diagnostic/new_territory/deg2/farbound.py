"""Far allowances and window count (THEORY_DEG2.md section 4).  Trusted; used by the replay.
Cnt(T) = A + B log(1 + |T|) bounds #{zeros (with multiplicity, any beta) : |gamma - T| <= 1/2}  (arith.count_bound, a0 = 1).
sech row (a, t):  every zero outside W contributes Re sech in [0, g(r)],  g(r) = cosh(a r)/sinh(a r)^2,  r = distance > 0.
Lorentzian row (eps > 1/2, t at distance >= eps + 1/2 from both edges of W): every zero outside W contributes in [0, eps/r^2 + 1/(16 r^4)].
Both sums are taken over unit blocks outside W (block count <= Cnt(block centre)), with an explicit remainder beyond a cut."""
import math
from flint import arb, ctx
import arith

def count_AB(F):
    """Cnt(T) = A + B log(1+|T|) as arbs"""
    c0 = arith.count_bound(F, 0)          # = A (log 1 = 0)
    c1 = arith.count_bound(F, math.e - 1) # = A + B
    old = ctx.prec; ctx.prec = 96
    try:
        B = arb(0.5).sech()
        B = 1 / B                           # 1/u_min with u_min = sech(1/2)
        A = c0
        assert ((A + B) - c1).contains(0) or abs(float((A + B - c1).mid())) < 1e-12
    finally:
        ctx.prec = old
    return A, B

def Nwin(F, wlo, whi):
    old = ctx.prec; ctx.prec = 96
    try:
        A, B = count_AB(F); n = int(math.ceil(whi - wlo)); tot = arb(0)
        for j in range(n):
            T = wlo + j + 0.5
            tot += A + B * (1 + abs(arb(T))).log()
        v = tot.upper()
    finally:
        ctx.prec = old
    return float(v) * (1 + 2 ** -40)

def _far(F, t, wlo, whi, g, tailf, rcut):
    """sum over unit blocks outside [wlo, whi] of Cnt(block) * g(min distance), plus remainder tailf(R, A', B) beyond distance rcut"""
    A, B = count_AB(F); tot = arb(0)
    assert wlo < t < whi
    for side in (+1, -1):
        j = 0
        while True:
            if side > 0: lo = whi + j; T = lo + 0.5; r = arb(lo) - arb(t)
            else: hi = wlo - j; T = hi - 0.5; r = arb(t) - arb(hi)
            if float(r.mid()) > rcut: break
            tot += (A + B * (1 + abs(arb(T))).log()) * g(r)
            j += 1
        # remaining blocks: distance >= r (current), and log(1+|T|) <= log(2+|t|) + log(1+r)
        Ap = A + B * (2 + abs(arb(t))).log()
        tot += tailf(r, Ap, B)
    return tot

def sech_far(F, a, t, wlo, whi):
    old = ctx.prec; ctx.prec = 96
    try:
        Aa = arb(a)
        g = lambda r: (Aa * r).cosh() / (Aa * r).sinh() ** 2
        def tailf(R, Ap, B):
            # g(r) <= 2.02 e^{-a r} for a r >= 3;  sum_{m>=0} (Ap + B log(1+R+m)) e^{-a(R+m)} <= e^{-aR}[(Ap + B log(1+R))/(1-q) + B q/(1-q)^2], q = e^{-a}
            assert float((Aa * R).mid()) >= 3
            q = (-Aa).exp()
            return 2.02 * (-Aa * R).exp() * ((Ap + B * (1 + R).log()) / (1 - q) + B * q / (1 - q) ** 2)
        v = _far(F, t, wlo, whi, g, tailf, rcut=60.0 / a)
        out = float(v.upper()) * (1 + 2 ** -40)
    finally:
        ctx.prec = old
    return out

def lor_far(F, eps, t, wlo, whi):
    assert eps > 0.5 and t - wlo >= eps + 0.5 and whi - t >= eps + 0.5
    old = ctx.prec; ctx.prec = 96
    try:
        E = arb(eps)
        g = lambda r: E / r ** 2 + 1 / (16 * r ** 4)
        def tailf(R, Ap, B):
            # sum over blocks at distances R, R+1, ...: f(r) = (Ap + B log(1+r)) (eps + 1/16)/r^2 decreasing, <= f(R) + int_R^inf f
            c = E + arb(1) / 16
            f = lambda r: (Ap + B * (1 + r).log()) * c / r ** 2
            integral = c * (Ap / R + B * ((1 + R).log() + 1) / R)
            return f(R) + integral
        v = _far(F, t, wlo, whi, g, tailf, rcut=2000.0)
        out = float(v.upper()) * (1 + 2 ** -40)
    finally:
        ctx.prec = old
    return out
