"""Exact integer q-expansion coefficients of the two eta-quotient newforms used here, and their Euler-factor data.
11.a  : f = eta(z)^2 eta(11z)^2  in S_2(Gamma_0(11)),  weight k = 2, trivial character, L(f,s) = L(E,s), E = X_0(11).
23.1.b.a: g = eta(z) eta(23z)    in S_1(Gamma_0(23), chi_{-23}), weight k = 1, dihedral; zeta_K = zeta * L(g,s), K = Q(x^3-x-1).
Coefficients from Euler's pentagonal theorem prod(1-q^n) = sum_k (-1)^k q^{k(3k-1)/2}, multiplied exactly with FLINT fmpz_poly."""
import numpy as np
from flint import fmpz_poly
def pentagonal(M):
    c=[0]*(M+1);k=0
    while True:
        e1=k*(3*k-1)//2
        if e1>M:break
        c[e1]+=(-1)**k
        if k>0:
            e2=k*(3*k+1)//2
            if e2<=M:c[e2]+=(-1)**k
        k+=1
    return c
def stretch(c,m,M):
    out=[0]*(M+1)
    for i,v in enumerate(c):
        if i*m>M:break
        out[i*m]=v
    return out
def eta_quotient_coeffs(M,level,power):
    """coefficients a_1..a_M of q * (prod(1-q^n) prod(1-q^{level n}))^power   (q^{(1+level)*power/24} = q exactly)"""
    P=fmpz_poly(pentagonal(M));Q=fmpz_poly(stretch(pentagonal(M),level,M))
    A=P.mul_low(Q,M) if hasattr(P,'mul_low') else (P*Q).truncate(M)
    B=A
    for _ in range(power-1):B=B.mul_low(A,M)
    co=[int(v) for v in B.coeffs()]+[0]*M
    return [0]+co[:M]          # a[n] for n = 0..M, a[0] = 0
def primes_upto(n):
    s=np.ones(n+1,bool);s[:2]=False
    for i in range(2,int(n**0.5)+1):
        if s[i]:s[i*i::i]=False
    return np.nonzero(s)[0]
FORMS={
 '11.a':dict(N=11,k=2,eps=1,level=11,power=2,bad={11:None},char=lambda p:1),
 '23.1.b.a':dict(N=23,k=1,eps=1,level=23,power=1,bad={23:None},char=lambda p:(0 if p%23==0 else (1 if pow(p,11,23)==1 else -1))),
}
def form(name,M):
    F=dict(FORMS[name]);a=eta_quotient_coeffs(M,F['level'],F['power']);F['a']=a;F['name']=name
    for p in F['bad']:F['bad'][p]=a[p]
    return F
