"""Generator (UNTRUSTED) for degree-2 sign-change LP certificates.  Nothing it says counts until replay_deg2.py passes.
usage: python gen_cert.py FORM TLO THI OUTDIR [--margin 6] [--cell 0.5] [--step 0.02]
Env (negative controls only): NC_N (fake conductor in the rows), NC_AP "p:delta" (perturb a_p in the rows),
NC_FAKE "t1,t2" (inject an unverified interval)."""
import sys, os, json, math, time, argparse
import numpy as np
from scipy.optimize import linprog
from flint import arb
import forms, lfun, arith, farbound, zfind, verify_deg2

PS = {0.8: 300000, 1.0: 1000000, 1.25: 2000000}     # prime cut-off per sech width
LEPS = {1.5: 1000000}

def outward(v):
    return math.nextafter(float(v.lower()), -math.inf), math.nextafter(float(v.upper()), math.inf)

def usech(a, r, d):
    ar = np.clip(a * r, -300, 300); c = np.cos(a * d); s = np.sinh(ar)
    return np.cosh(ar) * c / (s * s + c * c)

def uL(e, r, d):
    return 0.5 * ((e - d) / ((e - d) ** 2 + r * r) + (e + d) / ((e + d) ** 2 + r * r))

def U_np(rows, x, d):
    out = np.empty(len(rows))
    for j, (k, p, t) in enumerate(rows):
        out[j] = usech(p, x - t, d) if k == 'S' else uL(p, x - t, d)
    return out

def build_rows(F, target, W, log, step=0.25):
    tlo, thi = target; wlo, whi = W; rows = []
    ts = [tlo - 2 + step * i for i in range(int(round((thi - tlo + 4) / step)) + 1)]
    for a in sorted(PS):
        AR = arith.Arith(F, PS[a]); t0 = time.time()
        for t in ts:
            v = AR.sech_row(a, t); l, h = outward(v)
            rows.append(dict(kind='S', p=a, t=t, lo=l, hi=h, Fa=farbound.sech_far(F, a, t, wlo, whi), rad=float(v.rad())))
        log(f'sech a={a} P={PS[a]} rows={len(ts)} {time.time()-t0:.1f}s')
    for e in sorted(LEPS):
        AR = arith.Arith(F, LEPS[e])
        for t in ts[::4]:
            if t - wlo < e + 0.5 or whi - t < e + 0.5: continue
            v = AR.lor_row(e, t); l, h = outward(v)
            rows.append(dict(kind='L', p=e, t=t, lo=l, hi=h, Fa=farbound.lor_far(F, e, t, wlo, whi), rad=float(v.rad())))
    return rows

def solve_lp(rows, lo, hi, Fa, Nwin, W, cell, iv, rem, cand, tau=1e-4):
    J = len(rows); m = len(iv); n = 2 * J + 1 + m + 1
    A = []; b = []
    for x, d in rem:
        u = U_np(rows, x, d); r = np.zeros(n)
        r[:J] = -u; r[J:2 * J] = u; r[2 * J] = -1
        if d == 0:
            for i, (t1, t2) in enumerate(iv):
                if t1 <= x <= t2: r[2 * J + 1 + i] = 1
        A.append(r); b.append(-tau)
    for x, d in cand:
        u = U_np(rows, x, d); r = np.zeros(n)
        r[:J] = -(2 * u - hi); r[J:2 * J] = -(-2 * u + (lo - Fa)); r[2 * J] = (Nwin - 2)
        r[2 * J + 1:2 * J + 1 + m] = -1; r[-1] = 1
        A.append(r); b.append(0.0)
    Aeq = np.zeros((1, n)); Aeq[0, :2 * J + 1] = 1
    c = np.zeros(n); c[-1] = -1
    res = linprog(c, A_ub=np.array(A), b_ub=b, A_eq=Aeq, b_eq=[1], bounds=[(0, None)] * (n - 1) + [(None, None)], method='highs')
    if res.status != 0: return None
    x = np.maximum(res.x, 0.0)
    return dict(yup=x[:J], ylo=x[J:2 * J], yc=float(x[2 * J]), w=x[2 * J + 1:2 * J + 1 + m], mu=-res.fun)

def certify_cell(rows_all, Nwin, W, cell, iv, log, rounds=25):
    x0, x1 = cell; xc = (x0 + x1) / 2
    sel = [r for r in rows_all if abs(r['t'] - xc) <= 2.6]
    rows = [(r['kind'], r['p'], r['t']) for r in sel]
    lo = np.array([r['lo'] for r in sel]); hi = np.array([r['hi'] for r in sel]); Fa = np.array([r['Fa'] for r in sel])
    wlo, whi = W
    rem = [(x, d) for x in np.arange(wlo, whi + 1e-9, 0.02) for d in (0.0, 0.1, 0.25, 0.5)]
    rem += [(x, 0.0) for t1, t2 in iv for x in (t1, (t1 + t2) / 2, t2)]
    cand = [(x, d) for x in np.linspace(x0, x1, max(11, int((x1 - x0) / 0.01) + 1)) for d in (0.0, 1e-3, 0.01, 0.05, 0.1, 0.2, 0.35, 0.5)]
    for rnd in range(rounds):
        s = solve_lp(rows, lo, hi, Fa, Nwin, W, cell, iv, rem, cand)
        if s is None: return dict(status='LP_FAIL', rounds=rnd)
        if s['mu'] <= 0: return dict(status='NONPOSITIVE_SAMPLED', mu=s['mu'], rounds=rnd)
        r = verify_deg2.check(rows, list(lo), list(hi), list(Fa), Nwin, W, cell, list(map(float, s['yup'])), list(map(float, s['ylo'])),
                              s['yc'], list(map(float, s['w'])), iv, zcheck=None)
        log(f'  cell {cell} round {rnd} mu={s["mu"]:.4g} -> {r["status"]} boxes={r.get("boxes")} minc={r.get("min_candidate_lower")}')
        if r['status'] == 'CERTIFIED':
            return dict(status='CERTIFIED', rows=rows, yup=list(map(float, s['yup'])), ylo=list(map(float, s['ylo'])), yc=s['yc'],
                        w=list(map(float, s['w'])), sampled_mu=s['mu'], gen_check=r)
        if r['status'] != 'FAIL': return dict(status=r['status'], detail=r)
        b0, b1, e0, e1 = r['box']; xm = (b0 + b1) / 2; dm = (e0 + e1) / 2
        pts = [(xm, dm), (b0, e0), (b1, e0), (b0, e1), (b1, e1), (xm, 0.0)]
        if r['kind'] == 'cand': cand += pts
        else: rem += pts
    return dict(status='ROUND_LIMIT')

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('form'); ap.add_argument('tlo', type=float); ap.add_argument('thi', type=float)
    ap.add_argument('out'); ap.add_argument('--margin', type=float, default=6.0); ap.add_argument('--cell', type=float, default=0.5)
    ap.add_argument('--step', type=float, default=0.02)
    A = ap.parse_args(); os.makedirs(A.out, exist_ok=True)
    logf = open(os.path.join(A.out, 'gen.log'), 'a')
    def log(s):
        line = time.strftime('%H:%M:%S ') + s; print(line, flush=True); logf.write(line + '\n'); logf.flush()
    target = (A.tlo, A.thi); W = (A.tlo - A.margin, A.thi + A.margin)
    F = forms.form(A.form, max(max(PS.values()), max(LEPS.values())) + 10)
    Fz = F                                            # Z always from the true form
    Fr = dict(F)
    if os.environ.get('NC_N'): Fr['N'] = int(os.environ['NC_N']); log(f'NEGATIVE CONTROL: rows use N={Fr["N"]}')
    if os.environ.get('NC_AP'):
        p, dl = map(int, os.environ['NC_AP'].split(':')); a2 = list(F['a']); a2[p] += dl; Fr['a'] = a2; log(f'NEGATIVE CONTROL: rows use a_{p}+{dl}')
    log(f'form {A.form} target {target} window {W}')
    ivf = os.path.join(A.out, 'intervals.json')
    if os.path.exists(ivf): iv = [tuple(v) for v in json.load(open(ivf))['intervals']]
    else:
        t0 = time.time(); iv, nev = zfind.find_sign_changes(Fz, W[0], W[1], h=A.step, log=log)
        json.dump(dict(window=W, step=A.step, intervals=iv, evaluations=nev, seconds=time.time() - t0), open(ivf, 'w'))
        log(f'{len(iv)} sign changes in {W}, {nev} scan evaluations, {time.time()-t0:.1f}s')
    if os.environ.get('NC_FAKE'):
        t1, t2 = map(float, os.environ['NC_FAKE'].split(',')); iv = sorted(iv + [(t1, t2)]); log(f'NEGATIVE CONTROL: injected interval {(t1, t2)}')
    rf = os.path.join(A.out, 'rows.json')
    if os.path.exists(rf) and not (os.environ.get('NC_N') or os.environ.get('NC_AP')): rows = json.load(open(rf))['rows']
    else:
        rows = build_rows(Fr, target, W, log); json.dump(dict(rows=rows), open(rf, 'w'))
    Nw = farbound.Nwin(Fr, W[0], W[1]); log(f'Nwin bound {Nw:.2f} (true count about {len(iv)})')
    ncell = int(round((A.thi - A.tlo) / A.cell)); cells = [(A.tlo + (A.thi - A.tlo) * i / ncell, A.tlo + (A.thi - A.tlo) * (i + 1) / ncell) for i in range(ncell)]
    cells[-1] = (cells[-1][0], A.thi)
    os.makedirs(os.path.join(A.out, 'certs'), exist_ok=True); summary = []
    for cell in cells:
        t0 = time.time(); res = certify_cell(rows, Nw, W, cell, iv, log)
        rec = dict(cell=list(cell), status=res['status'], seconds=round(time.time() - t0, 1), min_candidate_lower=res.get('gen_check', {}).get('min_candidate_lower'))
        log(json.dumps(rec)); summary.append(rec)
        if res['status'] == 'CERTIFIED':
            cert = dict(form=A.form, window=list(W), cell=list(cell), d_range=[0.0, 0.5], rows=res['rows'], yup=res['yup'], ylo=res['ylo'], yc=res['yc'],
                        w=res['w'], intervals=[list(v) for v in iv], P=dict(sech={str(k): v for k, v in PS.items()}, lor={str(k): v for k, v in LEPS.items()}),
                        sampled_mu=res['sampled_mu'], gen_min_candidate_lower=res['gen_check']['min_candidate_lower'],
                        negative_control={k: os.environ[k] for k in ('NC_N', 'NC_AP', 'NC_FAKE') if os.environ.get(k)})
            json.dump(cert, open(os.path.join(A.out, 'certs', f'cell_{cell[0]:.4f}.json'), 'w'))
    json.dump(dict(target=list(target), window=list(W), cells=summary, intervals=len(iv)), open(os.path.join(A.out, 'gen_summary.json'), 'w'), indent=1)
    log(f'DONE certified {sum(r["status"]=="CERTIFIED" for r in summary)}/{len(summary)}')

if __name__ == '__main__':
    main()
