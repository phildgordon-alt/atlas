#!/bin/zsh
# Negative controls on the validation window 11.a [0,20] (results in runs/nc/*.out)
P=/Users/kiosk/projects/atlas-rerun/.venv/bin/python
cd /Users/kiosk/atlas_mark2/diagnostic/new_territory/deg2
V=runs/val_11a_0_20
# C1 fake sign change (12.0, 12.1): generator gives it credit, replay must reject
mkdir -p runs/nc/fake; cp $V/rows.json $V/intervals.json runs/nc/fake/
NC_FAKE=12.0,12.1 nice -n 19 $P -u gen_cert.py 11.a 0 20 runs/nc/fake > runs/nc/fake_gen.out 2>&1
nice -n 19 $P -u replay_deg2.py runs/nc/fake 0 20 > runs/nc/fake_replay.out 2>&1
# C2 wrong conductor in the replay (rows + Z): N=12 and N=10
for N in 12 10; do NC_N=$N nice -n 19 $P -u replay_deg2.py $V 0 20 > runs/nc/N${N}_replay.out 2>&1; done
# C2b wrong conductor in the rows only (true Z): N=10
NC_N=10 NC_ROWS_ONLY=1 nice -n 19 $P -u replay_deg2.py $V 0 20 > runs/nc/N10_rowsonly_replay.out 2>&1
# C3 perturbed a_2 (a_2 = -2 -> -1): full data, and rows only
NC_AP=2:1 nice -n 19 $P -u replay_deg2.py $V 0 20 > runs/nc/a2_replay.out 2>&1
NC_AP=2:1 NC_ROWS_ONLY=1 nice -n 19 $P -u replay_deg2.py $V 0 20 > runs/nc/a2_rowsonly_replay.out 2>&1
# C3b generator with perturbed a_3 in the rows (true Z): must not certify
mkdir -p runs/nc/a3gen; cp $V/intervals.json runs/nc/a3gen/
NC_AP=3:1 nice -n 19 $P -u gen_cert.py 11.a 0 20 runs/nc/a3gen > runs/nc/a3_gen.out 2>&1
echo NC_DONE > runs/nc/done
