"""Independent replay of all certificates in RUNDIR/certs (THEORY_DEG2.md section 8).
* every row enclosure is recomputed from scratch with DIFFERENT prime cut-offs (x1.5), quadrature (24 nodes, h = 0.4) and precision;
* far allowances and Nwin recomputed (farbound.py);
* every sign-change endpoint re-verified with the A = 1.2 split of the Lambda series at +40 bits, and the A = 1 value must overlap it
  (series self-consistency = functional-equation check of N, eps, a_n);
* the independently written verifier replay_verify.py is run plain and hardened (lo, hi, Fa moved 2 ulps outward);
* exact rational tiling: the certified cells cover [TLO, THI] and each covers d in [0, 1/2].
usage: python replay_deg2.py RUNDIR TLO THI"""
import sys, os, json, glob, math, time, hashlib
from fractions import Fraction
from flint import arb
import forms, lfun, arith, farbound, replay_verify

PS2 = {0.8: 450000, 1.0: 1500000, 1.25: 3000000}
LEPS2 = {1.5: 1500000}

def main():
    run, tlo, thi = sys.argv[1], float(sys.argv[2]), float(sys.argv[3])
    files = sorted(glob.glob(os.path.join(run, 'certs', 'cell_*.json')))
    certs = [json.load(open(f)) for f in files]
    assert certs, 'no certificates'
    form = certs[0]['form']; assert all(c['form'] == form for c in certs)
    F = forms.form(form, max(max(PS2.values()), max(LEPS2.values())) + 10)
    # NEGATIVE CONTROLS ONLY: NC_N / NC_AP corrupt the data; NC_ROWS_ONLY=1 corrupts the rows but keeps the true Z
    Fz = F
    if os.environ.get('NC_N') or os.environ.get('NC_AP'):
        Fbad = dict(F)
        if os.environ.get('NC_N'): Fbad['N'] = int(os.environ['NC_N'])
        if os.environ.get('NC_AP'):
            p, dl = map(int, os.environ['NC_AP'].split(':')); a2 = list(F['a']); a2[p] += dl; Fbad['a'] = a2
        print('NEGATIVE CONTROL replay with corrupted data', {k: os.environ.get(k) for k in ('NC_N', 'NC_AP', 'NC_ROWS_ONLY')}, flush=True)
        if not os.environ.get('NC_ROWS_ONLY'): Fz = Fbad
        F = Fbad
    AR = {}; rowcache = {}; zcache = {}
    def getrow(k, p, t, W):
        key = (k, p, t, tuple(W))
        if key not in rowcache:
            P = (PS2 if k == 'S' else LEPS2)[p]
            if (k, p) not in AR: AR[(k, p)] = arith.Arith(F, P, prec=112)
            A = AR[(k, p)]
            v = A.sech_row(p, t, nodes=24, h=0.4) if k == 'S' else A.lor_row(p, t)
            lo = math.nextafter(float(v.lower()), -math.inf); hi = math.nextafter(float(v.upper()), math.inf)
            fa = farbound.sech_far(F, p, t, W[0], W[1]) if k == 'S' else farbound.lor_far(F, p, t, W[0], W[1])
            rowcache[key] = (lo, hi, fa)
        return rowcache[key]
    def zcheck(t1, t2):
        out = []
        for t in (t1, t2):
            if t not in zcache:
                pr = 96 + int(2.3 * abs(t)) + 32 + 40
                z12 = lfun.Z(Fz, t, prec=pr, A=1.2); z1 = lfun.Z(Fz, t, prec=pr - 40, A=1.0)
                zcache[t] = (z12, z1)
            z12, z1 = zcache[t]
            if not z12.overlaps(z1): return False, f'series mismatch at {t}: {z12} vs {z1}'
            out.append(lfun.sign(z12))
        ok = out[0] != 0 and out[1] != 0 and out[0] == -out[1]
        return ok, out
    results = []; t00 = time.time()
    for f, c in zip(files, certs):
        W = c['window']; t0 = time.time()
        vals = [getrow(k, p, t, W) for k, p, t in c['rows']]
        lo = [v[0] for v in vals]; hi = [v[1] for v in vals]; Fa = [v[2] for v in vals]
        Nw = farbound.Nwin(F, W[0], W[1])
        rec = dict(file=os.path.basename(f), cell=c['cell'])
        for mode in ('plain', 'hardened'):
            if mode == 'hardened':
                lo2 = [math.nextafter(math.nextafter(v, -math.inf), -math.inf) for v in lo]
                hi2 = [math.nextafter(math.nextafter(v, math.inf), math.inf) for v in hi]
                Fa2 = [math.nextafter(math.nextafter(v, math.inf), math.inf) for v in Fa]
                Nw2 = math.nextafter(math.nextafter(Nw, math.inf), math.inf)
            else: lo2, hi2, Fa2, Nw2 = lo, hi, Fa, Nw
            r = replay_verify.run(c, lo2, hi2, Fa2, Nw2, zcheck)
            rec[mode] = r['status']; rec[mode + '_min_candidate_lower'] = r.get('min_candidate_lower')
            if r['status'] != 'CERTIFIED': rec[mode + '_detail'] = r
        rec['seconds'] = round(time.time() - t0, 1)
        print(json.dumps(rec), flush=True); results.append(rec)
    ok_cells = [(Fraction(c['cell'][0]), Fraction(c['cell'][1])) for c, r in zip(certs, results)
                if r['plain'] == 'CERTIFIED' and r['hardened'] == 'CERTIFIED' and c['d_range'] == [0.0, 0.5]]
    ok_cells.sort(); cur = Fraction(tlo); gaps = []
    for a, b in ok_cells:
        if a > cur: gaps.append([float(cur), float(a)])
        cur = max(cur, b)
    if cur < Fraction(thi): gaps.append([float(cur), thi])
    vsha = hashlib.sha256(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'replay_verify.py'), 'rb').read()).hexdigest()
    summ = dict(SUMMARY=run, form=form, target=[tlo, thi], certificates=len(certs), passed_both=len(ok_cells), tiling_gaps=gaps,
                closed=(not gaps), replay_verify_sha=vsha, sign_change_endpoints_checked=len(zcache), seconds=round(time.time() - t00, 1),
                min_margin=min((r['hardened_min_candidate_lower'] for r in results if r.get('hardened_min_candidate_lower') is not None), default=None),
                claim=('every zero of L(s) with ordinate in [%g, %g] lies on the critical line and is simple' % (tlo, thi)) if not gaps else None)
    print(json.dumps(summ), flush=True)
    json.dump(dict(summary=summ, cells=results), open(os.path.join(run, 'replay.json'), 'w'), indent=1)

if __name__ == '__main__':
    main()
