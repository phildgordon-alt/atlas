"""Second, independently written verifier (used only by the replay).  Same theorem as verify_deg2.py (THEORY_DEG2.md section 7),
different code: kernels evaluated as real parts of complex Arb expressions, breadth-first box queue, own K and credit logic.
  sech atom kernel   U = Re 1/cosh(a (r - i d))            (= cosh(ar)cos(ad)/(sinh^2(ar)+cos^2(ad)))
  Lorentzian kernel  U = (1/2) Re[1/(e - d + i r) + 1/(e + d + i r)]"""
import math
from collections import deque
from flint import arb, acb, ctx

def _iv(a, b):
    lo, hi = arb(a), arb(b)
    return (lo + hi) / 2 + arb(0, ((hi - lo) / 2).upper())

def kern(kind, p, t, X, D):
    R = X - arb(t); P = arb(p)
    if kind == 'S':
        return (1 / (acb(P * R, -P * D)).cosh()).real
    return ((1 / acb(P - D, R)) + (1 / acb(P + D, R))).real / 2

def run(cert, lo, hi, Fa, Nwin, zcheck, budget=4_000_000, maxdepth=64):
    old = ctx.prec; ctx.prec = 160
    try:
        return _run(cert, lo, hi, Fa, Nwin, zcheck, budget, maxdepth)
    finally:
        ctx.prec = old

def _run(cert, lo, hi, Fa, Nwin, zcheck, budget, maxdepth):
    rows = cert['rows']; yup = cert['yup']; ylo = cert['ylo']; yc = cert['yc']; w = cert['w']; I = cert['intervals']
    wlo, whi = cert['window']; x0, x1 = cert['cell']
    if cert['d_range'] != [0.0, 0.5]: return dict(status='BAD_DRANGE')
    for v in list(yup) + list(ylo) + [yc] + list(w):
        if not (isinstance(v, (int, float)) and math.isfinite(v) and v >= 0): return dict(status='BAD_MULTIPLIER')
    if not (wlo <= x0 < x1 <= whi): return dict(status='BAD_CELL')
    for k, p, t in rows:
        if k == 'S' and not (0 < p < math.pi and wlo < t < whi): return dict(status='BAD_ROW')
        if k == 'L' and not (p > 0.5 and wlo + p + 0.5 <= t <= whi - p - 0.5): return dict(status='BAD_ROW')
        if k not in ('S', 'L'): return dict(status='BAD_ROW')
    prev = -math.inf
    for t1, t2 in I:
        if not (wlo <= t1 < t2 <= whi and t1 > prev): return dict(status='BAD_INTERVALS')   # sorted, disjoint
        prev = t2
        ok, info = zcheck(t1, t2)
        if not ok: return dict(status='NO_SIGN_CHANGE', interval=[t1, t2], info=info)
    for j, (k, p, t) in enumerate(rows):          # inputs consistent with the proven on-line zeros?
        cr = sum((kern(k, p, t, _iv(t1, t2), arb(0)).lower() for t1, t2 in I), arb(0))
        if cr > arb(hi[j]): return dict(status='INCONSISTENT', row=[k, p, t])
    c = [arb(yup[j]) - arb(ylo[j]) for j in range(len(rows))]
    act = [(c[j], rows[j]) for j in range(len(rows)) if yup[j] != ylo[j]]
    K = arb(yc) * (arb(Nwin) - 2)
    for j in range(len(rows)): K = K + arb(yup[j]) * arb(hi[j]) - arb(ylo[j]) * (arb(lo[j]) - arb(Fa[j]))
    SW = sum((arb(v) for v in w), arb(0))
    def F(xa, xb, da, db):
        X = _iv(xa, xb); D = _iv(da, db); s = arb(yc)
        for cj, (k, p, t) in act: s = s + cj * kern(k, p, t, X, D)
        return s
    q = deque()
    edges = [wlo + (whi - wlo) * i / 8 for i in range(9)]; edges[-1] = whi
    for a, b in zip(edges, edges[1:]): q.append(('R', a, b, 0.0, 0.5, 0))
    q.append(('C', x0, x1, 0.0, 0.5, 0))
    nb = 0; mc = math.inf
    while q:
        typ, a, b, da, db, dep = q.popleft(); nb += 1
        if nb > budget: return dict(status='BUDGET')
        val = F(a, b, da, db)
        if typ == 'R':
            cred = arb(0)
            if da == 0.0:
                for (t1, t2), v in zip(I, w):
                    if t1 <= b and a <= t2: cred = cred + arb(v)
            g = val - cred                       # f = 2 scaling irrelevant for the sign
            if g.lower() >= 0: continue
        else:
            g = 2 * val - K - 2 * arb(yc) + SW
            if g.lower() > 0: mc = min(mc, float(g.lower())); continue
        if dep >= maxdepth: return dict(status='FAIL', kind=typ, box=[a, b, da, db])
        if (b - a) >= 4 * (db - da) or da == db:
            m = (a + b) / 2; q.append((typ, a, m, da, db, dep + 1)); q.append((typ, m, b, da, db, dep + 1))
        else:
            m = (da + db) / 2; q.append((typ, a, b, da, m, dep + 1)); q.append((typ, a, b, m, db, dep + 1))
    return dict(status='CERTIFIED', boxes=nb, min_candidate_lower=mc)
