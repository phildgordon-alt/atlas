"""Sign changes of Z(t) = e^{pi t/2} Lambda(k/2 + it) on [lo, hi] (Lemma 1, THEORY_DEG2.md section 6).
Scan with step h; every sign change is refined by bisection to width <= tol.  Endpoints are exact binary64 values,
and Z at each endpoint is an Arb ball with a strict sign.  (The generator is untrusted; the replay re-verifies every endpoint
with the A = 1.2 split of the series and +40 bits.)"""
import math, lfun

def zsign(F, t, A=1.0, extra=0):
    pr = 96 + int(2.3 * abs(t)) + 32 + extra
    z = lfun.Z(F, t, prec=pr, A=A)
    return lfun.sign(z), z

def find_sign_changes(F, lo, hi, h=0.02, tol=1e-9, log=None):
    n = int(math.ceil((hi - lo) / h)); ts = [lo + (hi - lo) * i / n for i in range(n + 1)]
    sg = []
    for t in ts:
        s, z = zsign(F, t)
        tt = t; k = 0
        while s == 0 and k < 20:                    # ball contains 0: nudge (never across the window edge)
            k += 1; tt = t + (1e-7 * k if t < hi else -1e-7 * k); s, z = zsign(F, tt)
        if s == 0: raise RuntimeError(f'cannot resolve sign near {t}')
        sg.append((tt, s))
    iv = []
    for (t1, s1), (t2, s2) in zip(sg, sg[1:]):
        if s1 == s2: continue
        a, b, sa = t1, t2, s1
        while b - a > tol:
            m = (a + b) / 2
            if m <= a or m >= b: break
            sm, _ = zsign(F, m)
            if sm == 0:
                break                                   # keep current (valid) interval
            if sm == sa: a = m
            else: b = m
        iv.append((a, b))
        if log: log(f'sign change in ({a!r}, {b!r})')
    return iv, len(ts)
