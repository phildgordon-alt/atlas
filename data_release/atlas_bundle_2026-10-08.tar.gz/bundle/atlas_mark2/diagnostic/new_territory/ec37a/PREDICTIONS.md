# 37.a1 target runs — pre-registered 2026-10-07 (written after validation [0,10] + negative controls, BEFORE any target run)

Code: ec37a/ as frozen in CODE_SHA256_FROZEN.txt (incl. a_p table ap_3000010.npy sha 9d5ead2f…, THEORY_37A.md).
Runs: run_targets.sh — gen_cert.py 37.a1 on chunks [10k, 10k+10], k = 1..9 ([10,100]) then k = 10..19 ([100,200]); defaults
(--margin 6 --cell 0.5 --step 0.02); each chunk replayed in a fresh process (replay_deg2.py: rows recomputed with x1.5 prime cut-offs,
24 nodes, h = 0.4; every sign-change endpoint re-verified with the A = 1.2 series, complex overlap with A = 1; replay_verify.py plain +
hardened). Then union.py 0 200 over runs/val_0_10 + the 19 chunks (exact Fractions), lean_gap_check.py over all certificates, and a
fresh-process verify_ap.py of the a_p table.

**P1 (main prediction).** All 19 target chunks close (every certificate passes plain + hardened replay; per-chunk exact tiling 0 gaps),
and the union with the validation window covers [0, 200] with 0 gaps. Claim if met: every zero of L(E, s), E = 37.a1, with ordinate
in [0, 200] (hence, by symmetry, in [−200, 200]) lies on the critical line and is simple (simplicity via Lemma 2; the central zero's
simplicity also via Lemma C, central.py).

**P2 (diagnostic).** Sign changes found per chunk = main term N(b) − N(a), N(T) = (T/π) log(√37 T/(2πe)), within ±2:

| chunk | main term | predicted |
|---|---|---|
| [10, 20] | 8.46 | 8 |
| [20, 30] | 10.12 | 10 |
| [30, 40] | 11.20 | 11 |
| [40, 50] | 12.01 | 12 |
| [50, 60] | 12.65 | 13 |
| [60, 70] | 13.18 | 13 |
| [70, 80] | 13.64 | 14 |
| [80, 90] | 14.04 | 14 |
| [90, 100] | 14.39 | 14 |
| [100, 110] | 14.71 | 15 |
| [110, 120] | 15.00 | 15 |
| [120, 130] | 15.26 | 15 |
| [130, 140] | 15.51 | 16 |
| [140, 150] | 15.74 | 16 |
| [150, 160] | 15.95 | 16 |
| [160, 170] | 16.15 | 16 |
| [170, 180] | 16.34 | 16 |
| [180, 190] | 16.51 | 17 |
| [190, 200] | 16.68 | 17 |

Totals: [10,100] ≈ 110, [100,200] ≈ 158, [10,200] ≈ 268 (±3). In [10, 16.2] the sign changes must match LMFDB's listed zeros
(10.775, 11.757, 12.958, 15.604, 16.192) — diagnostic only.

**Falsifiers.** Any chunk not closed (reported with location and failing status), any replay failure, any union gap, any Lean-surfaced
condition violated, verify_ap.py not VERIFIED. P2 misses are reported but do not affect P1.
