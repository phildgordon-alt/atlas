# 37.a1 (y² + y = x³ − x, N = 37, rank 1, ε = −1): results (2026-10-07)

**Outcome: P1 MET.** All 19 pre-registered target chunks closed; with the validation window, the exact union covers [0, 200] with 0 gaps.
* Pre-registration: `PREDICTIONS.md`, sha256 d6f9432e…38f3 (`PREDICTIONS.sha256`), written 19:00 after validation + negative controls and
  before any target run; unchanged. Code frozen in `CODE_SHA256_FROZEN.txt` (all files re-checked OK after the runs).
* Theory: `THEORY_37A.md` (new: Lemma Z — Z(t) = e^{πt/2} Im Λ(1+it) for ε = −1; Lemma C — central zero of order exactly 1;
  point-count a_p with a proof-carrying verifier). Everything else inherited from `../deg2/THEORY_DEG2.md`.

**Claim.** Every zero of L(E, s), E = 37.a1, with ordinate in [0, 200] — hence, by γ ↦ −γ symmetry, in [−200, 200] — lies on the
critical line and is simple. At t = 0 this means: the only zero with ordinate 0 is the central zero s = 1/2 (no real off-line zero),
and it is simple (Lemma C, `central.py`, independent of the LP: Λ'(1) = 0.296238908699800732300615056835 ± 5e−31,
L'(E,1) = 0.305999773834052301820483683322 ± 4e−31; and again via Lemma 2 in cell [0, 0.5], where the interval
(−1.4e−10, 4.6e−10) straddling 0 carries weight w = 0.98). Simplicity of the non-central zeros rests on Lemma 2 (parity lemma;
its logic is formalized in Lean, `formal/` `Cert.lemma2_parity`; Lemma 1's parity premise is a hypothesis there).

## Runs (all nice -n 19, one heavy process at a time; gen peak footprint ≤ 403 MB, replay ≤ 168 MB)

| window | sign changes in target | cells (plain + hardened) | min hardened margin | gen s | replay s |
|---|---|---|---|---|---|
| validation [0, 10] | 5 (0, 5.0032, 6.8704, 8.0143, 9.9331) | 20/20 | 1.883 | 85 | 96 |
| [10,20] … [90,100] | 9, 10, 11, 11, 13, 13, 14, 14, 15 | 9 × 20/20 | 1.800 | 90–180 | 54–89 |
| [100,110] … [190,200] | 15, 14, 15, 16, 16, 16, 15, 17, 17, 17 | 10 × 20/20 | 1.795 | 201–470 | 59–80 |

400 certificates, 400 pass both replays, every chunk's exact tiling closed, union [0, 200] 0 gaps (`logs/union.json`); one a_p table
sha and one replay_verify sha (82b38196…, identical to deg2's) across all chunks. Total compute ≈ 74 min generation + 23 min replay,
plus 44 s (a_p search to 3e6) + 19 s (a_p verification). 273 distinct sign changes in [0, 200] (incl. the central one).

**P2 (diagnostic) MET:** every chunk's count is within ±1 of the main-term prediction (±2 allowed); [10, 200] total 268 vs predicted 268.
LMFDB (`diagnostics/lmfdb_37a.json`, 9 listed zeros ≤ 16.19): all matched by sign-change intervals to ~1e−9; HIK's "5 zeros with
nonnegative ordinates in |t| ≤ 10" matched.

## Checks on every certificate
* Replay (fresh process): rows recomputed (×1.5 prime cut-offs, 24 nodes, h = 0.4, other precision), far allowances and N_win
  recomputed, every sign-change endpoint re-verified with the A = 1.2 series at +40 bits with **complex** overlap against A = 1;
  `replay_verify.py` plain and hardened.
* Lean-surfaced conditions (formal/README findings 1–3): enforced in `replay_verify.py` (BAD_DRANGE / BAD_CELL / BAD_INTERVALS) and
  re-checked in exact rationals on the stored JSON by `lean_gap_check.py`: 428 files (400 real + 28 NC), 12 156 intervals, **0 violations**
  of (1) candidate box [x0,x1] × [0, 1/2] incl. d = 0, (2) cell ⊂ window, (3) intervals ⊂ window.
* a_p table (ap_3000010.npy, sha 9d5ead2f…): `verify_ap.py` VERIFIED twice in fresh processes with different seeds — naive count for
  p < 20 000 (2262 primes), order-uniqueness proof for all 216 816 primes ≥ 1000 (≈ 215.6k on E, ≈ 1k via the twist); a_37 = −1.
  a_p for p ≤ 113 match LMFDB.

## Negative controls (validation window [0, 10]; `negctl.sh`, outputs in `runs/nc/`, never written to replay.json)

| control | observed |
|---|---|
| fake sign change (3.0, 3.1) injected into the generator | generator: 20/20 INCONSISTENT, emits nothing |
| same fake interval forged into all 20 real certificates (w = 0.5) | replay 20/20 NO_SIGN_CHANGE (Z has the same sign at both ends) |
| a_2 + 1, replay rows + Z | 20/20 rejected (A-split series mismatch) |
| a_2 + 1, rows only (true Z) | 20/20 INCONSISTENT |
| a_2 + 1 in the generator's rows | 0/20 certified (INCONSISTENT) |
| wrong root number ε = +1, replay of the true certificates | 20/20 rejected (series mismatch: A = 1 value real, A = 1.2 not) |
| generator scanning the wrong Z (ε = +1) | emitted 8 certificates; replay with true data: 8/8 NO_SIGN_CHANGE; replay with ε = +1: 8/8 series mismatch |
| wrong conductor N = 38 (rows + Z) | 20/20 rejected (series mismatch) |

Limits: rows do not depend on ε, so the root-number control exercises only the Z / sign-change side (that is where ε enters).
The ε = +1 generator run shows that the generator alone would accept a wrong ε for some cells; only the replay's complex A-split
check rejects it — so that check is load-bearing for ε.

## Proved vs trusted
**Proved here:** Lemma Z (reality, multiplicity, odd sign symmetry of Z for ε = −1), Lemma C (order exactly 1, given Arb), the a_p
verification argument (given Hasse), plus everything listed as proved in THEORY_DEG2 §9 (Lemma T, explicit formula adaptation,
quadrature bound, Lemma N, far allowances, certificate theorem, Lemma 2 — the last two with Lean-checked logic).
**Trusted:** Arb/FLINT (python-flint 0.9.0); modularity of E (Λ entire, FE with N = 37, ε = −1 — ε and N also checked numerically by
the complex A-split); Hasse's bound; Rosser–Schoenfeld; Trefethen's Gauss–Legendre bound; Iwaniec–Kowalski Thm 5.6 (Lorentzian rows
only). Untrusted: HiGHS, the generator, the BSGS search.

## Novelty status (moderate confidence; basis ../PRIOR_VERIFICATION.md, ../TARGETS.md)
* Hiary–Ireland–Kyi, arXiv:2408.00187 §7.4: RH for 37.a1 for |t| ≤ 10, using LMFDB/lcalc zeros as input. Our [0, 10] reproduces it
  (with zeros discovered, not input); [10, 200] extends it 20-fold in height.
* Best et al. (arXiv:2002.04717 §10.3): RH "up to height b" for all LMFDB CMF L-functions (37.2.a.a included), b unstated; Platt's
  code implies b = 32 for degree 2 (inference, not published); LMFDB lists 37.a zeros only to 16.19.
* So: [0, 10] is published (HIK); [10, ~32] is plausibly covered by the unpublished-height LMFDB check; **[32, 200] is not found in the
  published literature or LMFDB as of October 2026, to our knowledge.** Experts best placed to confirm: Hiary, Platt, Costa, Booker.
* Method contrast: like HIK/Büthe, but zeros are found by rigorous Arb sign changes, certificates are LP duals replayed independently,
  and simplicity (incl. the central zero) is certified.
