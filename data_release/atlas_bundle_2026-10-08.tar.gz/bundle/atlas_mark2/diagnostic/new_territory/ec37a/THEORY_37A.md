# Atlas degree-2 pipeline for E = 37.a1: theory (written before coding, 2026-10-07)

E = 37.a1: y² + y = x³ − x, conductor N = 37, rank 1, root number ε = −1, newform 37.2.a.a (weight k = 2, trivial character).
Everything not stated here is inherited unchanged from `../deg2/THEORY_DEG2.md` (cited as D§n). This note covers only what is
new: ε = −1, the central zero, and coefficients that do not come from an η-product.

## 0. Normalizations (as D§0)

* Arithmetic: Λ(s) = (√37/2π)^s Γ(s) L(E,s), entire (modularity: Wiles, Taylor–Wiles, BCDT), and Λ(s) = −Λ(2 − s).
* Analytic: Λ_an(s) = Λ(s + 1/2), Λ_an(s) = −Λ_an(1 − s). Zeros ρ = 1/2 + iγ, |Re ρ − 1/2| < 1/2.
* Real a_n ⇒ Λ(s̄) = conj Λ(s). With the FE, ρ ↦ ρ̄, 1 − ρ, 1 − ρ̄ preserve zeros and multiplicities. So:
  * an off-line zero has a partner at the **same ordinate** (atoms as in D§0, unchanged);
  * the zero set is symmetric under γ ↦ −γ (with multiplicity). A claim for ordinates in [0, T] gives the same claim on [−T, T].

## 1. Hardy-type Z for ε = −1

**Definition.** Z(t) := e^{πt/2} · Im Λ(1 + it) = −i e^{πt/2} Λ(1 + it).

**Lemma Z.** (a) Λ(1 + it) ∈ iℝ for real t, so Z is real. (b) Z is real-analytic and its zeros are exactly the ordinates of on-line zeros,
with the same multiplicity. (c) sign Z(−t) = −sign Z(t). (d) Λ(1) = 0, and the order of Λ at s = 1 is odd.

*Proof.* (a) conj Λ(1+it) = Λ(1−it) (real coefficients) = Λ(2 − (1+it)) = −Λ(1+it) (FE, ε = −1). A complex number equal to minus its
conjugate is purely imaginary, so Λ(1+it) = i·Im Λ(1+it) and Z(t) = −i e^{πt/2} Λ(1+it) is real.
(b) −i e^{πt/2} is a nowhere-vanishing entire function of t and d/dt = i d/ds on s = 1 + it, so ord_{t0} Z = ord_{1+it0} Λ.
(c) Im Λ(1−it) = Im conj Λ(1+it) = −Im Λ(1+it), and e^{±πt/2} > 0.
(d) g(z) := Λ(1+z) satisfies g(−z) = −g(z) (FE), so every even Taylor coefficient of g at 0 vanishes; in particular g(0) = 0 and
ord_0 g is odd. ∎

For ε = +1 the same argument gives Λ(1+it) ∈ ℝ, and D§1's Z = e^{πt/2} Re Λ(1+it). The code uses Z = e^{πt/2}·(Re Λ if ε = +1, Im Λ if
ε = −1); "wrong root number" means using the other choice together with the other ε in the series.

**Evaluator.** Λ is evaluated exactly as D§1 (Lemma T: the A-split series with an explicit geometric tail), with ε = −1 in the series.
Lemma T only uses |a_n| ≤ 2n^{k/2} = 2n, which holds here (Hasse at good p, |a_37| = 1, multiplicativity, d(n) ≤ 2√n). The A = 1 series
satisfies the FE formally for **any** ε, so its value on the line is purely imaginary up to rounding whatever the data. The A = 1.2 series
reproduces it only if N, ε and the a_n are right. The replay therefore requires the **complex** A = 1 and A = 1.2 balls to overlap at every
sign-change endpoint (both real and imaginary parts; deg2 compared only the real part Z). With the wrong ε, the A = 1 value is real and
the A = 1.2 value is not, so the check fails (negative control C3).

## 2. The central zero

**Lemma C (order exactly 1).** ord_{s=1} L(E,s) = 1, i.e. the analytic central zero ρ = 1/2 is simple.

*Proof.* By Lemma Z(d) the order is odd. Differentiate the A = 1 series. With h(u) := x^{−u}Γ(u, x) = ∫_1^∞ v^{u−1}e^{−xv} dv,

    h'(1) = ∫_1^∞ log v · e^{−xv} dv = E_1(x)/x        (integrate by parts),

and Λ(s) = Σ a_n [h_n(s) + ε h_n(2 − s)], so Λ'(1) = (1 − ε) Σ a_n E_1(x_n)/x_n = 2 Σ_n a_n E_1(x_n)/x_n, x_n = 2πn/√37.
Since L(E,1) = 0 and Γ(1) = 1, Λ'(1) = (√37/2π) L'(E,1), i.e. the classical L'(E,1) = 2 Σ a_n E_1(2πn/√37)/n.
Tail: E_1(x) ≤ e^{−x}/x and |a_n| ≤ 2n give |term_n| ≤ 4e^{−x_n}/x_n², with consecutive ratio ≤ e^{−2π/√37} < 0.36 beyond any m, so
the omitted part beyond M is ≤ T_{M+1}/(1 − 0.36). E_1 is an Arb ball (`acb.gamma_upper` at s = 0). If the resulting ball for
Λ'(1) excludes 0 (expected L'(E,1) ≈ 0.3060), the order is exactly 1. ∎ (`central.py`)

This proof is independent of the LP certificates. The certificates give it a second time: see below.

**The t = 0 neighbourhood in the certificates.**
* The scan grid passes through t = 0, where Z(0) = 0 exactly (ball contains 0). D§6's nudge moves that point to t = +1e−7, where
  |Z| ≈ Λ'(1)·1e−7 ≈ 3e−8 is resolved. The sign change between t < 0 and t > 0 is then bisected to an interval (t1, t2) with t1 < 0 < t2.
  The replay re-verifies both endpoints like any other (A = 1.2 at +40 bits, overlap with A = 1).
* Lemma 1 (D§6) gives on-line zeros of **odd** total multiplicity in (t1, t2). Nothing else about the interval is special: the window
  W = [−6, 16] (for target [0, 10]) contains the mirror zeros at negative ordinates, found independently by the scan (their signs are
  forced by Lemma Z(c), which is a diagnostic check, not an input).
* The explicit formula (D§3) is independent of ε: the FE is used only as Λ'/Λ(s) = −Λ'/Λ(1−s), which holds for ε = ±1. The central
  zero enters every row as the atom (0, 0, 1) and contributes sech(a·x) to a sech row at x, like any other on-line zero. The Lorentzian
  rows use Hadamard with Re B = −Σ Re 1/ρ (Iwaniec–Kowalski Thm 5.6, self-dual), also independent of ε; Λ_an(0) = Λ(1/2) ≠ 0 since the
  arithmetic zeros satisfy 1/2 < Re s < 3/2.
* **What a certified cell [0, x1] proves at t = 0:** every zero with ordinate 0 is on the line and simple. Ordinate 0 on the line is
  exactly s = 1/2 (analytic), so: (i) Λ_an has no real zero off the line, i.e. no zero β ≠ 1/2 in (0, 1); (ii) the central zero is
  simple (Lemma 2, the parity lemma, applied with x⋆ = 0 ∈ (t1, t2): a multiple central zero would force n_i ≥ 3). (ii) duplicates
  Lemma C, which does not depend on Lemma 2. The Lean formalization (`formal/`, `Cert.lemma2_parity`) covers Lemma 2's logic.
* Negative ordinates are not certified separately; they follow by the symmetry γ ↦ −γ.

## 3. Coefficients

37.a1 is not an η-quotient, so a_p is computed by counting points.
* **Small p (p < 20 000, including p = 2, 3, 37).** Directly on y² + y = x³ − x over F_p: #E(F_p) = 1 + #{(x,y) ∈ F_p²}, counted
  exactly with a histogram of y² + y mod p (numpy, exact integers). a_p = p + 1 − #E(F_p). For p = 37 (bad, multiplicative) the reduced
  curve has one singular point, counted among the affine points, and a_37 = 37 + 1 − #Ẽ(F_37); expected a_37 = −1 (non-split), which
  matches ε = w_∞·w_37 = (−1)(−a_37) = a_37 = −1 (multiplicative reduction at the only bad prime; consistency check, not an input).
* **All good p ≥ 5 (search, untrusted).** Model Y² = X³ − 16X + 16 (X = 4x, Y = 4(2y + 1); valid for p odd), baby-step giant-step for
  m·Q = O with m in the Hasse interval, intersecting candidate sets over random points and the quadratic twist (#E + #E' = 2p + 2).
* **Verification (trusted, separate code).** For each p ≥ 1000 the claimed a_p is accepted only if |a_p| ≤ 2√p (exactly: a_p² ≤ 4p) and
  some point Q on E with (p+1−a_p)·Q = O and exact order ord(Q) > 4√p is exhibited (or the same on the twist with p+1+a_p). Then the
  Hasse interval (length 4√p, Hasse's theorem trusted) contains exactly one multiple of ord(Q), and #E(F_p) is such a multiple
  (Lagrange), so #E(F_p) = p+1−a_p. ord(Q) is computed exactly by factoring the group order (trial division). For p < 20 000 the naive
  count is the proof and BSGS must agree with it (cross-check on [1000, 20 000]).
* **Diagnostics.** a_p for p ≤ 113 against LMFDB (`diagnostics/lmfdb_37a.json`, euler_factors); Hecke relation consistency is automatic
  (a_n built multiplicatively); Hasse for every p.
* a_n for n ≤ 6000 (only n ≲ 500 is needed by the Λ series at t ≤ 206) from a_{p^{j+1}} = a_p a_{p^j} − p a_{p^{j−1}} (good p),
  a_{37^j} = (−1)^j, and multiplicativity.

Arithmetic side (D§2): c(p^m) = (α^m + β^m) log p for good p, c(37^m) = (−1/√37)^m log 37. |c(n)| ≤ 2Λ(n) holds.

## 4. Unchanged pieces (inherited verbatim, with N = 37, k = 2)

Lemma T and the A-split (D§1), the sech explicit formula with its archimedean quadrature bound and prime truncation (D§3), Lemma N and the
far allowances (D§4), Lorentzian rows ε = 1.5 (D§5), Lemma 1 (D§6), the certificate theorem and Lemma 2 (D§7), the replay with
re-computed rows at ×1.5 prime cut-offs / 24 nodes / h = 0.4, and the exact Fraction tiling (D§8). Lemma N for N = 37:
Cnt(T) = [(1/2) log(37/4π²) + log(1+|T|) + 2 + 4G/π + 4(−ζ'/ζ)(1/2 + π/2)] / sech(1/2).

Prime cut-offs: same as deg2 (generator 3e5 / 1e6 / 2e6 for a = 0.8 / 1 / 1.25, 1e6 for Lorentzian; replay ×1.5, so a_p is needed for
p ≤ 3e6) if the a_p table is affordable; otherwise smaller cut-offs, which only enlarge the (tiny) truncation radii.

## 5. Conditions enforced on every certificate (formal/README.md findings 1–3)

(1) (C) on the closed box with d0 = 0 (d_range exactly [0, 1/2], candidate box seeded by the verifier); (2) cell ⊂ window;
(3) every sign-change interval ⊂ window, sorted, disjoint. Enforced by `replay_verify.py` and re-checked on the stored JSON in exact
rationals by `lean_gap_check.py`.

## 6. Rigor ledger (additions to D§9)

Proved here: Lemma Z, Lemma C (given Arb), the a_p verification argument. Trusted additionally: modularity of E (Λ entire with this FE
and ε = −1; ε also checked numerically by the complex A-split); Hasse's theorem (a_p verification and coefficient bounds); the curve
equation / label identification (cross-checked against LMFDB a_p as a diagnostic).
