"""Arithmetic side for a weight-k newform (analytic normalization: zeros rho = 1/2 + i gamma_rho, Euler product for Re s > 1).

  -L'/L(s) = sum_n c(n) n^{-s},  c(p^m) = (alpha_p^m + beta_p^m) log p (good p; alpha beta = chi(p), alpha + beta = lam_p = a_p p^{-(k-1)/2}),
                                 c(p^m) = lam_p^m log p (bad p),       |c(n)| <= 2 Lambda(n)   (Hasse / Deligne-Serre).
Sech row (THEORY_DEG2.md section 3):
  E_a(x) = sum_rho Re sech(a (gamma_rho - x))
         = (1/2a) log(N/4pi^2) + arch_a(x) - 2 sum_{n<=P} c(n) n^{-1/2} f(log n) cos(x log n)  +/- TailP,
  f(u) = (1/2a) sech(b u), b = pi/(2a);  TailP = (4/a) * 1.03883 * sig P^{1-sig}/(sig-1), sig = 1/2 + b.
  arch_a(x) = (1/2pi) int sech(a s) 2 Re psi(k/2 + i(s+x)) ds   (Gauss-Legendre panels with Bernstein-ellipse remainder + tail).
Lorentzian row, eps > 1/2 (section 5):
  M_eps(t) = Re Lambda'/Lambda(1/2+eps+it) = log(sqrt N/2pi) + Re psi(k/2+eps+it) - Re sum_{n<=P} c(n) n^{-1/2-eps-it} +/- 2*1.03883 sig P^{1-sig}/(sig-1), sig=1/2+eps
Counting bound (section 4): #{rho: |gamma - T| <= 1/2} <= Cnt(T) for every real T."""
import math
from flint import arb, acb, ctx
import forms

RS = arb('1.03883')   # Rosser-Schoenfeld 1962 Thm 12: psi(x) < 1.03883 x for x > 0

class Arith:
    def __init__(self, F, P, prec=96):
        self.F = F; self.P = P; self.prec = prec; k = F['k']; a = F['ap']      # ec37a: a_p table (curve37 / verify_ap)
        assert len(a) > P, 'need a_p for p <= P'
        old = ctx.prec; ctx.prec = prec
        try:
            pr = forms.primes_upto(P); self.terms = []   # (logn, c(n) n^{-1/2})
            for p in pr:
                p = int(p); lp = arb(p).log()
                lam = arb(int(a[p])) / arb(p) ** (arb(k - 1) / 2)
                bad = p in F['bad']; chi = 0 if bad else F['char'](p)
                e_prev, e = arb(2), lam      # e_m = alpha^m + beta^m (good);  lam^m (bad)
                pm = p; m = 1; lam_m = lam
                while pm <= P:
                    val = (lam_m if bad else e) * lp / arb(pm).sqrt()
                    self.terms.append((m * lp, val))
                    pm *= p; m += 1
                    if bad: lam_m = lam_m * lam
                    else: e_prev, e = e, lam * e - chi * e_prev
        finally:
            ctx.prec = old
        self.npp = len(self.terms)

    # ---------- tails ----------
    def tail_sum(self, sig):
        """bound for sum_{n > P} Lambda(n) n^{-sig}, sig > 1"""
        s = arb(sig); P = arb(self.P)
        return RS * s * P ** (1 - s) / (s - 1)

    # ---------- archimedean term for the sech row ----------
    def arch(self, a, x, nodes=20, h=0.5, H=None, S=None):
        k = self.F['k']; A = arb(a); X = arb(x)
        if H is None: H = min(0.6, 0.6 * k / 2, 0.6 * math.pi / (2 * a))
        assert H < k / 2 and a * H < math.pi / 2
        if S is None: S = math.ceil(46.0 / a)
        nh = int(math.ceil(S / (2 * h))); S = nh * 2 * h
        rho = (H / h) + math.sqrt((H / h) ** 2 + 1)      # semi-minor h (rho - 1/rho)/2 = H
        semimaj = h * (rho + 1 / rho) / 2
        gl = [arb.legendre_p_root(nodes, i, weight=True) for i in range(nodes)]
        kh = arb(k) / 2
        def g(s):   # sech(a s) * (psi(k/2 + i(s+x)) + psi(k/2 - i(s+x)))  [= 2 sech Re psi on the real line]
            w = acb(0, 1) * (s + X)
            return (kh + w).digamma() / (A * s).cosh() + (kh - w).digamma() / (A * s).cosh()
        tot = acb(0); err = arb(0)
        Rho = arb(rho); fac = arb(64) / 15 * Rho ** (-2 * nodes) / (Rho * Rho - 1)
        for j in range(-nh, nh):
            c = arb(2 * h * j + h)
            for xi, wi in gl:
                tot += wi * h * g(acb(c + h * xi))
            M = self._boxmax(g, float(c.mid()) - semimaj, float(c.mid()) + semimaj, -H, H)
            err += fac * h * M
        # tail |s| > S:  (4/pi) e^{-aS} (A0/a + 1/a^2),  A0 = log(1 + S + |x|) + 2
        A0 = (1 + arb(S) + abs(X)).log() + 2
        tail = 4 / arb.pi() * (-A * S).exp() * (A0 / A + 1 / (A * A))
        val = tot.real / (2 * arb.pi())
        rad = err / (2 * arb.pi()) + tail
        return val + arb(0, rad.upper())

    @staticmethod
    def _boxmax(g, x0, x1, y0, y1, depth=0):
        """rigorous upper bound of |g| on the closed rectangle [x0,x1] x [y0,y1] (adaptive subdivision)"""
        b = acb(arb((x0 + x1) / 2, (x1 - x0) / 2), arb((y0 + y1) / 2, (y1 - y0) / 2))
        v = abs(g(b))
        if v.is_finite() and (depth >= 3 or v.rad() < 0.25 * v.mid()):
            return v.upper()
        if depth >= 8:
            assert v.is_finite(), 'box maximum not resolved'
            return v.upper()
        xm = (x0 + x1) / 2; ym = (y0 + y1) / 2
        return max(Arith._boxmax(g, x0, xm, y0, ym, depth + 1), Arith._boxmax(g, xm, x1, y0, ym, depth + 1),
                   Arith._boxmax(g, x0, xm, ym, y1, depth + 1), Arith._boxmax(g, xm, x1, ym, y1, depth + 1))

    # ---------- rows ----------
    def sech_row(self, a, x, **kw):
        old = ctx.prec; ctx.prec = self.prec
        try:
            A = arb(a); b = arb.pi() / (2 * A); X = arb(x)
            s = arb(0)
            for L, v in self.terms:
                s += v * (b * L).sech() * (X * L).cos()
            prime = -2 * s / (2 * A)
            sig = 0.5 + math.pi / (2 * a)
            tail = 4 / A * self.tail_sum(sig)
            cst = (arb(self.F['N']) / (4 * arb.pi() ** 2)).log() / (2 * A)
            ar = self.arch(a, x, **kw)
            v = cst + ar + prime + arb(0, tail.upper())
        finally:
            ctx.prec = old
        return v

    def lor_row(self, eps, t):
        assert eps > 0.5
        old = ctx.prec; ctx.prec = self.prec
        try:
            E = arb(eps); T = arb(t); s = acb(arb(0.5) + E, T)
            acc = acb(0)
            for L, v in self.terms:
                acc += v * (-(s - arb(0.5)) * L).exp()      # c(n) n^{-1/2} n^{-(s - 1/2)} = c(n) n^{-s}
            sig = 0.5 + eps
            tail = 2 * self.tail_sum(sig)
            g = (arb(self.F['N']).sqrt() / (2 * arb.pi())).log() + (acb(arb(self.F['k']) / 2 + E, T)).digamma().real
            v = g - acc.real + arb(0, tail.upper())
        finally:
            ctx.prec = old
        return v

# ---------- zero counting bound (section 4) ----------
CATALAN = None
def count_bound(F, T):
    """upper bound (arb) for the number of zeros (with multiplicity, any beta) with |gamma - T| <= 1/2.  Uses a0 = 1."""
    old = ctx.prec; ctx.prec = 96
    try:
        a0 = arb(1); b0 = arb.pi() / 2
        G = arb.const_catalan()
        zeta_part = -(acb_series_logderiv_zeta(arb(0.5) + b0))      # -zeta'/zeta(1/2 + pi/2) > 0
        num = (arb(F['N']) / (4 * arb.pi() ** 2)).log() / (2 * a0) + ((1 + abs(arb(T))).log() + 2) / a0 + 4 * G / (arb.pi() * a0 * a0) + 4 / a0 * zeta_part
        umin = arb(0.5).sech()
        u2 = (arb(0.5)).cosh() * arb(0.5).cos() / (arb(0.5).sinh() ** 2 + arb(0.5).cos() ** 2)
        umin = umin if umin.upper() < u2.lower() else None
        assert umin is not None
        v = num / umin
    finally:
        ctx.prec = old
    return v

def acb_series_logderiv_zeta(x):
    from flint import acb_series
    z = acb_series([acb(x), 1], prec=2).zeta().coeffs()
    return (z[1] / z[0]).real
