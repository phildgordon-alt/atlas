"""Lemma C (THEORY_37A.md section 2): the central zero of L(E, s), E = 37.a1, has order exactly 1.
Lambda(1+z) is odd in z (FE with eps = -1), so the order at s = 1 is odd; it is 1 iff Lambda'(1) != 0, where
  Lambda'(1) = 2 sum_n a_n E_1(x_n)/x_n,  x_n = 2 pi n/sqrt(37),   and   L'(E, 1) = (2 pi/sqrt 37) Lambda'(1) = 2 sum a_n E_1(x_n)/n.
Tail beyond M: |a_n| <= 2n, E_1(x) <= e^{-x}/x  =>  |term_n| <= 4 e^{-x_n}/x_n^2 (for the Lambda' sum: 2 * 2n * e^{-x}/x^2),
consecutive ratio <= ((n+1)/n)^... bounded by q = e^{-2 pi/sqrt 37} * (1 + 1/M) < 1, tail <= T_{M+1}/(1-q).
Also prints Lambda(1) (A = 1 and A = 1.2) and the signs of Z(+-t) for small t (Lemma Z(c), diagnostic)."""
import json, math
from flint import arb, acb, ctx
import forms, lfun

def lam_prime_1(F, M=200, prec=200):
    old = ctx.prec; ctx.prec = prec
    try:
        x0 = 2 * arb.pi() / arb(37).sqrt(); s = arb(0)
        for n in range(1, M + 1):
            if F['a'][n] == 0: continue
            x = x0 * n
            E1 = acb(x).gamma_upper(acb(0)).real          # Gamma(0, x) = E_1(x)
            s += F['a'][n] * E1 / x
        tot = 2 * s
        m = M + 1; xm = x0 * m
        Tm = 2 * 2 * m * (-xm).exp() / (xm * xm)          # 2 * |a_m| * E_1(x)/x  with |a_m| <= 2m
        q = (-x0).exp() * (1 + arb(1) / m) ** 3            # ratio bound n -> n+1 (factor (n+1)/n * (x_n/x_{n+1})^2 <= (1+1/m))
        assert q < 1
        tail = Tm / (1 - q)
        tot = tot + arb(0, tail.upper())
        Lp = tot * x0                                       # L'(E,1) = (2 pi / sqrt 37) Lambda'(1)
    finally:
        ctx.prec = old
    return tot, Lp, tail

if __name__ == '__main__':
    F = forms.form('37.a1', 1000)
    lp, Lp, tail = lam_prime_1(F)
    l1 = lfun.Lam(F, acb(1, 0)); l12 = lfun.Lam(F, acb(1, 0), A=1.2)
    zs = {t: (lfun.sign(lfun.Z(F, t)), lfun.sign(lfun.Z(F, -t))) for t in (1e-7, 1e-3, 0.1, 1.0, 3.0)}
    out = dict(Lambda_prime_1=lp.str(30), L_prime_E_1=Lp.str(30), tail_bound=float(tail.upper()),
               nonzero=bool(lp.lower() > 0 or lp.upper() < 0), Lambda_1_A1=l1.str(10), Lambda_1_A12=l12.str(10),
               Lambda_1_contains_0=bool(l12.real.contains(0) and l12.imag.contains(0)),
               sign_Z_plus_minus=zs, odd_signs=all(a == -b != 0 for a, b in zs.values()),
               verdict=('ORDER_EXACTLY_1' if (lp.lower() > 0 or lp.upper() < 0) else 'UNRESOLVED'),
               lmfdb_expected_L_prime='0.305999773834052301820483683321676...  (diagnostic)')
    print(json.dumps(out, indent=1))
