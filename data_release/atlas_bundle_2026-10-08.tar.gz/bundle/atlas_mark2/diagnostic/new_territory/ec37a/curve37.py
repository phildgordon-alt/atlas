"""a_p of E = 37.a1 : y^2 + y = x^3 - x  (THEORY_37A.md section 3).
* naive_ap(p): exact count on the original equation (any p), histogram of y^2 + y mod p.        [proof for p < NAIVE_MAX]
* bsgs_ap(p):  baby-step giant-step on Y^2 = X^3 - 16X + 16 (X = 4x, Y = 4(2y+1)), with twist.  [UNTRUSTED search]
* build(P):    table ap[0..P] (ap[n] = 0 for composite n), saved as ap_P.npy;  verify_ap.py proves it.
usage: python curve37.py PMAX"""
import sys, math, random, time
import numpy as np

A4, A6 = -16, 16          # short model of 37.a1
NAIVE_MAX = 20000

def primes_upto(n):
    s = np.ones(n + 1, bool); s[:2] = False
    for i in range(2, int(n ** 0.5) + 1):
        if s[i]: s[i * i::i] = False
    return np.nonzero(s)[0]

def naive_count(p):
    """#E(F_p) projective (incl. the singular point when p = 37) for y^2 + y = x^3 - x"""
    y = np.arange(p, dtype=np.int64); h = np.bincount((y * y + y) % p, minlength=p)
    x = np.arange(p, dtype=np.int64); r = (x * x % p * x - x) % p
    return 1 + int(h[r].sum())

def naive_ap(p):
    return p + 1 - naive_count(p)

# ---------- affine arithmetic on Y^2 = X^3 + a X + b over F_p  (None = O) ----------
def add(P, Q, a, p):
    if P is None: return Q
    if Q is None: return P
    x1, y1 = P; x2, y2 = Q
    if x1 == x2:
        if (y1 + y2) % p == 0: return None
        l = (3 * x1 * x1 + a) * pow(2 * y1, -1, p) % p
    else:
        l = (y2 - y1) * pow(x2 - x1, -1, p) % p
    x3 = (l * l - x1 - x2) % p
    return (x3, (l * (x1 - x3) - y1) % p)

def mul(n, P, a, p):
    if n < 0: n = -n; P = None if P is None else (P[0], (-P[1]) % p)
    R = None
    while n:
        if n & 1: R = add(R, P, a, p)
        P = add(P, P, a, p); n >>= 1
    return R

def sqrt_mod(n, p):
    """a square root of a quadratic residue n mod odd prime p (Tonelli-Shanks); None if non-residue"""
    n %= p
    if n == 0: return 0
    if pow(n, (p - 1) // 2, p) != 1: return None
    if p % 4 == 3: return pow(n, (p + 1) // 4, p)
    q, s = p - 1, 0
    while q % 2 == 0: q //= 2; s += 1
    z = 2
    while pow(z, (p - 1) // 2, p) != p - 1: z += 1
    m, c, t, r = s, pow(z, q, p), pow(n, q, p), pow(n, (q + 1) // 2, p)
    while t != 1:
        i, tt = 0, t
        while tt != 1: tt = tt * tt % p; i += 1
        b = pow(c, 1 << (m - i - 1), p); m, c, t, r = i, b * b % p, t * b * b % p, r * b % p
    return r

def random_point(a, b, p, rng):
    while True:
        x = rng.randrange(p); y = sqrt_mod(x * x * x + a * x + b, p)
        if y is not None and y != 0: return (x, y)

def nonresidue(p):
    g = 2
    while pow(g, (p - 1) // 2, p) != p - 1: g += 1
    return g

def hasse(p):
    r = math.isqrt(4 * p)                       # floor(2 sqrt p)
    return p + 1 - r, p + 1 + r

def bsgs_multiples(Q, a, p, lo, hi):
    """all m in [lo, hi] with m Q = O (exhaustive by BSGS)"""
    L = hi - lo + 1; s = max(1, math.isqrt(L // 2) + 1)
    baby = {}; R = None
    for j in range(s + 1):
        if R is not None: baby.setdefault(R[0], []).append((j, R[1]))
        R = add(R, Q, a, p)
    step = mul(2 * s + 1, Q, a, p); c = lo + s; G = mul(c, Q, a, p); out = set()
    while c - s <= hi:
        if G is None: out.add(c)
        else:
            for j, yj in baby.get(G[0], []):
                # G = +-(jQ):  G = -jQ  => (c + j)Q = O ;  G = jQ => (c - j)Q = O
                if yj == G[1]: out.add(c - j)
                if (yj + G[1]) % p == 0: out.add(c + j)
        G = add(G, step, a, p); c += 2 * s + 1
    return sorted(m for m in out if lo <= m <= hi)

def bsgs_ap(p, rng):
    lo, hi = hasse(p); a, b = A4 % p, A6 % p
    g = nonresidue(p); at, bt = a * g * g % p, b * g * g * g % p
    cand = set(range(lo, hi + 1))
    for it in range(40):
        if it % 2 == 0: Q = random_point(a, b, p, rng); ms = set(bsgs_multiples(Q, a, p, lo, hi))
        else:
            Q = random_point(at, bt, p, rng); ms = {2 * p + 2 - m for m in bsgs_multiples(Q, at, p, lo, hi)}
        cand &= ms
        if len(cand) == 1: return p + 1 - cand.pop()
    return None

def build(P, seed=1):
    rng = random.Random(seed); pr = primes_upto(P); ap = np.zeros(P + 1, dtype=np.int32); t0 = time.time(); nfall = 0
    for p in pr:
        p = int(p)
        if p < 1000 or p == 37: v = naive_ap(p)
        else:
            v = bsgs_ap(p, rng)
            if v is None: v = naive_ap(p); nfall += 1
        ap[p] = v
    return ap, dict(primes=len(pr), seconds=round(time.time() - t0, 1), naive_fallbacks=nfall)

def an_table(ap, M):
    """a_n for n <= M by multiplicativity; a_{p^{j+1}} = a_p a_{p^j} - p a_{p^{j-1}} (good p), a_{37^j} = a_37^j"""
    a = [0] * (M + 1); a[1] = 1
    pk = {}
    for p in primes_upto(M):
        p = int(p); seq = [1, int(ap[p])]; q = p * p
        while q <= M:
            seq.append(seq[-1] * int(ap[p]) if p == 37 else int(ap[p]) * seq[-1] - p * seq[-2]); q *= p
        pk[p] = seq
    spf = list(range(M + 1))
    for i in range(2, int(M ** 0.5) + 1):
        if spf[i] == i:
            for j in range(i * i, M + 1, i):
                if spf[j] == j: spf[j] = i
    for n in range(2, M + 1):
        p = spf[n]; m = n; e = 0
        while m % p == 0: m //= p; e += 1
        a[n] = pk[p][e] * a[m]
    return a

if __name__ == '__main__':
    P = int(sys.argv[1]); ap, info = build(P)
    np.save(f'ap_{P}.npy', ap); print(info)
