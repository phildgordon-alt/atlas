"""Form data for E = 37.a1 (y^2 + y = x^3 - x), newform 37.2.a.a: weight k = 2, level N = 37, root number eps = -1, a_37 = -1.
Same interface as ../deg2/forms.py.  a_p from the point-count table ap_3000010.npy (curve37.py; proved by verify_ap.py, which
must report VERIFIED for the sha256 recorded in AP_SHA256 before any certificate counts).  a_n (n <= AN_MAX) by multiplicativity.
F['a'] = a_n list (n <= AN_MAX, used by the Lambda series); F['ap'] = int array of a_p (primes <= P; used by arith.Arith).
Negative controls: perturb(F, p, delta) changes a_p (and every a_n, rebuilt multiplicatively); F['eps'] may be overridden."""
import os, hashlib
import numpy as np
import curve37

HERE = os.path.dirname(os.path.abspath(__file__))
AP_FILE = os.path.join(HERE, 'ap_3000010.npy')
AP_SHA256 = '9d5ead2f46095169f85f3169a0cd0bc0add3df7d304e523355f7b6b5d0b28095'
AN_MAX = 6000
primes_upto = curve37.primes_upto
FORMS = {'37.a1': dict(N=37, k=2, eps=-1, bad={37: None}, char=lambda p: 1)}

def _load():
    raw = open(AP_FILE, 'rb').read()
    assert hashlib.sha256(raw).hexdigest() == AP_SHA256, 'a_p table hash mismatch'
    return np.load(AP_FILE)

def form(name, M):
    F = dict(FORMS[name]); ap = _load(); assert M < len(ap), 'need a_p up to M'
    F['ap'] = ap; F['a'] = curve37.an_table(ap, AN_MAX); F['name'] = name
    F['bad'] = {37: int(ap[37])}; assert F['bad'][37] == -1
    return F

def perturb(F, p, delta):
    G = dict(F); ap = np.array(F['ap']); ap[p] += delta; G['ap'] = ap; G['a'] = curve37.an_table(ap, AN_MAX)
    G['bad'] = {37: int(ap[37])}
    return G
