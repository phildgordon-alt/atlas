"""Lean-gap check for ec37a (copied from ../deg2/lean_gap_check/check.py, root path only changed): conditions (1)-(3) of formal/README.md 'gaps', checked directly on every deg2 certificate
in exact rationals (Fraction of the stored floats). Read-only. usage: python check.py [DEG2_DIR]"""
import sys, os, glob, json
from fractions import Fraction as Q
root = sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(os.path.abspath(__file__))
files = sorted(glob.glob(os.path.join(root, 'runs', '**', 'cell_*.json'), recursive=True))
groups = {}; viol = {1: [], 2: [], 3: []}; nint = 0
for f in files:
    rel = os.path.relpath(f, os.path.join(root, 'runs')); g = rel.split('/certs/')[0]
    if g.startswith('nc/'): g = g  # negative controls listed separately
    c = json.load(open(f)); groups[g] = groups.get(g, 0) + 1
    wlo, whi = map(Q, c['window']); x0, x1 = map(Q, c['cell']); d0, d1 = map(Q, c['d_range'])
    # (1) candidate box closed with d0 = 0 (and d1 = 1/2)
    if not (d0 == 0 and d1 == Q(1, 2)): viol[1].append((rel, c['d_range']))
    # (2) candidate region inside window (and nondegenerate)
    if not (wlo <= x0 < x1 <= whi): viol[2].append((rel, c['cell'], c['window']))
    # (3) every sign-change interval inside window, nondegenerate
    for t1, t2 in c['intervals']:
        nint += 1
        if not (wlo <= Q(t1) < Q(t2) <= whi): viol[3].append((rel, [t1, t2], c['window']))
real = {g: n for g, n in groups.items() if not g.startswith('nc/')}
print(json.dumps(dict(files=len(files), certificates_non_nc=sum(real.values()), groups=groups, intervals_checked=nint,
                      violations={k: len(v) for k, v in viol.items()}, details={k: v[:20] for k, v in viol.items() if v}), indent=1))
