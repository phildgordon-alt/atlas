"""Rigorous completed L-function of a holomorphic newform of weight k, level N, root number eps (real coefficients).

  Lambda(s) = (sqrt N / 2 pi)^s Gamma(s) L(f, s),   Lambda(s) = eps Lambda(k - s)          (arithmetic normalization)
  Lambda(s) = sum_{n>=1} a_n [ x_n^{-s} Gamma(s, A x_n) + eps x_n^{s-k} Gamma(k-s, x_n / A) ],   x_n = 2 pi n / sqrt N,  A > 0
  (A = 1 is the standard series; A != 1 gives an independent check of N, eps, a_n.)
Tail (THEORY_DEG2.md, Lemma T): for n > M,
  |a_n| <= 2 n^{k/2},  |x^{-s} Gamma(s, A x)| <= A^{sigma} e^{-A x} / (A x - c),  c = max(0, sigma - 1)  (A x > c)
so the omitted part is <= sum_{n>M} 2 n^{k/2} [A^sigma e^{-Ax}/(Ax - c1) + A^{-(k-sigma)} e^{-x/A}/(x/A - c2)]  (geometric bound).
Z(t) := e^{pi t / 2} Lambda(k/2 + i t)  is real for eps = +1 and real a_n, and has the sign of Lambda(k/2 + it).
ec37a (THEORY_37A.md Lemma Z): for eps = -1, Lambda(k/2 + it) is purely imaginary and Z(t) := e^{pi t/2} Im Lambda(k/2 + it)."""
import math
from flint import arb, acb, ctx

def _tail(F, sigma, A, M):
    """rigorous upper bound (arb) for the omitted terms n > M of the A-series at Re s = sigma"""
    k = F['k']; N = F['N']; c = 2 * math.pi / math.sqrt(N)
    c1 = max(0.0, sigma - 1); c2 = max(0.0, (k - sigma) - 1)
    m = M + 1
    # need A c m > c1 and c m / A > c2 and ratio q < 1
    assert A * c * m > c1 + 1 and c * m / A > c2 + 1
    def term(n, w, cc, pw):
        x = arb(2) * arb.pi() * n / arb(N).sqrt() * w
        return 2 * arb(n) ** (arb(k) / 2) * arb(pw) * (-x).exp() / (x - cc)
    t1 = term(m, A, c1, A ** sigma)
    t2 = term(m, 1 / A, c2, A ** (-(k - sigma)))
    # ratio bound for consecutive terms (n -> n+1), n >= m: ((n+1)/n)^{k/2} e^{-w c} * (w c n - cc)/(w c (n+1) - cc) <= (1+1/m)^{k/2} e^{-w c}
    q1 = (1 + 1.0 / m) ** (k / 2) * math.exp(-A * c); q2 = (1 + 1.0 / m) ** (k / 2) * math.exp(-c / A)
    assert q1 < 0.9 and q2 < 0.9
    # bound with outward safety: use arb for 1/(1-q) with q rounded up
    Q1 = arb(q1) * (1 + arb(2) ** -40); Q2 = arb(q2) * (1 + arb(2) ** -40)
    return t1 / (1 - Q1) + t2 / (1 - Q2)

def cutoff(F, t, A=1.0, extra_bits=60):
    """smallest-ish M with tail well below e^{-pi t/2} 2^{-extra_bits} (only efficiency; rigour comes from _tail)"""
    c = 2 * math.pi / math.sqrt(F['N'])
    target = math.pi * abs(t) / 2 + extra_bits * math.log(2) + 10
    return int(target / (c * min(A, 1 / A))) + 5

def Lam(F, s, prec=None, A=1.0, M=None):
    """acb enclosure of Lambda(s) (arithmetic normalization)"""
    s = acb(s); t = float(s.imag.mid()); sigma = float(s.real.mid())
    assert s.real.rad() == 0 and s.imag.rad() == 0, 'point arguments only'
    if prec is None: prec = 96 + int(2.3 * abs(t)) + 32
    if M is None: M = cutoff(F, t, A)
    a = F['a']; assert M < len(a), 'need more coefficients'
    k = F['k']; eps = F['eps']; old = ctx.prec; ctx.prec = prec
    try:
        s = acb(s); x0 = 2 * arb.pi() / arb(F['N']).sqrt(); Aa = arb(A); tot = acb(0)
        ks = k - s
        for n in range(1, M + 1):
            if a[n] == 0: continue
            x = x0 * n
            u = acb(x * Aa).gamma_upper(s) * acb(x) ** (-s)
            v = acb(x / Aa).gamma_upper(ks) * acb(x) ** (-ks)
            tot += a[n] * (u + eps * v)
        tb = _tail(F, sigma, A, M)
        tot = tot + acb(arb(0, tb.upper()), arb(0, tb.upper()))
    finally:
        ctx.prec = old
    return tot

def Z(F, t, prec=None, A=1.0):
    """real arb ball containing e^{pi t/2} Lambda(k/2 + it) (Re part for eps = +1, Im part for eps = -1; real a_n)"""
    if prec is None: prec = 96 + int(2.3 * abs(float(t))) + 32
    old = ctx.prec; ctx.prec = prec
    try:
        T = arb(t); s = acb(arb(F['k']) / 2, T)
        v = Lam(F, s, prec=prec, A=A)
        r = (v.real if F['eps'] == 1 else v.imag) * (arb.pi() * T / 2).exp()
    finally:
        ctx.prec = old
    return r

def Lam_line(F, t, prec=None, A=1.0):
    """complex enclosure of e^{pi t/2} Lambda(k/2 + it) (for the replay's complex A-split overlap check)"""
    if prec is None: prec = 96 + int(2.3 * abs(float(t))) + 32
    old = ctx.prec; ctx.prec = prec
    try:
        T = arb(t); v = Lam(F, acb(arb(F['k']) / 2, T), prec=prec, A=A) * (arb.pi() * T / 2).exp()
    finally:
        ctx.prec = old
    return v

def zpart(F, v):
    """the part of e^{pi t/2} Lambda(1+it) that Z takes: real part for eps = +1, imaginary part for eps = -1"""
    return v.real if F['eps'] == 1 else v.imag

def sign(ball):
    if ball.lower() > 0: return 1
    if ball.upper() < 0: return -1
    return 0
