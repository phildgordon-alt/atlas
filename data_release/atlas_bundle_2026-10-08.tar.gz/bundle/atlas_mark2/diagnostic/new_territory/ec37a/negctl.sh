#!/bin/zsh
# Negative controls on the validation window 37.a1 [0,10]. Every corrupted replay writes its own json (never replay.json).
P=/Users/kiosk/projects/atlas-rerun/.venv/bin/python
cd /Users/kiosk/atlas_mark2/diagnostic/new_territory/ec37a
V=runs/val_0_10; O=runs/nc; mkdir -p $O
# C1 fake sign change (3.0, 3.1) injected into the generator (true rows + true intervals copied)
mkdir -p $O/fake; cp $V/rows.json $V/intervals.json $O/fake/
NC_FAKE=3.0,3.1 nice -n 19 $P -B -u gen_cert.py 37.a1 0 10 $O/fake > $O/fake_gen.out 2>&1
nice -n 19 $P -B -u replay_deg2.py $O/fake 0 10 > $O/fake_replay.out 2>&1
# C2 perturbed a_2 (-2 -> -1): replay rows + Z; replay rows only (true Z); generator with a_2+1 rows
NC_AP=2:1 nice -n 19 $P -B -u replay_deg2.py $V 0 10 replay_NC_a2.json > $O/a2_replay.out 2>&1
NC_AP=2:1 NC_ROWS_ONLY=1 nice -n 19 $P -B -u replay_deg2.py $V 0 10 replay_NC_a2_rowsonly.json > $O/a2_rowsonly_replay.out 2>&1
mkdir -p $O/a2gen; cp $V/intervals.json $O/a2gen/
NC_AP=2:1 nice -n 19 $P -B -u gen_cert.py 37.a1 0 10 $O/a2gen > $O/a2_gen.out 2>&1
# C3 wrong root number eps = +1: replay of the true certificates with eps=+1 (Z and series);
#    generator scanning the wrong Z (eps=+1, fresh intervals), then replayed with the true data and with eps=+1
NC_EPS=1 nice -n 19 $P -B -u replay_deg2.py $V 0 10 replay_NC_eps.json > $O/eps_replay.out 2>&1
mkdir -p $O/epsgen; cp $V/rows.json $O/epsgen/
NC_EPS=1 nice -n 19 $P -B -u gen_cert.py 37.a1 0 10 $O/epsgen > $O/eps_gen.out 2>&1
if ls $O/epsgen/certs/cell_*.json >/dev/null 2>&1; then
  nice -n 19 $P -B -u replay_deg2.py $O/epsgen 0 10 replay_true_data.json > $O/epsgen_replay_true.out 2>&1
  NC_EPS=1 nice -n 19 $P -B -u replay_deg2.py $O/epsgen 0 10 replay_NC_eps.json > $O/epsgen_replay_eps.out 2>&1
fi
# C4 wrong conductor N = 38 (rows + Z)
NC_N=38 nice -n 19 $P -B -u replay_deg2.py $V 0 10 replay_NC_N38.json > $O/N38_replay.out 2>&1
echo NC_DONE > $O/done
