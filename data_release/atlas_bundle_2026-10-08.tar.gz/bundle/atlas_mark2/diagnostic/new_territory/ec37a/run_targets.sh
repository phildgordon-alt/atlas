#!/bin/zsh
# Pre-registered target runs (PREDICTIONS.md): [10,100] then [100,200] in 10-unit chunks; one heavy process at a time, nice 19.
P=/Users/kiosk/projects/atlas-rerun/.venv/bin/python
cd /Users/kiosk/atlas_mark2/diagnostic/new_territory/ec37a; mkdir -p runs/chunks
for k in $(seq 1 19); do lo=$((10*k)); hi=$((10*k+10)); R=runs/chunks/c_${lo}_${hi}
  [ -f $R/replay.json ] && continue
  /usr/bin/time -l nice -n 19 $P -B -u gen_cert.py 37.a1 $lo $hi $R > $R.out 2>&1
  /usr/bin/time -l nice -n 19 $P -B -u replay_deg2.py $R $lo $hi > $R.replay.out 2>&1
  echo "$lo $hi $(grep SUMMARY $R.replay.out | grep -o '"closed": [a-z]*') $(grep SUMMARY $R.replay.out | grep -o '"passed_both": [0-9]*') gen_peak=$(grep 'peak memory' $R.out | awk '{print $1}') rep_peak=$(grep 'peak memory' $R.replay.out | awk '{print $1}')" >> runs/chunks/SUMMARY.log
done
touch runs/chunks/done
