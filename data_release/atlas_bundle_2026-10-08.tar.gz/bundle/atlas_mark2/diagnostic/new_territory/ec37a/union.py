"""Exact union check of contiguous coverage (PREDICTIONS.md).  Reads every runs/CHUNK/replay.json (fresh-process replays), takes the
cells that passed BOTH plain and hardened replay with d_range [0, 1/2] (re-read from the certificate files), and checks in exact
Fractions that their union covers [LO, HI] with no gap.  Also re-checks: one a_p table sha for all chunks, the same replay_verify sha,
and counts distinct sign-change intervals with midpoint inside each chunk's target (diagnostic).
usage: python union.py LO HI CHUNKDIR [CHUNKDIR ...]"""
import sys, os, json
from fractions import Fraction as Q
lo, hi = Q(sys.argv[1]), Q(sys.argv[2]); dirs = sys.argv[3:]
cells = []; shas = set(); vshas = set(); per = []; mids = set()
for d in dirs:
    r = json.load(open(os.path.join(d, 'replay.json'))); s = r['summary']; shas.add(s.get('ap_table_sha256')); vshas.add(s['replay_verify_sha'])
    ok = 0
    for c in r['cells']:
        if c['plain'] == 'CERTIFIED' and c['hardened'] == 'CERTIFIED':
            cert = json.load(open(os.path.join(d, 'certs', c['file'])))
            assert cert['d_range'] == [0.0, 0.5] and cert['cell'] == c['cell'] and not cert.get('negative_control')
            cells.append((Q(cert['cell'][0]), Q(cert['cell'][1]))); ok += 1
    tlo, thi = s['target']; iv = json.load(open(os.path.join(d, 'intervals.json')))['intervals']
    n_in = sum(1 for t1, t2 in iv if tlo <= (t1 + t2) / 2 < thi or (thi == float(hi) and (t1 + t2) / 2 == thi))
    for t1, t2 in iv:
        m = (t1 + t2) / 2
        if tlo <= m <= thi: mids.add(round(m, 6))
    per.append(dict(chunk=d, target=s['target'], passed_both=ok, certificates=s['certificates'], closed=s['closed'], zeros_in_target=n_in,
                    min_margin=s['min_margin'], seconds=s['seconds']))
cells.sort(); cur = lo; gaps = []
for a, b in cells:
    if a > cur: gaps.append([float(cur), float(a)])
    cur = max(cur, b)
if cur < hi: gaps.append([float(cur), float(hi)])
out = dict(range=[float(lo), float(hi)], chunks=len(dirs), cells=len(cells), gaps=gaps, covered=(not gaps),
           ap_table_shas=sorted(map(str, shas)), replay_verify_shas=sorted(vshas), distinct_sign_changes_in_range=len(mids),
           all_chunks_closed=all(p['closed'] for p in per), per_chunk=per)
print(json.dumps(out, indent=1))
