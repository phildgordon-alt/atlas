"""TRUSTED verification of an a_p table for 37.a1 (THEORY_37A.md section 3).  Separate from the BSGS search in curve37.py.
For every prime p <= P:
  * p < 20000 (incl. 2, 3, 37): a_p must equal the exact naive count  p + 1 - #E(F_p)  on y^2 + y = x^3 - x;
  * p >= 1000: a_p^2 <= 4p, and a point Q on E (resp. on the quadratic twist E') is exhibited with n Q = O for n = p+1-a_p
    (resp. n' = p+1+a_p) and exact order ord(Q) > 4 sqrt(p)  (ord^2 > 16 p).  Then the Hasse interval (length 4 sqrt p) contains
    exactly one multiple of ord(Q), and #E(F_p) (resp. #E'(F_p) = 2p+2-#E) is one, so #E(F_p) = p+1-a_p.
Points come from an independent RNG seed and an independent point routine (x -> Euler criterion, y via pow for p = 3 mod 4,
Cipolla otherwise); scalar multiplication uses Jacobian coordinates (different code from curve37's affine routines).
usage: python verify_ap.py ap_P.npy [seed]"""
import sys, math, random, json, hashlib, time
import numpy as np
from curve37 import naive_ap      # naive count = the proof for small p (one short function)

A4, A6 = -16, 16

def jdbl(P, a, p):
    X, Y, Z = P
    if Z == 0 or Y == 0: return (1, 1, 0)
    YY = Y * Y % p; S = 4 * X * YY % p; Z2 = Z * Z % p
    M = (3 * X * X + a * Z2 * Z2) % p
    X3 = (M * M - 2 * S) % p
    return (X3, (M * (S - X3) - 8 * YY * YY) % p, 2 * Y * Z % p)

def jadd(P, Q, a, p):
    if P[2] == 0: return Q
    if Q[2] == 0: return P
    X1, Y1, Z1 = P; X2, Y2, Z2 = Q
    Z1Z1 = Z1 * Z1 % p; Z2Z2 = Z2 * Z2 % p
    U1 = X1 * Z2Z2 % p; U2 = X2 * Z1Z1 % p
    S1 = Y1 * Z2 * Z2Z2 % p; S2 = Y2 * Z1 * Z1Z1 % p
    if U1 == U2:
        if S1 != S2: return (1, 1, 0)
        return jdbl(P, a, p)
    H = (U2 - U1) % p; R = (S2 - S1) % p; HH = H * H % p; HHH = H * HH % p
    X3 = (R * R - HHH - 2 * U1 * HH) % p
    return (X3, (R * (U1 * HH - X3) - S1 * HHH) % p, Z1 * Z2 * H % p)

def jmul(n, P, a, p):
    R = (1, 1, 0); Q = P
    while n:
        if n & 1: R = jadd(R, Q, a, p)
        Q = jdbl(Q, a, p); n >>= 1
    return R

def cipolla(n, p):
    if p % 4 == 3: return pow(n, (p + 1) // 4, p)
    t = 0
    while pow((t * t - n) % p, (p - 1) // 2, p) != p - 1: t += 1
    w = (t * t - n) % p
    def m(x, y): return ((x[0] * y[0] + x[1] * y[1] % p * w) % p, (x[0] * y[1] + x[1] * y[0]) % p)
    r = (1, 0); b = (t, 1); e = (p + 1) // 2
    while e:
        if e & 1: r = m(r, b)
        b = m(b, b); e >>= 1
    return r[0]

def point(a, b, p, rng):
    while True:
        x = rng.randrange(p); f = (x * x * x + a * x + b) % p
        if f and pow(f, (p - 1) // 2, p) == 1:
            y = cipolla(f, p); assert y * y % p == f
            return (x, y, 1)

def order_ok(Q, n, a, p, spf):
    """True iff n Q = O and the exact order of Q satisfies ord^2 > 16 p"""
    if jmul(n, Q, a, p)[2] != 0: return False
    o = n; m = n; fac = []
    while m > 1:
        q = int(spf[m]); fac.append(q)
        while m % q == 0: m //= q
    for q in fac:
        while o % q == 0 and jmul(o // q, Q, a, p)[2] == 0: o //= q
    return o * o > 16 * p

def main():
    f = sys.argv[1]; seed = int(sys.argv[2]) if len(sys.argv) > 2 else 20261007
    ap = np.load(f); P = len(ap) - 1; rng = random.Random(seed); t0 = time.time()
    lim = P + 2 * math.isqrt(P) + 3
    spf = np.arange(lim + 1, dtype=np.int64)
    for i in range(2, math.isqrt(lim) + 1):
        if spf[i] == i:
            blk = spf[i * i::i]; mask = blk == np.arange(i * i, lim + 1, i); blk[mask] = i; spf[i * i::i] = blk
    isp = spf == np.arange(lim + 1); isp[:2] = False
    pr = np.nonzero(isp[:P + 1])[0]
    nonprime_nonzero = int(np.count_nonzero(ap[~isp[:P + 1]]))
    bad = []; stats = dict(naive=0, order_E=0, order_twist=0)
    for p in pr:
        p = int(p); v = int(ap[p])
        if p < 20000:
            if v != naive_ap(p): bad.append((p, 'naive')); continue
            stats['naive'] += 1
            if p < 1000: continue
        if v * v > 4 * p: bad.append((p, 'hasse')); continue
        a, b = A4 % p, A6 % p
        g = 2
        while pow(g, (p - 1) // 2, p) != p - 1: g += 1
        at, bt = a * g * g % p, b * g * g * g % p
        done = False
        for it in range(60):
            if it % 2 == 0:
                if order_ok(point(a, b, p, rng), p + 1 - v, a, p, spf): stats['order_E'] += 1; done = True; break
            else:
                if order_ok(point(at, bt, p, rng), p + 1 + v, at, p, spf): stats['order_twist'] += 1; done = True; break
        if not done and p >= 20000: bad.append((p, 'unproved'))
    out = dict(file=f, sha256=hashlib.sha256(open(f, 'rb').read()).hexdigest(), P=P, primes=len(pr), failures=len(bad),
               first_failures=bad[:20], nonprime_entries_nonzero=nonprime_nonzero, stats=stats, seconds=round(time.time() - t0, 1),
               a37=int(ap[37]), verdict='VERIFIED' if not bad and nonprime_nonzero == 0 else 'REJECTED')
    print(json.dumps(out))

if __name__ == '__main__':
    main()
