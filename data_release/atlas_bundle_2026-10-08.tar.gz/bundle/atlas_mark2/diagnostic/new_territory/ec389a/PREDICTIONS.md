# 389.a1 target runs — pre-registered 2026-10-07 (written after validation [0,10] + negative controls, BEFORE any target run)

Code: ec389a/ as frozen in CODE_SHA256_FROZEN.txt (incl. a_p table ap_3000010.npy sha 8b1c34cd…, modular-symbol certificate
logs/modsym/389.a1.json sha 593d1a0e…, THEORY_389A.md).
Runs: run_targets.sh — gen_cert.py 389.a1 on chunks [10k, 10k+10], k = 0..9 ([0,100]; chunk [0,10] re-run fresh, W = [−6, 16] carries the
central reduction m0 = 2), then k = 10..19 ([100,200]) as time allows; defaults (--margin 6 --cell 0.5 --step 0.02); each chunk replayed in
a fresh process (replay_deg2.py: rows recomputed ×1.5 prime cut-offs, 24 nodes, h = 0.4; every sign-change endpoint re-verified with the
A = 1.2 series, complex overlap with A = 1; replay_verify.py plain + hardened with expect_m0 = 2; central proofs re-run in-process for
chunk [0,10]). Then union.py 0 100 (and 0 200) over the chunks (exact Fractions), lean_gap_check.py over all certificates (conditions 1–4),
a fresh-process verify_ap.py, modsym.py verify, central.py, argcount.py.

**P1 (main prediction).** All 10 chunks of [0, 100] close (every certificate passes plain + hardened replay; per-chunk exact tiling 0 gaps)
and the union covers [0, 100] with 0 gaps. Claim if met: every zero of L(E, s), E = 389.a1, with |Im s| ≤ 100 lies on the critical line;
all are simple except the zero at s = 1 (analytic s = 1/2), which has multiplicity exactly 2.
**P1′ (if run).** The same for the 10 chunks of [100, 200], union [0, 200] 0 gaps.

**P2 (diagnostic).** Sign changes per chunk (intervals with midpoint in the chunk; the central double zero gives none) = main term
N(b) − N(a), N(T) = (T/π) log(√389 T/(2πe)), within ±2:

| chunk | main term | predicted |  | chunk | main term | predicted |
|---|---|---|---|---|---|---|
| [0, 10] | 7.79 | 7 (known from validation) | | [100, 110] | 18.45 | 18 |
| [10, 20] | 12.20 | 12 | | [110, 120] | 18.74 | 19 |
| [20, 30] | 13.87 | 14 | | [120, 130] | 19.01 | 19 |
| [30, 40] | 14.95 | 15 | | [130, 140] | 19.25 | 19 |
| [40, 50] | 15.75 | 16 | | [140, 150] | 19.48 | 19 |
| [50, 60] | 16.39 | 16 | | [150, 160] | 19.69 | 20 |
| [60, 70] | 16.93 | 17 | | [160, 170] | 19.89 | 20 |
| [70, 80] | 17.38 | 17 | | [170, 180] | 20.08 | 20 |
| [80, 90] | 17.78 | 18 | | [180, 190] | 20.26 | 20 |
| [90, 100] | 18.14 | 18 | | [190, 200] | 20.43 | 20 |

Totals: (0,100] ≈ 151 (±3), (100,200] ≈ 195 (±3). LMFDB's listed zeros (Cremona record, 20 zeros ≤ 19.86; CMF record, 8 ≤ 10.35) must
all be matched by sign-change intervals — diagnostic only.

**Falsifiers.** Any chunk not closed (reported with location and failing status), any replay failure, any union gap, any Lean-surfaced
condition (1)–(4) violated, verify_ap.py not VERIFIED, modsym verify not L_E_1_IS_ZERO_PROVED, central.py not ORDER_EXACTLY_2. P2 misses
are reported but do not affect P1.
