# 389.a1 (y² + y = x³ + x² − 2x, N = 389, rank 2, ε = +1): results (2026-10-07/08)

**Outcome: P1 MET and P1′ MET.** All 20 pre-registered chunks closed. The exact union covers [0, 200] with 0 gaps.
* Pre-registration: `PREDICTIONS.md`, sha256 e3db626d…d301 (`PREDICTIONS.sha256`). It was written at 21:44, after the validation run and the
  negative controls and before any target run, and it is unchanged. The frozen code is listed in `CODE_SHA256_FROZEN.txt`; every file
  re-checked OK after the runs. This includes the a_p table, the modular-symbol certificate and THEORY_389A.md.
* Theory: `THEORY_389A.md`, written before coding. It adds Lemma Z⁺, Lemma M (L(E,1) = 0 exactly, by modular symbols), Lemma C2 (order
  exactly 2), the central-atom reduction (§3) and the cross-checks X1/X2. Everything else is inherited from ec37a and deg2.

**Claim.** Every zero of L(E, s), E = 389.a1, with |Im s| ≤ 200 lies on the critical line Re s = 1. All of them are simple except the
zero at s = 1 (analytic s = 1/2), which has multiplicity exactly 2. The claim covers [−200, 200] because the zero set is symmetric
under γ ↦ −γ.

## The central zero
| statement | how | result |
|---|---|---|
| L(E,1) = 0, exactly | `modsym.py`: {0,∞} is a Q-combination of 380 Manin-relation / (T_p − a_p) vectors (p ≤ 13) in Q^{P¹(F_389)}. Found with FLINT rref; re-verified entry by entry in pure-Python Fractions, with every vector recomputed and fresh naive a_p | **L_E_1_IS_ZERO_PROVED** (cert sha 593d1a0e…). dim V/R = 65 = 2g+1 (g = 32); codim of the span = 2 (the f-isotypic ±) |
| order is even | Lemma Z⁺(d): Λ(1+z) is even | Λ'(1) = Λ'''(1) = 0 identically |
| Λ''(1) ≠ 0 | `central.py`: Λ''(1) = 2Σ a_n h_n''(1), with h''(1) in closed form (Arb) and rigorous tails | Λ''(1) = 4.76702868626780955739539698012 ± 3.6e−30, so **order exactly 2**. L''(E,1)/2 = 0.7593165002884267702301926 ± 8e−27; diagnostic: matches the BSD leading term 0.75931650028842677… |
| X1 (independent of Λ'') | certificate of cell [0, 0.5] with the reduction m0 = 2 | CERTIFIED in both replays (margin ≥ 1.73), so multiplicity ≤ 3, hence = 2 |
| X2 (independent of Λ'' and of the LP) | `argcount.py`: argument principle on [0.4, 1.6] × [−T, T], Cauchy-bounded pieces | T = 1: winding [2.000000000 ± 3e−14] → **count 2**. T = 2.5: count 2. T = 3.5: count 4 (picks up ±2.876; sensitivity check). So the only zero with \|t\| ≤ 2.5 is s = 1, with multiplicity 2 |
| sign of Z near 0 | Lemma Z⁺(c),(e) | Z(±t) < 0 for t = 1e−7 … 2 (even sign pattern, no sign change at 0), as −sign Λ''(1) predicts |

**Treatment in the certificates (choice (a), THEORY §3).** For windows with wlo < 0 < whi, the known atom (0, 0, 2) is removed from the
zero configuration: hi, lo → hi − 2U(0,0), lo − 2U(0,0), and Nwin → Nwin − 2. The unchanged certificate theorem and Lemma 2 then apply
to the reduced configuration. Both verifiers enforce the following, and `lean_gap_check.py` re-checks it in exact rationals:
* m0 equals the proved order 2;
* a central entry is recorded exactly when the window contains 0;
* no sign-change interval meets 0.

## Runs (all nice -n 19, one heavy process at a time; generator peak ≤ 408 MB, replay ≤ 180 MB)
| window | sign changes in target (pred.) | cells | min hardened margin | gen s | replay s |
|---|---|---|---|---|---|
| validation [0,10] | 7 (2.876, 4.417, 5.793, 6.986, 7.475, 8.633, 9.633) | 20/20 | 1.880 | 109 | 90 |
| [0,10] (target, fresh) | 7 (7) | 20/20 | 1.880 | 108 | 90 |
| [10,20] … [90,100] | 13, 14, 15, 14, 17, 17, 17, 18, 18 (pred. 12, 14, 15, 16, 16, 17, 17, 18, 18) | 9 × 20/20 | 1.793 | 128–501 | 74–93 |
| [100,110] … [190,200] | 19, 19, 19, 19, 20, 19, 19, 20, 21, 21 (pred. 18, 19, 19, 19, 19, 20, 20, 20, 20, 20) | 10 × 20/20 | 1.790 | 581–1576 | 93–181 |

* Coverage: 400 certificates, all of which pass both replays. Every chunk's exact tiling closed, and the union [0, 200] has 0 gaps
  (`logs/union_0_200.json`; [0, 100] in `logs/union_0_100.json`).
* Provenance: one a_p table sha (8b1c34cd…) and one replay_verify sha (3aceb379…) across all chunks.
* Compute: generator 219 min and replay 36 min in total; [0, 100] alone took 45 + 14 min. a_p search to 3e6 took 44 s and its
  verification 19 s; modsym took 1 s, central 0.3 s and argcount 9 s (T = 1).
* **P2 (diagnostic) MET.** Every chunk is within ±2 of its prediction (worst case [40,50]: 14 against 16).
  - (0, 100]: 150 sign changes against 151 predicted.
  - (100, 200]: 196 against 195.
  - In total there are 346 distinct sign changes in (0, 200], plus the central double zero.
* LMFDB diagnostics (`diagnostics/lmfdb_389a.json`, fetched via the API; `logs/diag_lmfdb_chunks.json`):
  - Cremona EC record: all 20 listed zeros (≤ 19.86) are matched by sign-change intervals, with a maximum deviation of 3.0e−10.
  - CMF record 2-389-1.1-c1-0-29: all 8 listed zeros (≤ 10.35) are matched, with a maximum deviation of 2.9e−10.
  - No unlisted sign changes appear below the listed maxima.
  - a_p matches for the first 30 primes; order_of_vanishing = 2 and root number +1 in both records.

## Checks on every certificate
* Replay (fresh process):
  - rows recomputed (×1.5 prime cut-offs, 24 nodes, h = 0.4);
  - far allowances and N_win recomputed;
  - every sign-change endpoint (1522 across the chunks) re-verified with the A = 1.2 series at +40 bits, with complex overlap against A = 1;
  - `replay_verify.py` run plain and hardened, with expect_m0 = 2;
  - for windows containing 0, the central proofs (modsym verify, Λ''(1)) re-run in-process.
* Lean-surfaced conditions plus the central condition (`logs/lean_gap_check.json`): 479 files (420 real + 59 negative-control), 16 583 intervals.
  **0 violations** of (1) d-range [0, 1/2] with d0 = 0, (2) cell ⊂ window, (3) intervals ⊂ window, or (4) the central reduction, on real
  certificates. The 39 violations of (4) are all in the deliberate m0 = 0/1 control certificates.
* a_p table: `verify_ap.py` reported VERIFIED twice, in fresh processes with seeds 20261007 and 777.
  - Naive count for p < 20 000 (2262 primes).
  - Order-uniqueness proof for all primes ≥ 1000 (≈ 215.6k on E, ≈ 1.06k via the twist).
  - a_389 = +1 (split), consistent with ε = +1.

## Negative controls (validation window [0,10]; `negctl.sh`, outputs in `runs/nc/`, never written to replay.json)
| control | observed |
|---|---|
| fake sign change (3.5, 3.6) injected into the generator | 20/20 INCONSISTENT, nothing emitted |
| same interval forged into all 20 real certificates (w = 0.5) | replay 20/20 NO_SIGN_CHANGE |
| a_2 + 1: replay rows + Z / rows only / generator | 20/20 rejected (series mismatch) / 20/20 INCONSISTENT / 0/20 certified (INCONSISTENT) |
| wrong root number ε = −1: replay of the true certificates | 20/20 rejected (A-split series mismatch) |
| wrong ε in the generator's scan | 3 spurious "sign changes", one straddling 0. 18 cells BAD_CENTRAL (interval meets 0) and 2 NONPOSITIVE, so 0 certified |
| wrong conductor N = 390 | 20/20 rejected (series mismatch) |
| **central m0 = 0** (no reduction), generator | 19/20. **Only the central cell [0, 0.5] fails** (NONPOSITIVE_SAMPLED): the double zero mimics a pair at d → 0, so the treatment is load-bearing. With the policy on, the replay rejects all (BAD_CENTRAL) |
| true certificates replayed with m0 forged to 0 (policy off) | 19/20. The central cell fails (BUDGET) |
| **m0 = 3**: generator / forged replay, policy off | 0/20 (INCONSISTENT) / 20/20 INCONSISTENT. Over-claiming is caught by the consistency check alone |
| m0 = 4 forged, policy off | 20/20 INCONSISTENT |
| **m0 = 1**: generator / forged replay, policy on | 20/20 BAD_CENTRAL (m0 ≠ proved order) |
| m0 = 1, policy off (bare mathematics) | 20/20 CERTIFIED (generator) and 20/20 (forged). This is **sound but weaker**: subtracting one known copy is a true lower bound and proves only "central multiplicity ≤ 2". Claiming *order* 1 is refuted separately: Λ'(1) ≡ 0 for ε = +1, and the order is even |
| central order claims 1 / 3 (`central.py`) | refuted: odd order is impossible for ε = +1 (Λ(1+z) is even) |
| modular symbols: 11.a1, 37.b1 (rank 0) / 37.a1 (rank 1) / 389 with a_2+1 | not in span (NOT_PROVED) / in span (PROVED) / codim 0, so the guard gives NOT_PROVED |

Reading:
* The central policy and the consistency check are both load-bearing. The m0 = 3/4 controls show that the consistency check alone
  catches over-claiming.
* m0 = 1 is the one case the mathematics itself accepts. It is not unsound, only weaker, and the policy pins m0 to the separately
  proved order.

## Proved vs trusted
**Proved here** (given Arb/FLINT):
* Lemma Z⁺;
* Lemma M (L(E,1) = 0 exactly);
* Lemma C2 (order exactly 2), with the two independent confirmations X1 and X2;
* the central-atom reduction (§3; it maps onto the Lean-checked theorem applied to the reduced configuration — the reduction step itself is
  a few lines of algebra not in Lean);
* the a_p verification (given Hasse);
* everything proved in THEORY_DEG2 §9 and THEORY_37A.

**Trusted:**
* Arb/FLINT (python-flint 0.9.0). FLINT's fmpq rref only *finds* the modular-symbol combination; the identity is re-checked in Fractions.
* Modularity of E (Λ entire, FE with N = 389 and ε = +1; also checked numerically by the A-split).
* Classical modular-symbol facts: the period map is additive and Γ_0(N)-invariant, the T_p equivariance computed in THEORY (P3), and
  L(f,1) = −2πi φ{0,∞}.
* Hasse; Rosser–Schoenfeld; Trefethen's Gauss–Legendre bound; Iwaniec–Kowalski Thm 5.6 (Lorentzian rows only).
* Lemma 2's logic (Lean-formalized, `Cert.lemma2_parity`) and the Lemma 1 parity premise (a hypothesis there).

**Untrusted:** HiGHS, the generator, the BSGS search, and the argcount piece search (the acceptance test of each piece is rigorous).

## Novelty status (careful; basis ../PRIOR_VERIFICATION.md plus checks made 2026-10-08)
* **Centre.** "Analytic rank of 389a is exactly 2" is classical: L(E,1) = 0 via modular symbols and root number, and L''(E,1) ≠ 0 by
  computation (Cremona's tables; LMFDB lists analytic rank 2). It is not new. Ours is an independent re-proof with three mutually
  independent confirmations of the order.
* **Hiary–Ireland–Kyi** (arXiv:2408.00187): their examples are ζ, a real Dirichlet character, Ramanujan Δ, and the single elliptic curve
  37.a1 (|t| ≤ 10). Confirmed via the arXiv HTML: **no conductor-389 curve, no rank-2 curve, no multiple central zero.**
* **LMFDB / CMF paper** (Best et al. §10.3): RH is checked "up to height b" for every CMF L-function, including 389.2.a.a. b is unpublished;
  Platt's code implies b = 32 for degree 2 (inference). LMFDB lists 389.a zeros only to 19.86 (Cremona record) and 10.35 (CMF record), and
  its reliability statement does not certify that zeros lie on the line.
* A web search (2026-10-08) found no published rigorous RH verification for 389.a.
* **So:** [0, ~32] is plausibly covered by the unpublished-height LMFDB/Büthe check. **[32, 200] for 389.a1, and any published certificate
  that treats its double central zero explicitly, is not found in the literature or in LMFDB as of October 2026, to our knowledge.**
  Moderate confidence; the experts best placed to confirm are Platt, Costa, Booker and Hiary.
* **Method contrast.** The double central zero is handled by an exactly proved known-mass subtraction inside the dual certificate. Büthe-type
  checks instead take a provisional zero list (including the central multiplicity) as input.
