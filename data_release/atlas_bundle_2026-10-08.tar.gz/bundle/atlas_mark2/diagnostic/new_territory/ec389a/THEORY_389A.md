# Atlas degree-2 pipeline for E = 389.a1: theory (written before coding, 2026-10-07)

E = 389.a1: y² + y = x³ + x² − 2x, a-invariants [0, 1, 1, −2, 0], conductor N = 389 (prime), Δ = 389, rank 2, root number ε = +1,
newform 389.2.a.a (weight 2, trivial character). This is the smallest-conductor curve of rank 2.
Everything not stated here is inherited unchanged from `../ec37a/THEORY_37A.md` (cited as E§n) and `../deg2/THEORY_DEG2.md` (D§n).
What is new: ε = +1 **with a central zero**, and that zero is **double**. A double on-line zero is invisible to Lemma 1 (no sign change)
and, to the explicit-formula rows, looks exactly like an off-line pair with δ → 0. Lemma 2 cannot certify it as simple, because it is not.

## 0. Normalizations (as E§0)

* Arithmetic: Λ(s) = (√389/2π)^s Γ(s) L(E,s), entire, Λ(s) = +Λ(2 − s) (modularity: Wiles, Taylor–Wiles, BCDT; ε = +1).
* Analytic: Λ_an(s) = Λ(s + 1/2), zeros ρ = 1/2 + iγ, |Re ρ − 1/2| < 1/2. Real a_n ⇒ zero set symmetric under ρ ↦ ρ̄, 1 − ρ, 1 − ρ̄
  with multiplicities; off-line zeros have a partner at the same ordinate; γ ↦ −γ symmetry, so claims on [0, T] give [−T, T].
* a_389 = +1 (split multiplicative), consistent with ε = −w_389 = −(−a_389) = a_389 (check, not input).

## 1. Z for ε = +1 (Lemma Z⁺)

Z(t) := e^{πt/2} Re Λ(1 + it).
(a) conj Λ(1+it) = Λ(1−it) = Λ(2 − (1+it)) = Λ(1+it), so Λ(1+it) is real and Z(t) = e^{πt/2} Λ(1+it).
(b) Z is real-analytic; its zeros are exactly the ordinates of on-line zeros, with the same multiplicity (d/dt = i d/ds).
(c) Λ(1−it) = conj Λ(1+it) = Λ(1+it), so Z(−t) = e^{−πt} Z(t): **sign Z(−t) = sign Z(t)** (even sign pattern).
(d) g(z) := Λ(1+z) is even (FE), so every odd Taylor coefficient at 0 vanishes, ord_{s=1} Λ is **even**, and Λ'(1) = Λ'''(1) = 0
    identically, for any data with ε = +1.
(e) Near t = 0: Z(t) = e^{πt/2} g(it) = e^{πt/2} [g(0) − g''(0) t²/2 + O(t⁴)]. With g(0) = 0 and g''(0) = Λ''(1) ≠ 0 (§2), Z has a
    zero of order exactly 2 at t = 0 and **does not change sign there**: sign Z(t) = −sign Λ''(1) for 0 < |t| small.
Consequences for the pipeline: no Lemma-1 interval ever certifies the central zero. The scan grid point t = 0 (ball contains 0) is nudged to
1e−7 exactly as in D§6; Z(±small) have the same sign, so no interval is produced there. The verifiers **require** that no sign-change
interval meets 0 whenever a central reduction (§3) is used (exact rational check).

## 2. The central zero has order exactly 2

### 2.1 Lemma M: L(E, 1) = 0, exactly (modular symbols)

A numerical |L(E,1)| < tiny is not a proof. Instead we prove {0, ∞} lies in the Hecke-annihilated part of the modular-symbol space,
in exact rational arithmetic. Let f = Σ a_n q^n ∈ S_2(Γ_0(389)) be the newform with L(f,s) = L(E,s) (modularity; a_p(f) = a_p(E) =
p + 1 − #E(F_p), proved for the primes used here by the naive count of §4).

**Period functional.** For cusps α, β ∈ P¹(Q) put φ{α,β} := ∫_α^β f(z) dz (any path in H joining the cusps; f is cuspidal, so the
integral converges and is path-independent). Classical facts (trusted: Manin 1972; Cremona, *Algorithms for modular elliptic curves*, ch. 2):
* (P1) φ{α,β} + φ{β,γ} + φ{γ,α} = 0.
* (P2) φ{γα, γβ} = φ{α,β} for γ ∈ Γ_0(N) (f(γz) d(γz) = f(z) dz).
* (P3) Hecke, p ∤ N: φ(T_p{α,β}) = a_p φ{α,β}, where T_p{α,β} := Σ_{r=0}^{p−1} {(α+r)/p, (β+r)/p} + {pα, pβ}.
  *Proof.* For g upper triangular, ∫_{gα}^{gβ} f(z)dz = ∫_α^β f(gz) g'(z) dz. For g = [1 r; 0 p]: g' = 1/p, and
  Σ_r f((z+r)/p)/p = Σ_m a_{pm} q^m. For g = [p 0; 0 1]: g' = p, giving p Σ_m a_m q^{pm}. The sum is Σ_m (a_{pm} + p a_{m/p}) q^m
  = a_p f (Hecke relation for a normalized eigenform, p ∤ N). The interchange of sum and integral is legitimate on paths where the
  q-series converges uniformly; between cusps, split at interior points and use (P1)/(P2) — standard. ∎
* (P4) L(f, 1) = 2π ∫_0^∞ f(iy) dy = −2πi · φ{0, ∞}. (Mellin: ∫_0^∞ f(iy) y^{s−1} dy = (2π)^{−s} Γ(s) L(f,s), entire in s.)

**Manin symbols.** For g = [a b; c d] ∈ SL_2(Z), [g] := φ(g{0, ∞}) = φ{b/d, a/c}. By (P2), [g] depends only on Γ_0(N)g, i.e. on
(c : d) ∈ P¹(Z/389) (390 classes). With S = [0 −1; 1 0], τ = [0 −1; 1 −1] (τ: 0 ↦ 1 ↦ ∞ ↦ 0):
  [x] + [xS] = 0,   [x] + [xτ] + [xτ²] = 0,   (c:d)S = (d : −c), (c:d)τ = (d : −c−d), (c:d)τ² = (−c−d : c).
**Manin's trick.** For r = p_n/q_n with convergents p_k/q_k (p_{−1}/q_{−1} = 1/0):
{∞, r} = Σ_{k=0}^{n} {p_{k−1}/q_{k−1}, p_k/q_k} = Σ_k [g_k], g_k = [(−1)^{k−1}p_k, p_{k−1}; (−1)^{k−1}q_k, q_{k−1}] ∈ SL_2(Z),
so {α, β} = {∞, β} − {∞, α} is an explicit integer combination of Manin symbols.

**Exact certificate.** Let V = Q^{P¹(Z/389)}, e_x the basis vectors, and φ̃: V → C the linear map e_x ↦ [x]. Then φ̃ kills
* the relation vectors e_x + e_{xS} and e_x + e_{xτ} + e_{xτ²};
* for each prime p ∈ {2, 3, 5, 7, 11, 13}, each x: the vector h_{p,x} = (Manin expansion of T_p(g_x{0,∞})) − a_p e_x, where g_x ∈ SL_2(Z)
  has bottom row ≡ x (P1–P3).
If e_{(0:1)} (= the symbol of the identity, {0, ∞}) is a **rational linear combination** of these vectors, then φ{0,∞} = 0 and, by (P4),
**L(E, 1) = 0**. `modsym.py` finds the combination with FLINT's exact fmpq_mat rref and writes the coefficients; `modsym.py --verify`
re-checks the identity Σ c_k v_k = e_{(0:1)} entry by entry in pure-Python `Fraction`s, recomputing every v_k from scratch.
Guard/diagnostics: dim V/R = 65 (= 2·genus + 1, genus X_0(389) = 32); codimension of the full span must be **≥ 1** (= 2 expected: the
f-isotypic part, plus and minus). If the a_p were wrong, the span would typically be everything (codim 0) and the "proof" would be void —
so codim ≥ 1 is checked, and the a_p used are proved by naive point counts. Note the logic does not need multiplicity one or the plus
quotient: any Q-combination suffices.
**Trusted:** modularity with a_p(f) = a_p(E); (P1)–(P4); FLINT's rref only for *finding* the combination (the identity is re-verified in
pure Python). No Manin-constant or torsion bound is needed (that would be the alternative "small rational ⇒ 0" route; not used).
Controls: 11.a1 and 37.b1 (rank 0) must give e_{(0:1)} ∉ span; 37.a1 (rank 1) must give ∈ span; 389 with a_2 perturbed must give codim 0.

### 2.2 Lemma E (evenness) and Lemma C2 (order exactly 2)

By Lemma Z⁺(d) the order at s = 1 is even; by Lemma M it is ≥ 2. Order exactly 2 ⇔ Λ''(1) ≠ 0.
With h(s) := ∫_1^∞ v^{s−1} e^{−xv} dv = x^{−s}Γ(s, x), Λ(s) = Σ a_n [h_n(s) + ε h_n(2 − s)] (A = 1), so
Λ''(1) = (1 + ε) Σ a_n h_n''(1) = 2 Σ_n a_n h_n''(1), x_n = 2πn/√389, and
  h''(1) = ∫_1^∞ log²v e^{−xv} dv = (1/x)[(γ + log x)² + π²/6] − 2 Σ_{k≥0} (−x)^k / (k! (k+1)³)
(full Mellin integral x^{−s}Γ(s) differentiated twice at s = 1, minus ∫_0^1 v^{s−1}e^{−xv}dv = Σ_k (−x)^k/(k!(s+k)) differentiated twice).
Series truncation: for k ≥ K ≥ 2x the terms decrease with ratio ≤ 1/2, so the omitted part is ≤ 2|T_K| (Arb, enough precision to absorb
the e^{x} cancellation). Tail in n: 0 ≤ h''(1) ≤ ∫_1^∞ (v−1)² e^{−xv} dv = 2e^{−x}/x³ (log v ≤ v − 1), |a_n| ≤ 2n, consecutive ratio
≤ (1 + 1/m)e^{−2π/√389} < 1 beyond m. Independent diagnostic: h''(1) also by `acb.integral` on [1, V] plus tail ∫_V^∞ v e^{−xv} dv
(log²v ≤ v for v ≥ 1). Expected L''(E,1) = (2π/√389) Λ''(1) ≈ 2 × 0.75931650… (LMFDB/BSD leading term; diagnostic only).
If the Arb ball for Λ''(1) excludes 0: **ord_{s=1} L(E, s) = 2 exactly** (`central.py`). (Classically first proved by Buhler–Gross–Zagier
1985; our proof is a re-derivation, not new.)

### 2.3 Two independent cross-checks of the central structure
* (X1) The certificate of cell [0, 0.5] (§3) proves, independently of Λ''(1), that the central multiplicity is ≤ m0 + 1 = 3, hence = 2.
* (X2) Argument principle (`argcount.py`): Λ on the boundary of B = [0.4, 1.6] × [−1, 1] (arithmetic s; B ⊃ the closed strip
  1/2 ≤ Re s ≤ 3/2 over |t| ≤ 1 and is symmetric under s ↦ 2 − s̄). Boundary pieces are Arb boxes; a piece is accepted when its
  enclosure (a rectangle, hence convex) excludes 0, so the continuous arg change along it equals the principal arg of F(end)/F(start)
  (Arb ball inside (−π, π)). The winding number must be an Arb ball containing exactly one integer. If it is 2: every zero with |t| ≤ 1
  is s = 1 (multiplicity 2) — with Lemma M (≥ 2) this is a third proof of "order exactly 2" and also closes |t| ≤ 1 by counting,
  in the style of atlas_v4_1 Lemma A. (Λ_ball: the same A = 1 series with ball arguments and the Lemma-T tail with c₁ = c₂ = 0.6.)

## 3. Certificates near t = 0: subtracting the known central atom (choice (a))

**Choice.** Treat the proven central double zero as known mass and remove it from the zero configuration before applying the unchanged
certificate theorem. (b) (argument-principle closure of a box) is run as a cross-check (X2), not as the closure mechanism: (a) keeps every
cell, including [0, 0.5], inside the LP-certificate framework, replayed by both verifiers, and reduces exactly to the Lean-checked theorem.

**Reduced configuration.** Let m0 be a positive integer with m0 ≤ ord_{s=1/2} Λ_an (here m0 = 2, valid by Lemma M + Lemma E; exactness by
Lemma C2). Define the reduced zero data Z′ = the zeros of Λ_an with multiplicities, except that the multiplicity at ρ0 = 1/2 is lowered by m0
(removed if it becomes 0). Z′ is again a valid zero configuration in the sense of `formal/` `ZeroData`: multiplicities ≥ 1, 0 < Re ρ < 1,
closed under ρ ↦ 1 − ρ̄ with equal multiplicity (ρ0 is its own mirror), locally finite.
For a window W with wlo < 0 < whi (so ρ0's atom (0, 0) is a **window** atom, never part of a far allowance):
* (H_rows′) S′_j = S_j − m0 U_j(0, 0), hence lo_j − Fa_j − m0U_j(0,0) ≤ S′_j ≤ hi_j − m0U_j(0,0) (exact shift; U_j(0,0) = sech(a·t_j) for a
  sech row, ε/(ε² + t_j²) for a Lorentzian row; Arb ball, rounded outward).
* (H_count′) N′ = N − m0 ≤ Nwin − m0.
* Lemma 1 on Z′: if no sign-change interval meets 0, the on-line multiplicities inside every I_i are the same for Z and Z′, so parity and
  n_i ≥ 1 hold verbatim. **Enforced:** every interval satisfies t2 < 0 or t1 > 0 (exact rationals).
So the certificate theorem (D§7 / THEORY_ZSIGN + Lemma 2; Lean `ZeroData.v4_onLine`, `v4_simple`) applies **verbatim** to Z′ with inputs
(lo′, hi′, Fa, Nwin′) = (lo − m0u0, hi − m0u0, Fa, Nwin − m0). Equivalently K′ = K − Φ(0, 0, m0): exactly "subtract the known atom's
contribution" (Φ(0,0,m0) = m0(y_c + Σ c_j U_j(0,0))). Only this reduction step (a few lines of algebra) is outside the Lean files.
**Conclusion of a certified cell [x0, x1] for Z′:** every zero of Z′ with ordinate in the cell is on the line and simple. Back on Λ: every
zero with ordinate in the cell other than ρ0 is on the line and simple; and if 0 ∈ [x0, x1], ρ0 has multiplicity ≤ m0 + 1 (else Z′ has a
multiple zero at x* = 0, excluded by Lemma 2 at the d = 0 point (0, 0), which lies in no interval) — with evenness, exactly 2 = m0 (X1).
Off-line zeros at ordinate 0 (real zeros β ≠ 1/2) are atoms of Z′ with d > 0 and are excluded by the Theorem as usual.

**Over-claiming is caught.** If m0 exceeded the true multiplicity (m0 = 3 or 4), Z′ would not be a configuration and (H_rows′) would be
false. The consistency check (both verifiers) — Σ_i min_{I_i} U_j(·,0) ≤ hi′_j — fails for rows near 0, where u0 ≈ 1 ≫ residual ≈ 1e−2:
INCONSISTENT. Policy checks (both verifiers, and `lean_gap_check.py` in exact rationals): m0 must equal the proven order 2 (an even
number for ε = +1); 'central' present ⇔ wlo < 0 < whi; no interval meets 0. Under-claiming (m0 = 1) is *sound* (a true lower bound) but
proves less (multiplicity ≤ 2 only, no exactness from the certificate) and contradicts evenness; it is rejected by policy (BAD_CENTRAL), and
the bare-mathematics outcome is reported separately. m0 = 0 (no treatment) is sound but is expected to **fail** to certify the cells near 0
(the double zero mimics a pair at d → 0): this shows the treatment is load-bearing.

**Final claim form.** For H covered by the union: every zero of L(E, s) with |Im s| ≤ H lies on the critical line Re s = 1; all are simple
except the zero at s = 1, which has multiplicity exactly 2.

## 4. Coefficients (as E§3, new curve)

* p < 20 000 (incl. 2, 3, 389): exact naive count on y² + y = x³ + x² − 2x (histogram of y² + y mod p); a_p = p + 1 − #Ẽ(F_p), also for
  p = 389 where the singular point is among the affine points (expected a_389 = +1, split).
* Search (untrusted), p ≥ 1000, p ≠ 389: BSGS on the short model Y² = X³ − 3024X + 46224 (c4 = 112, c6 = −856; X = 36x + 12,
  Y = 108(2y + 1); isomorphic over Z[1/6]) with the quadratic twist.
* Verification (trusted, separate code, `verify_ap.py`): naive count for p < 20 000; for p ≥ 1000 Hasse plus a point of exact order
  > 4√p (on E or the twist) — unique multiple in the Hasse interval (E§3).
* Diagnostics: a_p for small p against LMFDB (if reachable); a_n from a_{p^{j+1}} = a_p a_{p^j} − p a_{p^{j−1}}, a_{389^j} = 1.
* Arithmetic side: c(389^m) = (1/√389)^m log 389.

## 5. Unchanged pieces

Lemma T, the A-split replay (now complex overlap; with ε = +1 the A = 1 value is real on the line for any data, the A = 1.2 value only for
correct N, ε, a_n), sech/Lorentzian rows, Lemma N with N = 389, far allowances, Lemma 1, the certificate theorem and Lemma 2, exact tiling,
replay with re-computed rows (×1.5 prime cut-offs, 24 nodes, h = 0.4). The Lorentzian rows' Hadamard input needs Λ_an(0) ≠ 0, which
holds (no zeros on arithmetic Re s = 1/2).

## 6. Conditions enforced on every certificate

(1) (C) on the closed box with d0 = 0; (2) cell ⊂ window; (3) every interval ⊂ window, sorted, disjoint; **(4) central reduction:
'central' present iff wlo < 0 < whi, m0 = 2, no interval meets 0.** Enforced in `replay_verify.py` and `verify_deg2.py`, re-checked in
exact rationals on the stored JSON by `lean_gap_check.py`.

## 7. Rigor ledger (additions)

Proved here: Lemma Z⁺, Lemma M (given P1–P4 and modularity), Lemma C2 (given Arb), the reduction of §3, a_p verification (given Hasse).
Trusted additionally: classical modular-symbol facts (P1–P4); FLINT exact rref only to find coefficients (identity re-checked in Fractions);
ε = +1 (modularity/LMFDB; also checked numerically by the A-split).
