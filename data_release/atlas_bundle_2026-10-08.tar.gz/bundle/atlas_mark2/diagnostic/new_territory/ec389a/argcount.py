"""Cross-check X2 (THEORY_389A.md section 2.3): argument-principle count of the zeros of Lambda (arithmetic normalization) in the closed box
B = [S0, S1] x [-T, T], S0 = 0.4, S1 = 1.6 (symmetric about Re s = 1; contains the closed strip 1/2 <= Re s <= 3/2 for |t| <= T).

Method (all Arb).  The boundary is cut into axis-parallel pieces [z0, z1] with centre c and half-length r.
* Point values Lambda(z) from lfun.Lam (A = 1 series, Lemma-T tail).
* Majorant: for Re u in [sa, sb] (0 < sa <= sb < 2),  |Lambda(u)| <= G(sa, sb) := sum_n |a_n| [H(sb, x_n) + H(2 - sa, x_n)] + tail,
  H(sig, x) = int_1^oo v^{sig-1} e^{-xv} dv = x^{-sig} Gamma(sig, x)  (increasing in sig), tail (n > M): |a_n| <= 2n,
  H(sig, x) <= e^{-x}/(x - max(0, sig-1)) (Lemma T), geometric ratio bound.
* Cauchy: for w on the piece, |Lambda'(w)| <= G(sigma range of the piece +- R)/R, R = 0.2.  So |Lambda(z) - Lambda(c)| <= r G / R for z on
  the piece.  The piece is accepted iff r G / R < |Lambda(c)| (Arb, certain); then Lambda(piece) lies in the open disc D(Lambda(c), |Lambda(c)|),
  which is convex and excludes 0, so the continuous arg change along the piece is the principal Arg(Lambda(z1)/Lambda(z0)) (both endpoint
  values lie in that disc; the Arb ball of the Arg must lie in (-pi, pi)).  Otherwise the piece is halved.
* Winding number = sum / 2 pi; must be an Arb ball containing exactly one integer.
usage: python argcount.py [T]"""
import sys, json, math, time
from flint import arb, acb, ctx
import forms, lfun

S0, S1 = 0.4, 1.6
R = 0.2

class Maj:
    def __init__(self, F, M=400):
        self.F = F; self.M = M; self.cache = {}
    def H(self, sig, n):
        x = acb(2 * arb.pi() * n / arb(self.F['N']).sqrt())
        return (x.gamma_upper(acb(sig)) * x ** (-acb(sig))).real
    def G(self, sa, sb):
        key = (sa, sb)
        if key in self.cache: return self.cache[key]
        assert 0 < sa <= sb < 2
        a = self.F['a']; tot = arb(0)
        for n in range(1, self.M + 1):
            if a[n] == 0: continue
            tot += abs(a[n]) * (self.H(sb, n) + self.H(2 - sa, n))
        m = self.M + 1; x0 = 2 * arb.pi() / arb(self.F['N']).sqrt(); xm = x0 * m
        c1 = max(0.0, sb - 1); c2 = max(0.0, (2 - sa) - 1)
        Tm = 2 * arb(m) * ((-xm).exp() / (xm - c1) + (-xm).exp() / (xm - c2))
        q = (1 + arb(1) / m) * (-x0).exp(); assert q < 1
        v = tot + Tm / (1 - q)
        self.cache[key] = v
        return v

def count(F, T, prec=128, init=64, maxdepth=24):
    old = ctx.prec; ctx.prec = prec
    try:
        mj = Maj(F)
        corners = [complex(S0, -T), complex(S1, -T), complex(S1, T), complex(S0, T)]
        pt = {}
        def val(z):
            if z not in pt: pt[z] = lfun.Lam(F, acb(z.real, z.imag), prec=prec)
            return pt[z]
        stack = []
        for c0, c1 in zip(corners, corners[1:] + corners[:1]):
            pts = [c0 + (c1 - c0) * j / init for j in range(init)] + [c1]      # exact corners: the polygon closes exactly
            for j in range(init):
                stack.append((pts[j], pts[j + 1], 0))
        stack = stack[::-1]; total = arb(0); npiece = 0; minratio = math.inf
        while stack:
            z0, z1, dep = stack.pop()
            c = (z0 + z1) / 2                                                   # any point of the segment (axis-parallel)
            dist = lambda a, b: abs(arb(a.real) - arb(b.real)) + abs(arb(a.imag) - arb(b.imag))   # exact (one term is 0)
            assert (z0.real == z1.real == c.real) or (z0.imag == z1.imag == c.imag)
            r = max(dist(z0, c), dist(z1, c), key=lambda v: float(v.upper()))
            sa = min(z0.real, z1.real) - R; sb = max(z0.real, z1.real) + R
            sa = math.floor(sa * 20) / 20; sb = math.ceil(sb * 20) / 20       # coarse keys (wider range => larger G: still valid)
            bound = r * mj.G(sa, sb) / R
            Fc = val(c)
            ok = bool(bound < abs(Fc))
            if ok:
                d = (val(z1) / val(z0)).arg()
                ok = d.is_finite() and float(d.upper()) < math.pi and float(d.lower()) > -math.pi
            if not ok:
                if dep >= maxdepth: return dict(status='FAILED', piece=[str(z0), str(z1)])
                stack.append((c, z1, dep + 1)); stack.append((z0, c, dep + 1)); continue
            minratio = min(minratio, float((abs(Fc) / bound).lower()))
            total += d; npiece += 1
        W = total / (2 * arb.pi())
        u = W.unique_fmpz() if (W.is_finite() and float(W.rad()) < 0.25) else None     # the unique integer in the ball, if any
        res = dict(box=[S0, S1, -T, T], winding=W.str(10), pieces=npiece, point_evaluations=len(pt), min_margin_ratio=minratio,
                   count=int(u) if u is not None else None, status='COUNTED' if u is not None else 'AMBIGUOUS')
    finally:
        ctx.prec = old
    return res

if __name__ == '__main__':
    T = float(sys.argv[1]) if len(sys.argv) > 1 else 1.0
    F = forms.form('389.a1', 1000); t0 = time.time()
    r = count(F, T); r['seconds'] = round(time.time() - t0, 1)
    r['claim'] = ('the only zero of Lambda with |t| <= %g is s = 1, of multiplicity exactly 2 (count 2, and L(E,1) = 0 with even order '
                  'gives multiplicity >= 2 at s = 1)' % T) if r.get('count') == 2 else None
    print(json.dumps(r))
