"""Lemma C2 (THEORY_389A.md section 2.2): the central zero of L(E, s), E = 389.a1, has order exactly 2.
Lambda(1+z) is even (eps = +1), so the order at s = 1 is even; L(E,1) = 0 EXACTLY by modsym.py (Lemma M), so the order is >= 2;
it is exactly 2 iff Lambda''(1) != 0, where (A = 1 series, h(s) = x^{-s} Gamma(s, x) = int_1^oo v^{s-1} e^{-xv} dv)
  Lambda''(1) = 2 sum_n a_n h_n''(1),   h''(1) = int_1^oo log^2 v e^{-xv} dv = ((gamma + log x)^2 + pi^2/6)/x - 2 sum_k (-x)^k/(k!(k+1)^3),
  x_n = 2 pi n / sqrt(389);  L''(E,1) = (2 pi/sqrt 389) Lambda''(1)  (L(E,1) = L'(E,1) = 0).
Truncations: k-series: for k >= K >= 2x the terms decrease with ratio <= 1/2, omitted part <= 2|T_K|.
n-series: 0 <= h''(1) <= 2 e^{-x}/x^3, |a_n| <= 2n, so |2 a_n h_n''| <= 8 n e^{-x_n}/x_n^3, ratio <= (1+1/m) e^{-x_1}; tail <= T_{M+1}/(1-q).
Diagnostics: h''(1) for a few n also by acb.integral; Lambda(1) and Lambda'(1) balls (contain 0); signs of Z(+-t) (Lemma Z+(c),(e));
LMFDB/BSD leading term L''(E,1)/2 = 0.7593165002884... (diagnostic only)."""
import json, math, sys
from flint import arb, acb, ctx
import forms, lfun

N = 389

def xn(n):
    return 2 * arb.pi() * n / arb(N).sqrt()

def h2(n, prec):
    """Arb enclosure of int_1^oo log^2 v e^{-xv} dv at x = x_n (computed at the working precision)"""
    old = ctx.prec; ctx.prec = prec
    try:
        x = xn(n); g = arb.const_euler(); lx = x.log()
        full = ((g + lx) ** 2 + arb.pi() ** 2 / 6) / x
        K0 = int(2 * float(x.mid())) + 10; eps = arb(2) ** (-(prec - 40))
        S = arb(0); term = arb(1); k = 0               # term = (-x)^k / k!
        while True:
            if k >= K0 and (abs(term) / arb(k + 1) ** 3) < eps: break
            S += term / arb(k + 1) ** 3
            term = term * (-x) / (k + 1); k += 1
        K = k; TK = abs(term) / arb(K + 1) ** 3        # omitted part (k >= K >= 2x, ratio <= 1/2) <= 2 T_K
        S += arb(0, (2 * TK).upper())
        v = full - 2 * S
    finally:
        ctx.prec = old
    return v

def h2_integral(n, prec=128):
    """diagnostic: the same integral by acb.integral on [1, V] + tail int_V^oo v e^{-xv} dv (log^2 v <= v for v >= 1)"""
    old = ctx.prec; ctx.prec = prec
    try:
        x = xn(n); V = int(120 / float(x.mid())) + 10
        f = lambda z, an: z.log(analytic=an) ** 2 * (-acb(x) * z).exp()
        I = acb.integral(f, 1, V).real
        Vb = arb(V); tail = (-x * Vb).exp() * (Vb / x + 1 / (x * x))
        v = I + arb(0, tail.upper())
    finally:
        ctx.prec = old
    return v

def lam2(F, M=260, prec=256):
    old = ctx.prec; ctx.prec = prec
    try:
        return _lam2(F, M)
    finally:
        ctx.prec = old

def _lam2(F, M):
    x0 = xn(1)
    tot = arb(0)
    for n in range(1, M + 1):
        if F['a'][n] == 0: continue
        pr = 128 + int(2 * float((x0 * n).mid())) + 32
        tot += F['a'][n] * h2(n, pr)
    tot = 2 * tot
    m = M + 1; xm = x0 * m
    Tm = 8 * m * (-xm).exp() / xm ** 3
    q = (-x0).exp() * (1 + arb(1) / m)
    assert q < 1
    tail = Tm / (1 - q)
    return tot + arb(0, tail.upper()), tail

def lam_derivs_A(F, A, prec=200):
    """diagnostic: Lambda(1) and Lambda'(1) from the A-series (complex step-free: Lambda'(1) by the symmetric formula is identically 0
    for A = 1; for A = 1.2 we report the value of Lambda(1) only)"""
    return lfun.Lam(F, acb(1, 0), prec=prec, A=A)

def main():
    F = forms.form('389.a1', 1000)
    assert F['eps'] == 1
    l2, tail = lam2(F)
    ctx.prec = 256
    Lpp = l2 * xn(1)
    diag_int = []
    for n in (1, 2, 5, 20):
        a = h2(n, 200); b = h2_integral(n)
        diag_int.append(dict(n=n, series=a.str(15), integral=b.str(15), overlap=bool(a.overlaps(b))))
    l1 = lfun.Lam(F, acb(1, 0)); l12 = lfun.Lam(F, acb(1, 0), A=1.2)
    zs = {}
    for t in (1e-7, 1e-3, 0.1, 1.0, 2.0):
        zp = lfun.Z(F, t); zm = lfun.Z(F, -t)
        zs[str(t)] = (lfun.sign(zp), lfun.sign(zm))
    nonzero = bool(l2.lower() > 0 or l2.upper() < 0)
    out = dict(Lambda_pp_1=l2.str(30), L_pp_E_1=Lpp.str(30), half_L_pp=(Lpp / 2).str(25), n_tail_bound=float(tail.upper()),
               Lambda_pp_nonzero=nonzero,
               Lambda_1_A1=l1.str(8), Lambda_1_A12=l12.str(8),
               Lambda_1_balls_contain_0=bool(l1.real.contains(0) and l12.real.contains(0)),
               h2_series_vs_integral=diag_int,
               sign_Z_plus_minus=zs, even_signs=all(a == b != 0 for a, b in zs.values()),
               sign_Z_near_0_expected=(-1 if l2.lower() > 0 else 1),
               order_claims={'1': 'REFUTED: eps=+1 makes Lambda(1+z) even, so Lambda\'(1)=0 identically and the order is even',
                             '3': 'REFUTED: odd order impossible for eps=+1 (Lemma Z+(d))',
                             '2': 'PROVED' if nonzero else 'UNRESOLVED'},
               verdict=('ORDER_EXACTLY_2 (given modsym.py L(E,1)=0)' if nonzero else 'UNRESOLVED'),
               lmfdb_expected_half_L_pp='0.7593165002884...  (BSD leading term, diagnostic)')
    print(json.dumps(out, indent=1))

if __name__ == '__main__':
    main()
