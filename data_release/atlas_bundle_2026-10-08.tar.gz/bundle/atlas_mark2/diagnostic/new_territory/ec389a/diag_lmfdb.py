"""DIAGNOSTIC ONLY: compare with LMFDB (diagnostics/lmfdb_389a.json, fetched 2026-10-07 via the API; two records: Cremona EC origin,
20 zeros to 19.86, and CMF 2-389-1.1-c1-0-29, 8 zeros to 10.35).  (1) a_p from euler_factors vs the verified table; (2) every listed
zero must lie in (or within 1e-8 of) a sign-change interval of the given run dirs, and every interval with |t| <= max listed zero must
match a listed zero.  usage: python diag_lmfdb.py RUNDIR [RUNDIR ...]"""
import sys, json, os
import numpy as np
recs = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'diagnostics', 'lmfdb_389a.json')))['data']
ap = np.load(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ap_3000010.npy'))
import curve389
pr = [int(p) for p in curve389.primes_upto(10000)]
iv = []
for d in sys.argv[1:]: iv += [tuple(v) for v in json.load(open(os.path.join(d, 'intervals.json')))['intervals']]
iv = sorted(set(v for v in iv if v[1] > 0))
out = []
for r in recs:
    ef = r.get('euler_factors') or []
    mism = [(p, -e[1], int(ap[p])) for p, e in zip(pr, ef) if -e[1] != int(ap[p])]
    zs = [float(z) for z in r['positive_zeros']]
    unmatched = [z for z in zs if not any(t1 - 1e-8 <= z <= t2 + 1e-8 for t1, t2 in iv)]
    extra = [v for v in iv if v[0] <= max(zs) and not any(v[0] - 1e-8 <= z <= v[1] + 1e-8 for z in zs)]
    dev = max(min(abs(z - (t1 + t2) / 2) for t1, t2 in iv) for z in zs)
    out.append(dict(origin=r.get('origin'), label=r.get('label'), order_of_vanishing=r.get('order_of_vanishing'), root_number=r.get('root_number'),
                    a_p_compared=len(ef), a_p_mismatches=mism[:10], zeros=len(zs), max_zero=max(zs), unmatched_zeros=unmatched,
                    extra_sign_changes_below_max=extra, max_abs_dev_from_interval_mid=dev))
print(json.dumps(out, indent=1))
