"""Form data for E = 389.a1 (y^2 + y = x^3 + x^2 - 2x), newform 389.2.a.a: weight k = 2, level N = 389, root number eps = +1,
a_389 = +1 (split multiplicative).  Same interface as ../ec37a/forms.py.  a_p from the point-count table ap_3000010.npy (curve389.py;
proved by verify_ap.py, which must report VERIFIED for the sha256 recorded in AP_SHA256 before any certificate counts).
F['a'] = a_n list (n <= AN_MAX, used by the Lambda series); F['ap'] = int array of a_p (primes <= P; used by arith.Arith).
F['central_m0'] = 2: the PROVED order of the central zero (THEORY_389A.md section 2: modsym.py (L(E,1) = 0) + evenness + central.py
(Lambda''(1) != 0)); used by the central reduction (section 3) for windows with wlo < 0 < whi.
Negative controls: perturb(F, p, delta) changes a_p (and every a_n, rebuilt multiplicatively); F['eps'] may be overridden."""
import os, hashlib
import numpy as np
import curve389

HERE = os.path.dirname(os.path.abspath(__file__))
AP_FILE = os.path.join(HERE, 'ap_3000010.npy')
AP_SHA256 = '8b1c34cd92c2740277139abcc8168f896be85bc419fb4ff5b508b6b98365dc6d'
AN_MAX = 6000
CENTRAL_M0 = 2
primes_upto = curve389.primes_upto
FORMS = {'389.a1': dict(N=389, k=2, eps=1, bad={389: None}, char=lambda p: 1)}

def _load():
    raw = open(AP_FILE, 'rb').read()
    assert hashlib.sha256(raw).hexdigest() == AP_SHA256, 'a_p table hash mismatch'
    return np.load(AP_FILE)

def form(name, M):
    F = dict(FORMS[name]); ap = _load(); assert M < len(ap), 'need a_p up to M'
    F['ap'] = ap; F['a'] = curve389.an_table(ap, AN_MAX); F['name'] = name
    F['bad'] = {389: int(ap[389])}; assert F['bad'][389] == 1
    F['central_m0'] = CENTRAL_M0
    return F

def perturb(F, p, delta):
    G = dict(F); ap = np.array(F['ap']); ap[p] += delta; G['ap'] = ap; G['a'] = curve389.an_table(ap, AN_MAX)
    G['bad'] = {389: int(ap[389])}
    return G
