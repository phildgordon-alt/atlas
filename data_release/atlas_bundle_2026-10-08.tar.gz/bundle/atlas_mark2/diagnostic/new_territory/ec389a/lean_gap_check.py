"""Lean-gap check for ec389a (copied from ../ec37a/lean_gap_check.py): conditions (1)-(3) of formal/README.md 'gaps', checked directly on every
certificate in exact rationals (Fraction of the stored floats), plus (4) the central reduction (THEORY_389A.md section 3): 'central' present
iff wlo < 0 < whi, m0 = 2 (the proved order), and no sign-change interval meets 0.  Read-only. usage: python lean_gap_check.py [DIR]"""
import sys, os, glob, json
from fractions import Fraction as Q
root = sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(os.path.abspath(__file__))
files = sorted(glob.glob(os.path.join(root, 'runs', '**', 'cell_*.json'), recursive=True))
groups = {}; viol = {1: [], 2: [], 3: [], 4: []}; nint = 0; ncentral = 0
for f in files:
    rel = os.path.relpath(f, os.path.join(root, 'runs')); g = rel.split('/certs/')[0]
    if g.startswith('nc/'): g = g  # negative controls listed separately
    c = json.load(open(f)); groups[g] = groups.get(g, 0) + 1
    wlo, whi = map(Q, c['window']); x0, x1 = map(Q, c['cell']); d0, d1 = map(Q, c['d_range'])
    # (1) candidate box closed with d0 = 0 (and d1 = 1/2)
    if not (d0 == 0 and d1 == Q(1, 2)): viol[1].append((rel, c['d_range']))
    # (2) candidate region inside window (and nondegenerate)
    if not (wlo <= x0 < x1 <= whi): viol[2].append((rel, c['cell'], c['window']))
    # (3) every sign-change interval inside window, nondegenerate
    for t1, t2 in c['intervals']:
        nint += 1
        if not (wlo <= Q(t1) < Q(t2) <= whi): viol[3].append((rel, [t1, t2], c['window']))
    # (4) central reduction
    cen = c.get('central'); has0 = wlo < 0 < whi
    if cen:
        ncentral += 1
        if not (has0 and cen.get('m0') == 2): viol[4].append((rel, 'm0/window', cen.get('m0'), c['window']))
        for t1, t2 in c['intervals']:
            if Q(t1) <= 0 <= Q(t2): viol[4].append((rel, 'interval meets 0', [t1, t2]))
    elif has0: viol[4].append((rel, 'window contains 0 but no central reduction recorded'))
real = {g: n for g, n in groups.items() if not g.startswith('nc/')}
print(json.dumps(dict(files=len(files), certificates_non_nc=sum(real.values()), groups=groups, intervals_checked=nint, central_certificates=ncentral,
                      violations={k: len([e for e in v if not e[0].startswith('nc/')]) for k, v in viol.items()},
                      violations_in_negative_controls={k: len([e for e in v if e[0].startswith('nc/')]) for k, v in viol.items()},
                      details={k: v[:20] for k, v in viol.items() if v}), indent=1))
