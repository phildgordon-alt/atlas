"""Lemma M (THEORY_389A.md section 2.1): L(E, 1) = 0 EXACTLY, via weight-2 modular symbols for Gamma_0(N), N prime.

phi{a,b} = int_a^b f(z) dz (f the newform of E).  Manin symbol [x] = phi(g_x{0,oo}), x in P^1(Z/N) (bottom row of g_x).
phi kills:  e_x + e_{xS};  e_x + e_{x tau} + e_{x tau^2};  h_{p,x} = Manin(T_p g_x{0,oo}) - a_p e_x   (p not dividing N),
T_p{a,b} = sum_r {(a+r)/p, (b+r)/p} + {pa, pb}.   If e_{(0:1)} = sum c_k v_k (rational), then phi{0,oo} = 0, so L(E,1) = -2 pi i phi{0,oo} = 0.

usage:
  python modsym.py find   LABEL  OUT.json     # find c_k with FLINT exact rref (untrusted search), write certificate
  python modsym.py verify LABEL  CERT.json    # recompute every v_k and check sum c_k v_k == e_(0:1) in pure-Python Fractions
LABEL in {389.a1, 37.a1, 37.b1, 11.a1} or 389.a1:a2+1 (negative control: perturbed a_2).
a_p (p in PRIMES) are exact naive point counts on the minimal model (the proof for these p)."""
import sys, json, math, hashlib, time
from fractions import Fraction

CURVES = {'389.a1': (389, [0, 1, 1, -2, 0]), '37.a1': (37, [0, 0, 1, -1, 0]), '37.b1': (37, [0, 1, 1, -23, -50]),
          '11.a1': (11, [0, -1, 1, -10, -20])}
PRIMES = [2, 3, 5, 7, 11, 13]

def naive_ap(p, ai):
    """a_p = p + 1 - #E~(F_p) for y^2 + a1 xy + a3 y = x^3 + a2 x^2 + a4 x + a6 (projective count, singular point included)"""
    a1, a2, a3, a4, a6 = ai; cnt = 1
    for x in range(p):
        rhs = (x * x * x + a2 * x * x + a4 * x + a6) % p
        for y in range(p):
            if (y * y + a1 * x * y + a3 * y - rhs) % p == 0: cnt += 1
    return p + 1 - cnt

# ---------- P^1(Z/N), N prime ----------
def p1_index(c, d, N):
    c %= N; d %= N
    if d != 0: return c * pow(d, -1, N) % N
    assert c != 0
    return N                       # the point (1:0)

def rep_matrix(i, N):
    """g in SL2(Z) with bottom row representing index i"""
    if i == N: return (0, -1, 1, 0)
    return (1, 0, i, 1)

def cusp(num, den):
    if den < 0: num, den = -num, -den
    if den == 0: return (1, 0)
    g = math.gcd(num, den); return (num // g, den // g)

def act(m, c):
    a, b, cc, d = m; p, q = c
    return cusp(a * p + b * q, cc * p + d * q)

def manin_inf_to(r, N, acc, sign):
    """acc += sign * (Manin expansion of {oo, r})"""
    num, den = r
    if den == 0: return
    # continued fraction of num/den, convergents p_k/q_k; {oo, r} = sum_k [((-1)^{k-1} q_k : q_{k-1})]
    pm2, qm2, pm1, qm1 = 0, 1, 1, 0
    a, b = num, den; k = 0
    while True:
        qk = a // b
        pk_, qk_ = qk * pm1 + pm2, qk * qm1 + qm2
        s = -1 if k % 2 == 0 else 1          # (-1)^{k-1}
        # g_k = [s p_k, p_{k-1}; s q_k, q_{k-1}],  det = 1
        assert s * pk_ * qm1 - pm1 * s * qk_ == 1
        idx = p1_index(s * qk_, qm1, N); acc[idx] = acc.get(idx, 0) + sign
        pm2, qm2, pm1, qm1 = pm1, qm1, pk_, qk_
        a, b = b, a - qk * b; k += 1
        if b == 0: break
    assert (pm1, qm1) == (num, den) or (-pm1, -qm1) == (num, den)

def symbol(alpha, beta, N, acc, sign=1):
    """acc += sign * Manin expansion of {alpha, beta} = {oo, beta} - {oo, alpha}"""
    manin_inf_to(beta, N, acc, sign); manin_inf_to(alpha, N, acc, -sign)

def relations(N):
    """(kind, x, 0, vector): S-relation e_x + e_{xS}, tau-relation e_x + e_{x tau} + e_{x tau^2}"""
    res = []
    for i in range(N + 1):
        c, d = (1, 0) if i == N else (i, 1)
        v = {}
        for idx in (i, p1_index(d, -c, N)): v[idx] = v.get(idx, 0) + 1
        res.append(('S', i, 0, v))
        v = {}
        for idx in (i, p1_index(d, -c - d, N), p1_index(-c - d, c, N)): v[idx] = v.get(idx, 0) + 1
        res.append(('T', i, 0, v))
    return res

def hecke_vec(p, i, ap, N):
    a, b, c, d = rep_matrix(i, N)
    alpha, beta = cusp(b, d), cusp(a, c)          # g{0, oo} = {g 0, g oo}
    acc = {}
    for r in range(p):
        m = (1, r, 0, p); symbol(act(m, alpha), act(m, beta), N, acc)
    m = (p, 0, 0, 1); symbol(act(m, alpha), act(m, beta), N, acc)
    acc[i] = acc.get(i, 0) - ap
    return acc

def all_vectors(N, aps):
    vecs = [(k, i, 0, v) for k, i, _, v in relations(N)]
    for p in PRIMES:
        if N % p == 0: continue
        for i in range(N + 1): vecs.append(('H', i, p, hecke_vec(p, i, aps[p], N)))
    return vecs

def setup(label):
    base, _, pert = label.partition(':')
    N, ai = CURVES[base]
    aps = {p: naive_ap(p, ai) for p in PRIMES}
    if pert: p, dl = pert.split('+') if '+' in pert else (pert, '0'); aps[int(p[1:])] += int(dl)
    return N, ai, aps

def target(N):
    return {p1_index(0, 1, N): 1}      # e_(0:1) = [identity] = {0, oo}

def find(label, out):
    from flint import fmpq_mat
    t0 = time.time(); N, ai, aps = setup(label); vecs = all_vectors(N, aps); D = N + 1; K = len(vecs)
    tgt = target(N)
    # quotient dimension and codimension diagnostics
    Rm = fmpq_mat(len([v for v in vecs if v[0] != 'H']), D)
    r = 0
    for k, i, p, v in vecs:
        if k == 'H': continue
        for j, x in v.items(): Rm[r, j] = x
        r += 1
    rankR = Rm.rank()
    A = fmpq_mat(D, K + 1)
    for col, (k, i, p, v) in enumerate(vecs):
        for j, x in v.items(): A[j, col] = x
    for j, x in tgt.items(): A[j, K] = x
    E, rk = A.rref()
    pivots = []
    for row in range(rk):
        col = next(c for c in range(K + 1) if E[row, c] != 0); pivots.append((row, col))
    in_span = all(col != K for _, col in pivots)
    rankM = sum(1 for _, col in pivots if col != K)
    coeffs = {}
    if in_span:
        for row, col in pivots:
            val = E[row, K]
            if val != 0: coeffs[col] = str(val)
    res = dict(label=label, N=N, ainvs=ai, a_p={str(p): v for p, v in aps.items()}, primes=PRIMES, dim_V=D, rank_relations=rankR,
               dim_quotient=D - rankR, rank_relations_plus_hecke=rankM, codim=D - rankM, target_in_span=in_span,
               certificate=[dict(kind=vecs[c][0], x=vecs[c][1], p=vecs[c][2], coeff=q) for c, q in sorted(coeffs.items())],
               seconds=round(time.time() - t0, 1))
    res['verdict_search'] = ('L1_ZERO_CANDIDATE' if in_span and res['codim'] >= 1 else
                             ('DEGENERATE_CODIM0' if res['codim'] == 0 else 'NOT_IN_SPAN'))
    json.dump(res, open(out, 'w'), indent=0)
    print(json.dumps({k: v for k, v in res.items() if k != 'certificate'} | dict(nonzero_coeffs=len(coeffs))))

def verify(label, cf):
    """pure-Python exact check: recompute every vector, sum with Fraction coefficients, compare with e_(0:1)."""
    t0 = time.time(); c = json.load(open(cf)); N, ai, aps = setup(label)
    assert c['label'] == label and c['N'] == N
    assert {int(p): v for p, v in c['a_p'].items()} == aps, 'a_p mismatch with fresh naive counts'
    rel = {(k, i): v for k, i, _, v in relations(N)}
    tot = {}
    for e in c['certificate']:
        q = Fraction(e['coeff'])
        if e['kind'] == 'H':
            assert e['p'] in PRIMES and N % e['p'] != 0
            v = hecke_vec(e['p'], e['x'], aps[e['p']], N)
        else: v = rel[(e['kind'], e['x'])]
        for j, x in v.items(): tot[j] = tot.get(j, Fraction(0)) + q * x
    tot = {j: x for j, x in tot.items() if x != 0}
    ok = (tot == {p1_index(0, 1, N): Fraction(1)}) and len(c['certificate']) > 0 and c['codim'] >= 1
    out = dict(label=label, cert=cf, cert_sha256=hashlib.sha256(open(cf, 'rb').read()).hexdigest(), terms=len(c['certificate']),
               a_p=aps, codim_reported=c['codim'], identity_holds=(tot == {p1_index(0, 1, N): Fraction(1)}),
               verdict='L_E_1_IS_ZERO_PROVED' if ok else 'NOT_PROVED', seconds=round(time.time() - t0, 1))
    print(json.dumps(out)); return out

if __name__ == '__main__':
    mode, label = sys.argv[1], sys.argv[2]
    if mode == 'find': find(label, sys.argv[3])
    else: verify(label, sys.argv[3])
