"""NEGATIVE CONTROL helper: copy every certificate of SRC/certs to DST/certs, insert a forged sign-change interval (t1, t2) with
weight w (kept sorted), and mark it negative_control.  usage: python nc_forge.py SRC DST t1 t2 w"""
import sys, os, glob, json
src, dst, t1, t2, w = sys.argv[1], sys.argv[2], float(sys.argv[3]), float(sys.argv[4]), float(sys.argv[5])
os.makedirs(os.path.join(dst, 'certs'), exist_ok=True)
for f in sorted(glob.glob(os.path.join(src, 'certs', 'cell_*.json'))):
    c = json.load(open(f)); iv = [tuple(v) for v in c['intervals']]; ws = list(c['w'])
    k = sum(1 for a, b in iv if a < t1); iv.insert(k, (t1, t2)); ws.insert(k, w)
    c['intervals'] = [list(v) for v in iv]; c['w'] = ws; c['negative_control'] = dict(FORGED_INTERVAL=[t1, t2, w])
    json.dump(c, open(os.path.join(dst, 'certs', os.path.basename(f)), 'w'))
print('forged', len(glob.glob(os.path.join(dst, 'certs', '*.json'))))
