#!/bin/zsh
# Negative controls on the validation window 389.a1 [0,10] (W = [-6,16]). Every corrupted replay writes its own json (never replay.json).
P=/Users/kiosk/projects/atlas-rerun/.venv/bin/python
cd /Users/kiosk/atlas_mark2/diagnostic/new_territory/ec389a
V=runs/val_0_10; O=runs/nc; mkdir -p $O
G() { nice -n 19 $P -B -u gen_cert.py 389.a1 0 10 "$@"; }
RP() { nice -n 19 $P -B -u replay_deg2.py "$@"; }
# C1 fake sign change (3.5, 3.6) [no zero there: Z same sign] injected into the generator (true rows + intervals copied)
mkdir -p $O/fake; cp $V/rows.json $V/intervals.json $O/fake/
NC_FAKE=3.5,3.6 G $O/fake > $O/fake_gen.out 2>&1
[ -d $O/fake/certs ] && RP $O/fake 0 10 replay_NC.json > $O/fake_replay.out 2>&1
# C1b the same fake interval forged (w = 0.5) into all real certificates
$P -B nc_forge.py $V $O/forged 3.5 3.6 0.5 > /dev/null
RP $O/forged 0 10 replay_NC.json > $O/forged_replay.out 2>&1
# C2 perturbed a_2 (-2 -> -1): replay rows + Z; rows only (true Z); generator with a_2+1 rows
NC_AP=2:1 RP $V 0 10 replay_NC_a2.json > $O/a2_replay.out 2>&1
NC_AP=2:1 NC_ROWS_ONLY=1 RP $V 0 10 replay_NC_a2_rowsonly.json > $O/a2_rowsonly_replay.out 2>&1
mkdir -p $O/a2gen; cp $V/intervals.json $O/a2gen/
NC_AP=2:1 G $O/a2gen > $O/a2_gen.out 2>&1
# C3 wrong root number eps = -1: replay of the true certificates; generator scanning the wrong Z, replayed with true and wrong data
NC_EPS=-1 RP $V 0 10 replay_NC_eps.json > $O/eps_replay.out 2>&1
mkdir -p $O/epsgen; cp $V/rows.json $O/epsgen/
NC_EPS=-1 G $O/epsgen > $O/eps_gen.out 2>&1
if ls $O/epsgen/certs/cell_*.json >/dev/null 2>&1; then
  RP $O/epsgen 0 10 replay_true_data.json > $O/epsgen_replay_true.out 2>&1
  NC_EPS=-1 RP $O/epsgen 0 10 replay_NC_eps.json > $O/epsgen_replay_eps.out 2>&1
fi
# C4 wrong conductor N = 390 (rows + Z)
NC_N=390 RP $V 0 10 replay_NC_N390.json > $O/N390_replay.out 2>&1
# C5 central multiplicity. (a) generator with m0 = 0 (no reduction), 1, 3 (true rows + intervals)
for m in 0 1 3; do
  mkdir -p $O/m0_$m; cp $V/rows.json $V/intervals.json $O/m0_$m/
  NC_M0=$m G $O/m0_$m > $O/m0_${m}_gen.out 2>&1
  if ls $O/m0_$m/certs/cell_*.json >/dev/null 2>&1; then
    RP $O/m0_$m 0 10 replay_NC_policy.json > $O/m0_${m}_replay_policy.out 2>&1
    NC_NOPOLICY=1 RP $O/m0_$m 0 10 replay_NC_nopolicy.json > $O/m0_${m}_replay_nopolicy.out 2>&1
  fi
done
# (b) the true certificates replayed with m0 forged to 0, 1, 3, 4: with the policy, and as bare mathematics (policy off)
for m in 0 1 3 4; do
  NC_M0=$m RP $V 0 10 replay_NC_forgeM0_${m}_policy.json > $O/forgeM0_${m}_policy.out 2>&1
  NC_M0=$m NC_NOPOLICY=1 RP $V 0 10 replay_NC_forgeM0_${m}_nopolicy.json > $O/forgeM0_${m}_nopolicy.out 2>&1
done
# C6 modular-symbol controls (rank 0 curves not in span; rank 1 in span; perturbed a_2 degenerate)
for L in 11.a1 37.a1 37.b1 389.a1:a2+1; do $P -B modsym.py find $L "$O/modsym_$L.json" > "$O/modsym_$L.find.out" 2>&1; $P -B modsym.py verify $L "$O/modsym_$L.json" > "$O/modsym_$L.verify.out" 2>&1; done
echo NC_DONE > $O/done
