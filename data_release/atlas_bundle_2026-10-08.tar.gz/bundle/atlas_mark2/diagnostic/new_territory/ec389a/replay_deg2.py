"""Independent replay of all certificates in RUNDIR/certs (THEORY_DEG2.md section 8).
* every row enclosure is recomputed from scratch with DIFFERENT prime cut-offs (x1.5), quadrature (24 nodes, h = 0.4) and precision;
* far allowances and Nwin recomputed (farbound.py);
* every sign-change endpoint re-verified with the A = 1.2 split of the Lambda series at +40 bits, and the A = 1 value must overlap it
  as a COMPLEX ball (ec37a: real and imaginary parts; series self-consistency = functional-equation check of N, eps, a_n);
* the independently written verifier replay_verify.py is run plain and hardened (lo, hi, Fa moved 2 ulps outward);
* exact rational tiling: the certified cells cover [TLO, THI] and each covers d in [0, 1/2].
usage: python replay_deg2.py RUNDIR TLO THI [OUTNAME]   (OUTNAME default replay.json; negative controls must pass another name)
ec37a: form data from forms.py; NC_EPS overrides the root number (Z and series).
ec389a: central reduction (THEORY_389A.md section 3) checked by replay_verify with expect_m0 = forms.CENTRAL_M0 (the proved order);
if any certificate uses it, the central proofs are re-run in this process: modsym.verify (L(E,1) = 0, exact) and central.lam2
(Lambda''(1) != 0, Arb).  Negative controls: NC_M0 forges the certificates' m0; NC_NOPOLICY=1 drops the expect_m0 policy (bare maths)."""
import sys, os, json, glob, math, time, hashlib
from fractions import Fraction
from flint import arb
import forms, lfun, arith, farbound, replay_verify, modsym, central

PS2 = {0.8: 450000, 1.0: 1500000, 1.25: 3000000}
LEPS2 = {1.5: 1500000}

def main():
    run, tlo, thi = sys.argv[1], float(sys.argv[2]), float(sys.argv[3])
    outname = sys.argv[4] if len(sys.argv) > 4 else 'replay.json'
    if any(os.environ.get(k) is not None for k in ('NC_N', 'NC_AP', 'NC_EPS', 'NC_M0', 'NC_NOPOLICY')): assert outname != 'replay.json', 'NC replays must not overwrite replay.json'
    files = sorted(glob.glob(os.path.join(run, 'certs', 'cell_*.json')))
    certs = [json.load(open(f)) for f in files]
    assert certs, 'no certificates'
    form = certs[0]['form']; assert all(c['form'] == form for c in certs)
    F = forms.form(form, max(max(PS2.values()), max(LEPS2.values())) + 10)
    # NEGATIVE CONTROLS ONLY: NC_N / NC_AP corrupt the data; NC_ROWS_ONLY=1 corrupts the rows but keeps the true Z
    Fz = F
    if os.environ.get('NC_N') or os.environ.get('NC_AP') or os.environ.get('NC_EPS'):
        Fbad = dict(F)
        if os.environ.get('NC_N'): Fbad['N'] = int(os.environ['NC_N'])
        if os.environ.get('NC_AP'):
            p, dl = map(int, os.environ['NC_AP'].split(':')); Fbad = forms.perturb(Fbad, p, dl)
        if os.environ.get('NC_EPS'): Fbad['eps'] = int(os.environ['NC_EPS'])
        print('NEGATIVE CONTROL replay with corrupted data', {k: os.environ.get(k) for k in ('NC_N', 'NC_AP', 'NC_EPS', 'NC_ROWS_ONLY')}, flush=True)
        if not os.environ.get('NC_ROWS_ONLY'): Fz = Fbad
        F = Fbad
    expect_m0 = None if os.environ.get('NC_NOPOLICY') else forms.CENTRAL_M0
    m0_override = int(os.environ['NC_M0']) if os.environ.get('NC_M0') is not None else None
    central_proof = None
    if any(c.get('central') for c in certs) or m0_override:
        here = os.path.dirname(os.path.abspath(__file__))
        ms = modsym.verify('389.a1', os.path.join(here, 'logs', 'modsym', '389.a1.json'))
        l2, _ = central.lam2(forms.form('389.a1', 1000))
        central_proof = dict(modsym=ms['verdict'], modsym_cert_sha256=ms['cert_sha256'], Lambda_pp_1=l2.str(20),
                             order_exactly_2=bool(ms['verdict'] == 'L_E_1_IS_ZERO_PROVED' and l2.lower() > 0))
        print(json.dumps(dict(central_proof=central_proof)), flush=True)
        assert central_proof['order_exactly_2'] or os.environ.get('NC_NOPOLICY'), 'central order 2 not re-proved'
    AR = {}; rowcache = {}; zcache = {}
    def getrow(k, p, t, W):
        key = (k, p, t, tuple(W))
        if key not in rowcache:
            P = (PS2 if k == 'S' else LEPS2)[p]
            if (k, p) not in AR: AR[(k, p)] = arith.Arith(F, P, prec=112)
            A = AR[(k, p)]
            v = A.sech_row(p, t, nodes=24, h=0.4) if k == 'S' else A.lor_row(p, t)
            lo = math.nextafter(float(v.lower()), -math.inf); hi = math.nextafter(float(v.upper()), math.inf)
            fa = farbound.sech_far(F, p, t, W[0], W[1]) if k == 'S' else farbound.lor_far(F, p, t, W[0], W[1])
            rowcache[key] = (lo, hi, fa)
        return rowcache[key]
    def zcheck(t1, t2):
        out = []
        for t in (t1, t2):
            if t not in zcache:
                pr = 96 + int(2.3 * abs(t)) + 32 + 40
                v12 = lfun.Lam_line(Fz, t, prec=pr, A=1.2); v1 = lfun.Lam_line(Fz, t, prec=pr - 40, A=1.0)
                zcache[t] = (v12, v1)
            v12, v1 = zcache[t]
            if not v12.overlaps(v1): return False, f'series mismatch at {t}: {v12} vs {v1}'
            out.append(lfun.sign(lfun.zpart(Fz, v12)))
        ok = out[0] != 0 and out[1] != 0 and out[0] == -out[1]
        return ok, out
    results = []; t00 = time.time()
    for f, c in zip(files, certs):
        W = c['window']; t0 = time.time()
        vals = [getrow(k, p, t, W) for k, p, t in c['rows']]
        lo = [v[0] for v in vals]; hi = [v[1] for v in vals]; Fa = [v[2] for v in vals]
        Nw = farbound.Nwin(F, W[0], W[1])
        rec = dict(file=os.path.basename(f), cell=c['cell'])
        for mode in ('plain', 'hardened'):
            if mode == 'hardened':
                lo2 = [math.nextafter(math.nextafter(v, -math.inf), -math.inf) for v in lo]
                hi2 = [math.nextafter(math.nextafter(v, math.inf), math.inf) for v in hi]
                Fa2 = [math.nextafter(math.nextafter(v, math.inf), math.inf) for v in Fa]
                Nw2 = math.nextafter(math.nextafter(Nw, math.inf), math.inf)
            else: lo2, hi2, Fa2, Nw2 = lo, hi, Fa, Nw
            r = replay_verify.run(c, lo2, hi2, Fa2, Nw2, zcheck, expect_m0=expect_m0, m0_override=m0_override)
            rec[mode] = r['status']; rec[mode + '_min_candidate_lower'] = r.get('min_candidate_lower')
            if r['status'] != 'CERTIFIED': rec[mode + '_detail'] = r
        rec['seconds'] = round(time.time() - t0, 1)
        print(json.dumps(rec), flush=True); results.append(rec)
    ok_cells = [(Fraction(c['cell'][0]), Fraction(c['cell'][1])) for c, r in zip(certs, results)
                if r['plain'] == 'CERTIFIED' and r['hardened'] == 'CERTIFIED' and c['d_range'] == [0.0, 0.5]]
    ok_cells.sort(); cur = Fraction(tlo); gaps = []
    for a, b in ok_cells:
        if a > cur: gaps.append([float(cur), float(a)])
        cur = max(cur, b)
    if cur < Fraction(thi): gaps.append([float(cur), thi])
    vsha = hashlib.sha256(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'replay_verify.py'), 'rb').read()).hexdigest()
    summ = dict(SUMMARY=run, form=form, ap_table_sha256=forms.AP_SHA256, target=[tlo, thi], certificates=len(certs), passed_both=len(ok_cells), tiling_gaps=gaps,
                closed=(not gaps), replay_verify_sha=vsha, sign_change_endpoints_checked=len(zcache), seconds=round(time.time() - t00, 1),
                min_margin=min((r['hardened_min_candidate_lower'] for r in results if r.get('hardened_min_candidate_lower') is not None), default=None),
                central_proof=central_proof,
                claim=(('every zero of L(s) with ordinate in [%g, %g] lies on the critical line and is simple' % (tlo, thi)) +
                       (', except the central zero s = 1/2 (ordinate 0), which has multiplicity exactly 2' if tlo <= 0 <= thi else '')) if not gaps else None)
    print(json.dumps(summ), flush=True)
    json.dump(dict(summary=summ, cells=results), open(os.path.join(run, outname), 'w'), indent=1)

if __name__ == '__main__':
    main()
