#!/bin/zsh
# Validation window [0,10] (W = [-6, 16], contains the central double zero): generator then fresh-process replay.
P=/Users/kiosk/projects/atlas-rerun/.venv/bin/python
cd /Users/kiosk/atlas_mark2/diagnostic/new_territory/ec389a; R=runs/val_0_10; mkdir -p $R
/usr/bin/time -l nice -n 19 $P -B -u gen_cert.py 389.a1 0 10 $R > $R.out 2>&1
/usr/bin/time -l nice -n 19 $P -B -u replay_deg2.py $R 0 10 > $R.replay.out 2>&1
echo VAL_DONE >> $R.out
