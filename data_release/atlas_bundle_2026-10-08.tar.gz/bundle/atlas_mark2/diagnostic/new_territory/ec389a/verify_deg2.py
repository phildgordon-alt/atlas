"""Trusted verifier for one degree-2 sign-change LP certificate (THEORY_DEG2.md section 7, Theorem + Lemma 2).
Pure function of: rows (kind, param, t), row enclosures lo/hi and far allowances Fa (recomputed by the caller), Nwin,
window W, cell, y_up, y_lo, y_c, w, intervals, and a callable zcheck(t1, t2) -> (ok, info) that re-verifies the sign change.
Atoms: on-line zeros (x, 0, f=1) and same-ordinate pairs / double on-line zeros (x, d, f=2), 0 <= d <= 1/2, x in W.
Var boxes: [wlo, whi] x [0, 1/2] with f = 2 (cut into unit boxes); this covers every atom (Phi scales with f).
  (R)  f (yc + sum_j c_j U_j(x,d)) - f * SUM_{i: d=0 in box, [t1_i,t2_i] meets box} w_i >= 0 on every var box
  (C)  2 (yc + sum_j c_j U_j(x,d)) - K - 2 yc + sum_i w_i > 0 on cell x [0, 1/2]
  K = sum_j [yup_j hi_j - ylo_j (lo_j - Fa_j)] + yc (Nwin - 2).
Also: (consistency) for every row with yup_j > 0 or ylo_j > 0, sum_i min_{x in I_i} U_j(x, 0) <= hi_j  (else the inputs are
contradictory: INCONSISTENT).
ec389a central reduction (THEORY_389A.md section 3): with central = m0 > 0 the known central atom (0, 0, m0) is removed from the zero
configuration: hi_j, lo_j -> hi_j - m0 U_j(0,0), lo_j - m0 U_j(0,0) (Arb), Nwin -> Nwin - m0; everything else unchanged.
Policy (BAD_CENTRAL): m0 > 0 requires wlo < 0 < whi and every interval with t2 < 0 or t1 > 0; if expect_m0 is given, a window with
wlo < 0 < whi must carry central == expect_m0 (the proved order) and a window without 0 must carry no central atom."""
import math
from flint import arb, ctx

PREC = 128

def _ball(lo, hi):
    a, b = arb(lo), arb(hi)
    return (a + b) / 2 + arb(0, ((b - a) / 2).upper())

def _U(kind, p, t, x, d):
    r = x - arb(t); P = arb(p)
    if kind == 'S':
        c = (P * d).cos(); sh = (P * r).sinh()
        return (P * r).cosh() * c / (sh * sh + c * c)
    else:
        em = P - d; ep = P + d
        return (em / (em * em + r * r) + ep / (ep * ep + r * r)) / 2

def check(rows, lo, hi, Fa, Nwin, window, cell, yup, ylo, yc, w, intervals, zcheck=None, maxdepth=60, budget=3_000_000, sub='sum',
          central=0, expect_m0=None):
    old = ctx.prec; ctx.prec = PREC
    try:
        return _check(rows, lo, hi, Fa, Nwin, window, cell, yup, ylo, yc, w, intervals, zcheck, maxdepth, budget, sub, central, expect_m0)
    finally:
        ctx.prec = old

def _check(rows, lo, hi, Fa, Nwin, window, cell, yup, ylo, yc, w, intervals, zcheck, maxdepth, budget, sub, central=0, expect_m0=None):
    J = len(rows); wlo, whi = map(float, window); x0, x1 = map(float, cell)
    if not (len(lo) == len(hi) == len(Fa) == len(yup) == len(ylo) == J and len(w) == len(intervals)): return dict(status='BAD_SHAPE')
    vals = list(yup) + list(ylo) + [yc] + list(w)
    if any((not math.isfinite(float(v))) or float(v) < 0 for v in vals): return dict(status='BAD_SIGN')
    if not (wlo <= x0 < x1 <= whi): return dict(status='BAD_CELL')
    for (kind, p, t) in rows:
        if kind == 'S':
            if not (0 < p < math.pi and wlo < t < whi): return dict(status='BAD_ROW', row=[kind, p, t])
        elif kind == 'L':
            if not (p > 0.5 and t - wlo >= p + 0.5 and whi - t >= p + 0.5): return dict(status='BAD_ROW', row=[kind, p, t])
        else: return dict(status='BAD_ROW', row=[kind, p, t])
    for (t1, t2) in intervals:
        if not (wlo <= t1 < t2 <= whi): return dict(status='BAD_INTERVAL', interval=[t1, t2])
    m0 = int(central or 0); has0 = wlo < 0.0 < whi
    if m0 < 0: return dict(status='BAD_CENTRAL', why='negative m0')
    if m0 > 0:
        if not has0: return dict(status='BAD_CENTRAL', why='central atom outside window')
        for (t1, t2) in intervals:
            if not (t2 < 0.0 or t1 > 0.0): return dict(status='BAD_CENTRAL', why='interval meets 0', interval=[t1, t2])
    if expect_m0 is not None and m0 != (expect_m0 if has0 else 0):
        return dict(status='BAD_CENTRAL', why=f'm0={m0} but the proved central order is {expect_m0} (window contains 0: {has0})')
    hiA = [arb(v) for v in hi]; loA = [arb(v) for v in lo]; NwA = arb(Nwin)
    if m0 > 0:
        for j, (kind, p, t) in enumerate(rows):
            u0 = _U(kind, p, t, arb(0), arb(0))
            hiA[j] = hiA[j] - m0 * u0; loA[j] = loA[j] - m0 * u0
        NwA = NwA - m0
    if zcheck is not None:
        for (t1, t2) in intervals:
            ok, info = zcheck(t1, t2)
            if not ok: return dict(status='NO_SIGN_CHANGE', interval=[t1, t2], info=info)
    # consistency: each interval holds >= 1 on-line zero, U_j >= 0, far zeros >= 0  =>  sum_i min_{I_i} U_j(.,0) <= S_j <= hi_j
    for j, (kind, p, t) in enumerate(rows):
        s = arb(0)
        for (t1, t2) in intervals:
            s += _U(kind, p, t, _ball(t1, t2), arb(0)).lower()
        if s.lower() > hiA[j]:
            return dict(status='INCONSISTENT', row=[kind, p, t], credit_lower=float(s.lower()), hi=hi[j], hi_reduced=float(hiA[j].mid()))
    terms = [(arb(yup[j]) - arb(ylo[j]), rows[j]) for j in range(J) if yup[j] != ylo[j]]
    K = arb(0)
    for j in range(J):
        K += arb(yup[j]) * hiA[j] - arb(ylo[j]) * (loA[j] - arb(Fa[j]))
    K += arb(yc) * (NwA - 2)
    Wsum = arb(0)
    for v in w: Wsum += arb(v)
    YC = arb(yc)
    def phi(b0, b1, e0, e1):
        x = _ball(b0, b1); d = _ball(e0, e1); s = YC
        for c, (kind, p, t) in terms:
            s += c * _U(kind, p, t, x, d)
        return s
    def zsub(b0, b1, e0):
        if e0 > 0: return arb(0)
        hit = [arb(v) for (t1, t2), v in zip(intervals, w) if b0 <= t2 and b1 >= t1]
        if not hit: return arb(0)
        if sub == 'max': return max(hit, key=lambda q: float(q.mid()))     # UNSOUND variant (negative control only)
        s = arb(0)
        for h_ in hit: s += h_
        return s
    roots = []
    n = int(math.ceil(whi - wlo))
    for j in range(n):
        roots.append(('rem', wlo + (whi - wlo) * j / n, wlo + (whi - wlo) * (j + 1) / n if j < n - 1 else whi, 0.0, 0.5))
    roots.append(('cand', x0, x1, 0.0, 0.5))
    nb = 0; minc = None; minr = None
    for kind, b0_, b1_, e0_, e1_ in roots:
        st = [(b0_, b1_, e0_, e1_, 0)]
        while st:
            b0, b1, e0, e1, dep = st.pop(); nb += 1
            if nb > budget: return dict(status='BUDGET', boxes=nb)
            v = phi(b0, b1, e0, e1)
            if kind == 'cand':
                v = 2 * v - K - 2 * YC + Wsum
                if v.lower() > 0:
                    lv = float(v.lower()); minc = lv if minc is None else min(minc, lv); continue
            else:
                v = 2 * v - 2 * zsub(b0, b1, e0)
                if v.lower() >= 0:
                    lv = float(v.lower()); minr = lv if minr is None else min(minr, lv); continue
            if dep >= maxdepth:
                return dict(status='FAIL', kind=kind, box=[b0, b1, e0, e1], value=v.str(6), boxes=nb)
            if (b1 - b0) >= 4 * (e1 - e0) or e0 == e1:
                m = (b0 + b1) / 2; st += [(b0, m, e0, e1, dep + 1), (m, b1, e0, e1, dep + 1)]
            else:
                m = (e0 + e1) / 2; st += [(b0, b1, e0, m, dep + 1), (b0, b1, m, e1, dep + 1)]
    return dict(status='CERTIFIED', boxes=nb, min_candidate_lower=minc, K=float(K.mid()), sum_w=float(Wsum.mid()), central_m0=m0)
