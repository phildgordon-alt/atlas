P=/Users/kiosk/projects/atlas-rerun/.venv/bin/python; N=/Users/kiosk/atlas_mark2/diagnostic/new_territory; D=/Users/kiosk/atlas_mark2/diagnostic
until [ -f $D/atlas_v4/runs/acceptance.done ] && [ -f $D/plant_test/RESULTS.md ]; do sleep 120; done
cd $N/deg2; mkdir -p runs/contig
for k in $(seq 0 29); do lo=$((10*k)); hi=$((10*k+10)); R=runs/contig/c_${lo}_${hi}
  [ -f $R/replay.json ] && continue
  $P -B gen_cert.py 11.a $lo $hi $R > $R.out 2>&1
  $P -B replay_deg2.py $R $lo $hi > $R.replay.out 2>&1
  echo "$lo $hi $(tail -1 $R.replay.out | grep -o '"closed": [a-z]*') $(tail -1 $R.replay.out | grep -o '"passed_both": [0-9]*')" >> runs/contig/SUMMARY.log
done
touch runs/contig/done
