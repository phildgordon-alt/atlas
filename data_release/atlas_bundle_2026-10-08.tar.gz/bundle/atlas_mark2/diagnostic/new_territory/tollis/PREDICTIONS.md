# Tollis extension — pre-registered 2026-10-08 (written after the six validation windows [0,10], BEFORE any target run)

Code: tollis/ as frozen in CODE_SHA256_FROZEN.txt (copied from ec389a; forms.py/cubic.py/verify_cubic.py new; type tables types/*.npy
VERIFIED by verify_cubic.py, shas in TYPES_SHA256.json). Theory: THEORY_TOLLIS.md. Runs: `run_targets.sh PLAN.txt` (lines in order;
gen_cert.py defaults --margin 6 --cell 0.5 --step 0.02; each run replayed in a fresh process: rows recomputed x1.5 prime cut-offs,
24 nodes, h = 0.4; every sign-change endpoint re-verified with the A = 1.2 series (complex overlap with A = 1); replay_verify.py plain +
hardened with expect_m0 = 0; exact Fraction tiling). Then union.py per field, lean_gap_check.py over all certificates (conditions 1–4),
diag_tollis.py per field, verify_cubic.py re-run fresh.

L = ζ_K/ζ (N = |d_K|, k = 1, ε = +1). Tollis heights H (Table 6.2, p. 1318): −23: 93.81, −31: 94.11, −44: 93.98, −59: 93.78, −76: 93.89, −83: 93.73.

**P1 (main).** For each of the six fields, the window [H − 2, H + 10] closes (every certificate passes plain + hardened replay; exact tiling
0 gaps). Claim if met: every zero of L with ordinate in [H−2, H+10] lies on the critical line and is simple; with Tollis [0, H] and RH for ζ
to 3·10¹² (Platt–Trudgian): **GRH for ζ_K holds for |Im s| ≤ H + 10**.
Predicted sign changes in [H−2, H+10] (main term N(T) = (T/π) log(√N T/(2πe)), ±2):

| field | window | main term | predicted |
|---|---|---|---|
| −23 | [91.81, 103.81] | 16.47 | 16 |
| −31 | [92.11, 104.11] | 17.05 | 17 |
| −44 | [91.98, 103.98] | 17.72 | 18 |
| −59 | [91.78, 103.78] | 18.27 | 18 |
| −76 | [91.89, 103.89] | 18.76 | 19 |
| −83 | [91.73, 103.73] | 18.92 | 19 |

**P2 (if run).** Contiguous [0, 110] for each field in 11 chunks [10j, 10j+10]; union 0 gaps. Claim if met: GRH for ζ_K for |Im s| ≤ 110,
independently of Tollis (only Platt–Trudgian for ζ). **P2-diag (falsifiable cross-check with Tollis):** the number of sign changes of Z in
(0, 92] equals Tollis's Nb ≤ 92 minus 25 (ζ has 25 zeros ≤ 92): −23: 96, −31: 100, −44: 105, −59: 109, −76: 113, −83: 114
(main term + 7/8: 96.1, 100.5, 105.6, 109.9, 113.6, 114.9). A mismatch is reported as a discrepancy with Tollis (it would not by itself
invalidate a closed certificate, which does not use counts). First zero must match Tollis's column (already seen in validation:
5.11568, 4.16621, 4.04200, 3.43181, 3.27623, 2.91607 vs Tollis 5.11568, 4.16621, 4.04199, 3.43180, 3.27623, 2.91606).
Per-chunk predictions: main-term increments (±2), e.g. −23: 3.3, 7.7, 9.4, 10.4, 11.3, 11.9, 12.4, 12.9, 13.3, 13.6, 14.0; −83: 5.3, 9.7,
11.4, 12.5, 13.3, 13.9, 14.5, 14.9, 15.3, 15.7, 16.0 (others between; computed by the same formula).

**P3 (if run).** −23 contiguous [0, 200] (chunks to 200), union 0 gaps; per-chunk main terms 14.2, 14.5, 14.8, 15.0, 15.2, 15.4, 15.6, 15.8,
15.9 for [110,120] … [190,200] (±2).

**Falsifiers.** Any target window not closed (reported with location and status), any replay failure, any union gap, any condition (1)–(4)
violated, verify_cubic.py not VERIFIED. Count misses are reported but do not affect P1–P3.
Scope: totally real fields (Table 6.1) are not attempted (THEORY_TOLLIS §7).
