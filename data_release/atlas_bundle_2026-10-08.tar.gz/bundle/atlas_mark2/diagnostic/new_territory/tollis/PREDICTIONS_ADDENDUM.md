# Tollis extension — ADDENDUM: the four remaining complex cubic fields of Table 6.2 (pre-registered 2026-10-08, BEFORE any run of these fields)

Fields: d_K = −87 (x³+x²+2x−1), −104 (x³−x−2), −107 (x³−x²+3x−2), −108 (x³−2). Type tables types/K87, K104, K107, K108 .npy were
VERIFIED by verify_cubic.py (logs/types_verify*.out; Dedekind's criterion at 2 for −104, at 2 and 3 for −108) and pass the theta check
(logs/diag_theta.out, n ≤ 20 000, 0 mismatches; h = 6 for −87, −104; h = 3 for −107, −108). No window of these four fields has been run
before this file was written (no validation window either).

Code: unchanged, frozen per CODE_SHA256_FROZEN.txt (checked before the runs: every entry OK except diag_tollis.py, the post-freeze
diagnostic-only edit already disclosed in RESULTS.md; its current sha256 is abff6d0c0a2b7bf29fb5663df1a8358e8ead868c1c3cfa1024dff30125fa89ee).
Procedure identical to PREDICTIONS.md: `run_targets.sh PLAN_ADDENDUM.txt` (gen_cert.py defaults; fresh-process replay_deg2.py per run:
×1.5 prime cut-offs, 24 nodes, h = 0.4, A = 1.2 endpoint re-verification, replay_verify.py plain + hardened, expect_m0 = 0; exact Fraction
tiling); then union.py per field over [0,110], lean_gap_check.py over all certificates (conditions 1–4), diag_tollis.py per field (diagnostic).

Tollis heights H (Table 6.2, p. 1318): −87: 93.38, −104: 93.06, −107: 93.34, −108: 94.26.

**A1 (main).** For each of the four fields, the window [H − 2, H + 10] closes (every certificate passes plain + hardened replay; exact tiling
0 gaps). Predicted sign changes of Z (main term N(T) = (T/π) log(√N T/(2πe)), ±2):

| field | window | main term | predicted |
|---|---|---|---|
| −87  | [91.38, 103.38]  | 19.00 | 19 |
| −104 | [91.06, 103.06]  | 19.32 | 19 |
| −107 | [91.34, 103.34]  | 19.39 | 19 |
| −108 | [92.26, 104.26]  | 19.44 | 19 |

**A2.** Contiguous [0, 110] for each field in 11 chunks [10j, 10j+10], every chunk closed, union.py 0 gaps. Claim if met: every zero of
L = ζ_K/ζ with |Im s| ≤ 110 is on the critical line and simple; with Platt–Trudgian, GRH for ζ_K for |Im s| ≤ 110, independently of Tollis.
Per-chunk predicted counts (main-term increments, same convention as PREDICTIONS.md, ±2), chunks [0,10] … [100,110]:
* −87:  5.4, 9.8, 11.5, 12.6, 13.4, 14.0, 14.5, 15.0, 15.4, 15.8, 16.1
* −104: 5.7, 10.1, 11.8, 12.8, 13.7, 14.3, 14.8, 15.3, 15.7, 16.0, 16.4
* −107: 5.7, 10.1, 11.8, 12.9, 13.7, 14.3, 14.9, 15.3, 15.7, 16.1, 16.4
* −108: 5.7, 10.2, 11.8, 12.9, 13.7, 14.4, 14.9, 15.3, 15.7, 16.1, 16.4

**A2-diag (falsifiable cross-check with Tollis; diagnostic).** Sign changes of Z in (0, 92] = Tollis Nb ≤ 92 − 25:
−87: 140 − 25 = **115**, −104: 142 − 25 = **117**, −107: 143 − 25 = **118**, −108: 143 − 25 = **118** (main term + 7/8: 115.6, 118.2, 118.6,
118.7). First sign change must match Tollis's first zero: 2.68368, 3.31991, 2.61608, 2.82161. Note for −87: Tollis's Least Gap 0.00008 is a
ζ/L near-coincidence (THEORY §1); our Gap column (with ζ zeros to 6 decimals) is expected to reproduce it only to ~1e−5.

**Prediction: all 48 runs (4 core windows + 44 chunks) closed, all replays pass plain + hardened, 4 unions with 0 gaps, 0 condition
violations.** Falsifiers as in PREDICTIONS.md (any window not closed, replay failure, union gap, condition (1)–(4) violation). Count misses are
reported but do not affect A1/A2.
