# Tollis extension — ADDENDUM 2: the 15 remaining complex cubic fields of Table 6.2 (pre-registered 2026-10-08, BEFORE any run of these fields)

Fields (Tollis, Math. Comp. 66 (1997), Table 6.2, p. 1318, rows 11–25; P(x), D_K, GRH Height H, Nb ≤ 92, First Zero):

| field | P(x) | H | Nb ≤ 92 | first zero | disc(P) | index / Dedekind | h(D) |
|---|---|---|---|---|---|---|---|
| −116 | x³ − x² − 2 | 93.73 | 144 | 3.11568 | −116 = −2²·29 | criterion at 2: OK (2 = 𝔭²𝔮) | 6 |
| −135 | x³ + 3x − 1 | 93.12 | 146 | 2.04028 | −135 = −3³·5 | criterion at 3: OK (3 = 𝔭³) | 6 |
| −139 | x³ + x² + x − 2 | 93.40 | 146 | 2.66179 | −139 (prime) | squarefree ⇒ index 1 | 3 |
| −140 | x³ + 2x − 2 | 93.35 | 147 | 2.27790 | −140 = −2²·5·7 | criterion at 2: OK (2 = 𝔭³) | 6 |
| −152 | x³ − x² − 2x − 2 | 94.20 | 148 | 2.81196 | −152 = −2³·19 | criterion at 2: OK (2 = 𝔭²𝔮) | 6 |
| −172 | x³ + x² − x − 3 | 93.79 | 150 | 2.35670 | −172 = −2²·43 | criterion at 2: OK (2 = 𝔭³) | 3 |
| −175 | x³ − x² + 2x − 3 | 93.20 | 150 | 1.81080 | −175 = −5²·7 | criterion at 5: OK (5 = 𝔭³) | 6 |
| −199 | x³ − x² + 4x − 1 | 92.30 | 152 | 1.67161 | −199 (prime) | squarefree ⇒ index 1 | 9 |
| −200 | x³ + x² + 2x − 2 | 93.67 | 152 | 2.52234 | −200 = −2³·5² | criterion at 2 (𝔭²𝔮) and 5 (𝔭³): OK | 6 |
| −204 | x³ − x² + x − 3 | 93.07 | 152 | 2.51256 | −204 = −2²·3·17 | criterion at 2: OK (2 = 𝔭³) | 6 |
| −211 | x³ − 2x − 3 | 92.83 | 153 | 2.29906 | −211 (prime) | squarefree ⇒ index 1 | 3 |
| −212 | x³ − x² + 4x − 2 | 93.27 | 152 | 2.46540 | −212 = −2²·53 | criterion at 2: OK (2 = 𝔭²𝔮) | 6 |
| −216 | x³ + 3x − 2 | 94.07 | 153 | 2.79656 | −216 = −2³·3³ | criterion at 2 (𝔭²𝔮) and 3 (𝔭³): OK | 6 |
| −231 | x³ + x² − 3 | 93.14 | 154 | 1.84481 | −231 = −3·7·11 | squarefree ⇒ index 1 | 12 |
| −239 | x³ − x − 3 | 93.83 | 154 | 2.12721 | −239 (prime) | squarefree ⇒ index 1 | 15 |

**Index / order check (per field).** For all 15 polynomials disc(P) = D_K exactly. Since disc(P) = [O_K : Z[α]]² · d_K, a prime can divide
the index only if p² | disc(P); at every such p (2 for −116, −140, −152, −172, −200, −204, −212, −216; 3 for −135, −216; 5 for −175, −200)
Dedekind's criterion was verified exactly (verify_cubic.py, column above). Hence Z[α] = O_K, d_K = disc(P) is proved (not taken from Tollis),
and Dedekind–Kummer applies at every prime; no non-maximal-order correction is needed for any of the 15 fields.

**Tables.** types/K116 … K239.npy built by cubic.build (FLINT factorisation; `logs/types_build_addendum2.out`) and **VERIFIED** by
verify_cubic.py in two separate fresh processes (`logs/types_verify_addendum2_run{1,2}.out`, p ≤ 3 000 010, 216 816 primes, ~19 s per field,
identical shas). Shas: `TYPES_SHA256_ADDENDUM2.json` (sha256 3bea4902…7247; = the 10 frozen entries of TYPES_SHA256.json verbatim + the 15 new).

**Diagnostics (done before this file; no zeros computed).** Theta series 4f = 2Σ_{C ∈ ker ψ} θ_C − Σ_{C ∉ ker ψ} θ_C over the form class group
of discriminant d_K: 0 mismatches for n ≤ 20 000 for **all 15 fields** (`logs/diag_theta2_addendum2.out`, new diag_theta2.py with Gauss
composition, ker ψ = cubes, index 3 checked; 3-rank 1 for all, incl. h = 9, 12, 15 for −199, −231, −239), and independently with the frozen
diag_theta.py for the 12 fields with h ∈ {3, 6} (`logs/diag_theta_addendum2.out`, 0 mismatches). LMFDB small-p traces: see RESULTS (fetched
where the captcha allowed).

**Code.** Frozen pipeline unchanged; checked before this file: CODE_SHA256_FROZEN.txt all OK except diag_tollis.py (the post-freeze
diagnostic-only edit already disclosed; sha256 abff6d0c…89ee). The frozen field registry (cubic.FIELDS, TYPES_SHA256.json) lists only the first
10 fields, so the new fields are registered **at run time, in memory, data only** by the new files
* `fields_ext2.py` (sha256 11c27731…96f5): adds the 15 entries to cubic.FIELDS and forms.FORMS (N = |d|, k = 1, ε = +1, the frozen rule),
  points forms.SHA_FILE to TYPES_SHA256_ADDENDUM2.json; refuses to overwrite any existing entry;
* `run_ext2.py` (sha256 665d1404…0984): installs the registration and runs a frozen script unchanged via runpy as `__main__`;
* `run_targets_ext2.sh` (sha256 3755ea02…4986): run_targets.sh with the launcher inserted, a < 2 GB free-disk stop, an end-time column,
  output to runs/SUMMARY_ADDENDUM2.log.

Regression check of the launcher (before this file): K23 [0, 10] regenerated and replayed through run_ext2.py (scratchpad) gives 20/20 closed and
all 20 certificate JSONs **field-for-field identical** to the frozen runs/contig/K23/c_0_10 certificates.

Procedure identical to PREDICTIONS.md / PREDICTIONS_ADDENDUM.md: `run_targets_ext2.sh PLAN_ADDENDUM2.txt` (sha256 05088433…188a; 15 core
windows first, then 165 chunks; gen_cert.py defaults --margin 6 --cell 0.5 --step 0.02; fresh-process replay_deg2.py per run: ×1.5 prime
cut-offs, 24 nodes, h = 0.4, A = 1.2 endpoint re-verification, replay_verify.py plain + hardened with expect_m0 = 0; exact Fraction tiling);
then union.py per field over [0,110] and per core window, lean_gap_check.py over the whole tree (conditions (1)–(4)), diag_tollis.py per field.

L = ζ_K/ζ, N = |d_K|, k = 1, ε = +1. Main term N(T) = (T/π) log(√N T/(2πe)).

**B1 (main).** For each of the 15 fields the window [H − 2, H + 10] closes (all certificates pass plain + hardened replay; exact tiling 0 gaps).

| field | window | main term | predicted (±2) |
|---|---|---|---|
| −116 | [91.73, 103.73] | 19.56 | 20 |
| −135 | [91.12, 103.12] | 19.82 | 20 |
| −139 | [91.40, 103.40] | 19.89 | 20 |
| −140 | [91.35, 103.35] | 19.90 | 20 |
| −152 | [92.20, 104.20] | 20.09 | 20 |
| −172 | [91.79, 103.79] | 20.31 | 20 |
| −175 | [91.20, 103.20] | 20.32 | 20 |
| −199 | [90.30, 102.30] | 20.53 | 21 |
| −200 | [91.67, 103.67] | 20.60 | 21 |
| −204 | [91.07, 103.07] | 20.61 | 21 |
| −211 | [90.83, 102.83] | 20.67 | 21 |
| −212 | [91.27, 103.27] | 20.69 | 21 |
| −216 | [92.07, 104.07] | 20.76 | 21 |
| −231 | [91.14, 103.14] | 20.85 | 21 |
| −239 | [91.83, 103.83] | 20.94 | 21 |

**B2.** Contiguous [0, 110] per field in 11 chunks [10j, 10j+10], every chunk closed, union.py 0 gaps. Claim if met: every zero of L with
|Im s| ≤ 110 is on the critical line and simple; with Platt–Trudgian, GRH for ζ_K for |Im s| ≤ 110, independently of Tollis.
Per-chunk predicted counts (main-term increments, ±2), chunks [0,10] … [100,110]:
* −116: 5.9, 10.3, 11.9, 13.0, 13.8, 14.5, 15.0, 15.5, 15.9, 16.2, 16.5
* −135: 6.1, 10.5, 12.2, 13.3, 14.1, 14.7, 15.2, 15.7, 16.1, 16.5, 16.8
* −139: 6.1, 10.6, 12.2, 13.3, 14.1, 14.8, 15.3, 15.7, 16.1, 16.5, 16.8
* −140: 6.2, 10.6, 12.2, 13.3, 14.1, 14.8, 15.3, 15.8, 16.2, 16.5, 16.8
* −152: 6.3, 10.7, 12.4, 13.5, 14.3, 14.9, 15.4, 15.9, 16.3, 16.6, 17.0
* −172: 6.5, 10.9, 12.6, 13.6, 14.5, 15.1, 15.6, 16.1, 16.5, 16.8, 17.2
* −175: 6.5, 10.9, 12.6, 13.7, 14.5, 15.1, 15.7, 16.1, 16.5, 16.9, 17.2
* −199: 6.7, 11.1, 12.8, 13.9, 14.7, 15.3, 15.9, 16.3, 16.7, 17.1, 17.4
* −200: 6.7, 11.1, 12.8, 13.9, 14.7, 15.3, 15.9, 16.3, 16.7, 17.1, 17.4
* −204: 6.8, 11.2, 12.8, 13.9, 14.7, 15.4, 15.9, 16.4, 16.8, 17.1, 17.4
* −211: 6.8, 11.2, 12.9, 14.0, 14.8, 15.4, 16.0, 16.4, 16.8, 17.2, 17.5
* −212: 6.8, 11.2, 12.9, 14.0, 14.8, 15.4, 16.0, 16.4, 16.8, 17.2, 17.5
* −216: 6.9, 11.3, 12.9, 14.0, 14.8, 15.5, 16.0, 16.4, 16.8, 17.2, 17.5
* −231: 7.0, 11.4, 13.0, 14.1, 14.9, 15.6, 16.1, 16.6, 17.0, 17.3, 17.6
* −239: 7.0, 11.4, 13.1, 14.2, 15.0, 15.6, 16.2, 16.6, 17.0, 17.4, 17.7

**B2-diag (falsifiable cross-check with Tollis; diagnostic).** Sign changes of Z in (0, 92] = Tollis Nb ≤ 92 − 25 (main term + 7/8 in brackets):
−116: **119** (119.8), −135: **121** (122.0), −139: **121** (122.4), −140: **122** (122.5), −152: **123** (123.7), −172: **125** (125.6),
−175: **125** (125.8), −199: **127** (127.7), −200: **127** (127.8), −204: **127** (128.1), −211: **128** (128.6), −212: **127** (128.6),
−216: **128** (128.9), −231: **129** (129.9), −239: **129** (130.4). (Note −212 has Nb 152 < −211's 153 in Tollis's table; we predict his
value.) First sign change must match Tollis's First Zero column (table above) to within his 5-decimal truncation. Gap columns compared as a
further diagnostic.

**Prediction: all 180 runs (15 core windows + 165 chunks) closed, all replays pass plain + hardened, 15 unions over [0,110] with 0 gaps,
0 condition violations.** Falsifiers as in PREDICTIONS.md (any window not closed — reported with location and status, a result either way;
any replay failure, union gap, condition (1)–(4) violation; verify_cubic.py not VERIFIED). Count misses are reported but do not affect B1/B2.
Larger conductors (to 239) may make runs slower; timings are reported, nothing is changed to force closure.
