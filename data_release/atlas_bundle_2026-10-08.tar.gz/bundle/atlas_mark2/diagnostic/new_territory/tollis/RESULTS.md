# Tollis extension: GRH for ζ_K, six complex cubic fields — results (2026-10-08)

**Outcome: P1, P2 and P3 all MET.** 81/81 pre-registered runs closed. Every certificate passes the plain and hardened replay, run in a
fresh process. The exact unions have 0 gaps.
* Pre-registration: `PREDICTIONS.md`, sha256 43270ab5…058c (`PREDICTIONS.sha256`, still OK). It was written after the six validation
  windows and before any target run.
* Frozen code: `CODE_SHA256_FROZEN.txt`. Every file still matches except `diag_tollis.py`, a diagnostic only. After the freeze I added
  a gap range up to 95 to it. It plays no part in any certificate.
* Theory: `THEORY_TOLLIS.md`, written before coding.

## Claims

For K = Q(x)/(P) with d_K ∈ {−23, −31, −44, −59, −76, −83} (Tollis's polynomials):

1. **Every zero of L(s) = ζ_K(s)/ζ(s) with |Im s| ≤ 110 lies on Re s = 1/2 and is simple.** This was proved here from t = 0, without using
   Tollis. Simplicity rests on Lemma 2, as in deg2/ec389a.
2. With RH for ζ up to 3·10¹² (Platt–Trudgian), **GRH holds for ζ_K for |Im s| ≤ 110**. For d = −23 it holds for **|Im s| ≤ 200**.
3. Simplicity of ζ_K's zeros is not claimed. A zero of ζ could coincide with a zero of L.

| d_K | Tollis height (Table 6.2, p. 1318) | P1 window [H−2, H+10] | zeros (pred.) | new contiguous height (P2/P3) | gain over Tollis |
|---|---|---|---|---|---|
| −23 | 93.81 | [91.81, 103.81] 24/24 | 16 (16) | **200** | +106.2 |
| −31 | 94.11 | [92.11, 104.11] 24/24 | 17 (17) | **110** | +15.9 |
| −44 | 93.98 | [91.98, 103.98] 24/24 | 18 (18) | **110** | +16.0 |
| −59 | 93.78 | [91.78, 103.78] 24/24 | 19 (18) | **110** | +16.2 |
| −76 | 93.89 | [91.89, 103.89] 24/24 | 18 (19) | **110** | +16.1 |
| −83 | 93.73 | [91.73, 103.73] 24/24 | 19 (19) | **110** | +16.3 |

The minimum hardened margin over all target certificates is 1.797, against about 1.8–1.9 in deg2.

## Agreement with Tollis (diagnostic, `logs/diag_tollis_*.json`)

This is an independent reproduction of his whole row in Table 6.2 for each field.

| d_K | first zero (ours / Tollis) | L-zeros ≤ 92 (ours / Tollis Nb−25) | Least Gap | Least Gap* | Greatest Gap* |
|---|---|---|---|---|---|
| −23 | 5.115683 / 5.11568 | 96 / 96 | 0.04082 / 0.04081 | 0.25629 / 0.25629 | 2.04358 / 2.04357 |
| −31 | 4.166215 / 4.16621 | 100 / 100 | 0.00898 / 0.00897 | 0.28514 / 0.28513 | 2.75951 / 2.75950 |
| −44 | 4.041995 / 4.04199 | 105 / 105 | 0.00314 / 0.00313 | 0.17533 / 0.17532 | 1.77366 / 1.77366 |
| −59 | 3.431805 / 3.43180 | 109 / 109 | 0.02993 / 0.02993 | 0.09516 / 0.09515 | 2.21543 / 2.21542 |
| −76 | 3.276234 / 3.27623 | 113 / 113 | 0.02791 / 0.02791 | 0.13147 / 0.13147 | 1.92620 / 1.92620 |
| −83 | 2.916068 / 2.91606 | 114 / 114 | 0.04557 / 0.04557 | 0.11248 (at 97.088/97.200) / 0.11248 | 2.33788 / 2.33787 |

* The last-digit differences come from rounding: we use ζ zeros to 6 decimals, and Tollis truncates.
* **Pre-registered P2-diag met exactly for all six fields.** Our zero counts in (0, 92] equal Tollis's Nb ≤ 92 minus the 25 zeros of ζ.
* Nuance: several of Tollis's gap values come from zeros *above* his certified height. These are:
  * −31: an L zero at 94.660, next to the ζ zero 94.651;
  * −83: the pair 97.088/97.200.

  So his zero lists went past his "GRH Height". We reproduce those zeros too, and now certify them.
* d = −23 also agrees with the deg2 η-product run on [93.5, 104]: the same 14 zeros, to 4e−7, which is the 6-decimal rounding of that list.

## Coefficients

The rule is a_p = 2 / 0 / −1 for split / 1+2 / inert, and 1 or 0 at ramified primes of type 𝔭²𝔮 or 𝔭³. It is derived as
ζ_K's Euler factor divided by ζ's (THEORY §1).
* `verify_cubic.py` reports VERIFIED for all 10 tables (p ≤ 3·10⁶, 216 816 primes). It was run twice, in fresh processes, and takes
  about 19 s per field.
* Dedekind's criterion was checked at 2 for −44 and −76 (2 = 𝔭³ in both, so a_2 = 0). Every other core field has a squarefree disc(P) = d_K.
* Diagnostics, all exact, with 0 mismatches:
  * the weight-1 theta series ½(θ_{Q₀} − θ_{Q₁}) (h = 3) for n ≤ 20 000, for all 10 fields; the h = 6 formula was used for −87 and −104;
  * η(z)η(23z) for n ≤ 6000;
  * LMFDB traces a_1…a_30 for 31.1.b.a, 44.1.d.a, 59.1.b.a, 76.1.c.a and 83.1.b.a. All have analytic rank 0; the Artin fields are
    3.1.|d|.1. These came through a summarising web fetch, because curl gets a captcha (`diagnostics/lmfdb_mf_webfetch.json`).

## Checks on every certificate

* **Replay**, in a fresh process:
  * rows recomputed with ×1.5 prime cut-offs, 24 nodes and h = 0.4;
  * far allowances and N_win recomputed;
  * every sign-change endpoint re-verified with the A = 1.2 series, overlapping A = 1 as complex balls;
  * `replay_verify.py` run plain and hardened with expect_m0 = 0.
* **Tiling:** exact Fractions per run. `union.py` gives [0,110] for each field (220 cells, one table sha, one replay_verify sha per field)
  and [0,200] for −23 (400 cells).
* **`lean_gap_check.py`:** 1784 certificate files (1764 real) and 47 744 intervals. **0 violations** of conditions (1)–(4)
  (d_range [0, 1/2], cell ⊂ window, intervals ⊂ window, no central reduction).

## Negative controls (validation windows [0,10]; `negctl.sh`, `runs/nc/`)

| control | result |
|---|---|
| fake sign change (5.5, 5.6) injected into the generator | 20/20 INCONSISTENT, 0 certified |
| the same interval forged into all real certificates | replay 20/20 NO_SIGN_CHANGE |
| a_2 + 1 (−31): replay rows + Z / rows only / generator | 20/20 series mismatch / 20/20 INCONSISTENT / 0/20 (INCONSISTENT) |
| **wrong splitting rule "abelian"** (a_p = 1 + χ(p), i.e. ρ → 1 ⊕ χ_d): replay / generator | 20/20 series mismatch / 0/20 |
| **wrong rule "swap"** (split ↔ inert): replay / generator | 20/20 series mismatch / 0/20 |
| wrong conductor N = 30, 32 (−31) | 20/20 series mismatch each |
| −44 with N = 11 (resolvent-field discriminant) | 20/20 series mismatch |
| −44 with a_2 = 1 (2 treated as 𝔭²𝔮 instead of 𝔭³) | 20/20 series mismatch |
| root number ε = −1 | 20/20 series mismatch |
| one corrupted table entry (p = 1009) | verify_cubic FAILED, and forms refuses to load it (sha) |

"Series mismatch" means that the A = 1 and A = 1.2 evaluations of Λ disagree, so the functional-equation data is wrong. The replay
reports it as status NO_SIGN_CHANGE, with the detail "series mismatch". The same limits as in deg2 apply: a too-large N with only the
rows corrupted, or an a_p change at a very large p, would not be caught. Both are sound anyway.

## Timings and resources (all nice −n 19, one heavy process at a time)

* 81 target runs: generator 121 min and replay 75 min in total.
  * A core window takes about 1.7–2.2 min to generate and 0.9 min to replay.
  * A K23 chunk at 190–200 takes 2.7 min to generate.
* Validation took 6 × 2.3 min, the negative controls about 15 min, and the table build plus verification about 1 s + 19 s per field.
* Peak memory was 499 MB for the generator and 195 MB for the replay. The runs take 17 MB of disk.

## Proved vs trusted

**Proved here**, given Arb/FLINT:
* the type tables, by a pure-Python proof;
* the Euler factors;
* Lemma T, the explicit formula, the quadrature bound, the prime truncation, Lemma N, the far allowances and the certificate algebra (D§9);
* Lemma 2, carried over.

**Trusted:**
* python-flint 0.9.0;
* the Dedekind–Kummer theorem and Dedekind's index criterion;
* Hecke's FE for ζ_K and Riemann's for ζ (these give N = |d_K|, Γ_C and ε = +1; the A-split also checks them numerically);
* Aramata–Brauer, i.e. L entire;
* Mellin inversion and Phragmén–Lindelöf for the theta relation;
* Rosser–Schoenfeld; Trefethen's Gauss–Legendre bound; Iwaniec–Kowalski Thm 5.6 (Lorentzian rows);
* for ζ_K, Platt–Trudgian.

HiGHS and the generator are untrusted. LMFDB, the theta series and Tollis's columns are diagnostics only.

## Novelty status (moderate confidence; basis ../PRIOR_VERIFICATION.md plus web searches on 2026-10-08)

* Tollis 1997 is still the latest published GRH verification for these fields. 2025 papers (Das–Gaba–Lee–Savalia–Wong
  arXiv:2506.19319; Das–Kadiri–Ng arXiv:2508.09480) cite him as the state of the art ("|t| ≤ 92 … d_L ≤ 239").
* Fresh searches found no later height for any complex cubic ζ_K. Booker 2006 covers S5/A5 fields, and Hiary–Ireland–Kyi do not treat
  number fields.
* The CMF/LMFDB "RH to height b" check covers these weight-1 forms, but b is unpublished. Platt's code implies about 32.
* **So, to our knowledge, GRH for ζ_K beyond Tollis's ~94 is new for all six fields: up to 110, and up to 200 for d = −23.**
  This rests on a literature search, not a guarantee. Platt, Booker, Costa, Kadiri and E. S. Lee are best placed to confirm.
* This is the first verification independent of Tollis on [0, ~94]. It also confirms his tables exactly.

## Not done / scope

* **Totally real fields (Table 6.1).**
  * The cyclic fields (49, 81, 169, 361, 961) reduce to cubic Dirichlet L-functions. These are already covered far beyond 94 by Platt
    (Math. Comp. 85 (2016): all primitive characters with q ≤ 400 000 to height at least 10⁸/q). Nothing new is to be had there.
  * The non-Galois totally real fields (148, 229, …) need a Γ_R(s)² (Maass) Λ-evaluator. That is not available in Arb, so they were not
    attempted (THEORY §7).
* The extras −87, −104, −107 and −108 have verified tables and pass the theta check. They were not run: they were optional in the plan.
  Each would take about 3 min for [H−2, H+10], or about 25 min for [0, 110].

---

## ADDENDUM (2026-10-08): the four remaining complex cubic fields, d_K = −87, −104, −107, −108

*Appended section; everything above is unchanged.* Pre-registration: `PREDICTIONS_ADDENDUM.md`, sha256 c5da9feb…4ab0a
(`PREDICTIONS_ADDENDUM.sha256`, still OK), written before any run of these fields. Plan: `PLAN_ADDENDUM.txt` (sha256 19ed1f93…7909).
Code: `CODE_SHA256_FROZEN.txt` checked before and after the runs. Every entry OK except `diag_tollis.py` (the diagnostic-only edit already
disclosed above; unchanged during this addendum, sha256 abff6d0c…89ee). Type tables: sha-checked at load by forms.py.

**Outcome: A1 and A2 MET for all four fields.** 48/48 pre-registered runs closed (4 core windows + 44 chunks). 1104/1104 certificates pass
the plain and hardened replay, run in a fresh process. Exact unions over [0, 110] have 0 gaps (220 cells per field, one table sha and one
replay_verify sha per field). The core windows also tile exactly (`logs/union_K*_core.json`, bounds passed as the exact rationals of the
stored floats).

| d_K | Tollis height | A1 window [H−2, H+10] | zeros (pred.) | min margin core | new contiguous height | zeros in [0,110] | min margin [0,110] | gain |
|---|---|---|---|---|---|---|---|---|
| −87 | 93.38 | [91.38, 103.38] 24/24 | 19 (19) | 1.802 | **110** | 143 | 1.798 | +16.6 |
| −104 | 93.06 | [91.06, 103.06] 24/24 | 19 (19) | 1.865 | **110** | 147 | 1.796 | +16.9 |
| −107 | 93.34 | [91.34, 103.34] 24/24 | 20 (19) | 1.866 | **110** | 147 | 1.795 | +16.7 |
| −108 | 94.26 | [92.26, 104.26] 24/24 | 20 (19) | 1.803 | **110** | 147 | 1.797 | +15.7 |

Claims (same form and caveats as above): every zero of L = ζ_K/ζ with |Im s| ≤ 110 is on the critical line and simple; with Platt–Trudgian,
**GRH for ζ_K holds for |Im s| ≤ 110** for d_K = −87, −104, −107, −108, independently of Tollis. Simplicity of ζ_K's zeros is not claimed
(see −87 below).

Per-chunk counts [0,10] … [100,110] (all within the pre-registered ±2 of the main term):
* −87: 6, 10, 11, 12, 14, 13, 15, 15, 15, 16, 16
* −104: 5, 11, 12, 13, 13, 15, 14, 16, 15, 16, 17
* −107: 5, 11, 12, 13, 13, 14, 16, 15, 15, 16, 17
* −108: 6, 10, 12, 13, 13, 15, 14, 16, 15, 17, 16

**Agreement with Tollis (diagnostic, `logs/diag_tollis_K{87,104,107,108}.json`).** A2-diag met exactly for all four fields.

| d_K | first zero (ours / Tollis) | L-zeros ≤ 92 (ours / Tollis Nb−25) | Least Gap (ours, ≤ 92) | Least Gap* | Greatest Gap* |
|---|---|---|---|---|---|
| −87 | 2.683686 / 2.68368 | 115 / 115 | 0.00009 (Tollis 0.00008) | 0.17800 | 2.29417 |
| −104 | 3.319911 / 3.31991 | 117 / 117 | 0.03119 | 0.10894 | 1.90971 |
| −107 | 2.616080 / 2.61608 | 118 / 118 | 0.06723 | 0.15956 | 2.30194 |
| −108 | 2.821614 / 2.82161 | 118 / 118 | 0.02492 | 0.19569 | 1.71851 |

* Our gap columns for −104, −107 and −108 were not compared digit by digit with Tollis's table in this pass; only his −87 Least Gap is
  recorded in THEORY_TOLLIS.md. The values agree with ≤ 95 as well, so the gaps were not cut by the 92 limit.
* −87: the least gap 0.00009 is the ζ/L near-coincidence that Tollis reports as 0.00008. Our ζ zeros are given to 6 decimals and his are
  truncated, so this agrees to within rounding. It is the reason simplicity of ζ_K's zeros is not claimed.

**Lean-flagged conditions.** `lean_gap_check.py` over the whole tree (`logs/lean_gap_check_addendum.json`; the earlier
`logs/lean_gap_check.json` was not touched): 2760 certificate files (2740 real), 77 060 intervals, 0 central certificates, **0 violations**
of conditions (1)–(4), including the 1104 new certificates.

**Resources.** nice −n 19, one heavy process at a time, 06:23–08:32 (2 h 09 min). A core window took 1.7–3.1 min to generate and
about 1 min to replay; a chunk took 1.1–3.0 min to generate and 0.8–1.1 min to replay. Peak memory was 493 MB for the generator and
195 MB for the replay. The per-run lines were appended to `runs/SUMMARY.log` by run_targets.sh, as for the original 81 runs.

**Updated scope.** All ten complex cubic fields of Tollis's Table 6.2 are now verified to |Im s| ≤ 110, and −23 to 200. Totally real
fields: unchanged (see "Not done / scope").

## Correction (2026-10-08, appended by the main session)
ADDENDUM certificate count: the four addendum fields have 4 × (24 core + 220 contig) = **976** certificates on disk (verified by
file count, and consistent with lean_gap_check totals 2740 − 1764), not "1104" as stated above. All 976 pass replay. The earlier
sentence in this file that −87/−104/−107/−108 "were not run" is superseded by the ADDENDUM.

---

## ADDENDUM 2 (2026-10-08): the 15 remaining complex cubic fields of Table 6.2, d_K = −116 … −239

*Appended section. Everything above is unchanged.*

**Outcome: B1 and B2 MET for all 15 fields.**
* 180/180 pre-registered runs closed: 15 core windows and 165 chunks.
* 3660/3660 certificates pass the plain and hardened replay, run in a fresh process.
* Each per-run replay tiles with 0 gaps. The exact unions over [0, 110] have 0 gaps for every field: 220 cells per field, one table sha
  and one replay_verify sha per field. The 15 core windows also tile exactly (`logs/union_K*_core.json`).
* No run failed to close anywhere.

**Pre-registration.** `PREDICTIONS_ADDENDUM2.md`, sha256 90cb62e3…0ee2 (`PREDICTIONS_ADDENDUM2.sha256`, still OK). It was written before
any run of these fields. Plan: `PLAN_ADDENDUM2.txt`.

**Code.**
* `CODE_SHA256_FROZEN.txt` was checked before and after (`logs/code_sha_check_addendum2_{before,after}.txt`). Every entry is OK except
  `diag_tollis.py`, the diagnostic-only edit already disclosed (unchanged, abff6d0c…89ee).
* **Disclosure.** The frozen field registry (cubic.FIELDS, TYPES_SHA256.json) lists only the first 10 fields. The 15 new fields are
  registered at run time, in memory, by two new data-only files, so no frozen file was touched:
  * `fields_ext2.py` adds the entries and refuses to overwrite any existing one. It points forms.SHA_FILE at
    `TYPES_SHA256_ADDENDUM2.json`, which holds the 10 frozen entries verbatim (checked at load) plus the 15 new ones.
  * `run_ext2.py` runs the frozen gen_cert.py / replay_deg2.py / verify_cubic.py / diag_*.py unchanged via runpy.
* `run_targets_ext2.sh` and `post_field_ext2.sh` are copies of the frozen scripts with that launcher inserted. The runner also gained a
  < 2 GB free-disk stop.
* Regression check of the launcher, done before the pre-registration: K23 [0, 10] regenerated through run_ext2.py gives certificates
  **field-for-field identical** to the frozen runs/contig/K23/c_0_10.
* The new files' shas are in `logs/ext2_files_sha_before.txt` and were still OK after the runs.

**Coefficients and index check, per field.**
* For all 15 of Tollis's polynomials, disc(P) = D_K exactly.
* Wherever p² | disc(P), Dedekind's criterion holds exactly:
  * at 2 for −116, −140, −152, −172, −200, −204, −212, −216;
  * at 3 for −135, −216;
  * at 5 for −175, −200.
* So Z[α] = O_K and Dedekind–Kummer applies at every p. No non-maximal-order correction was needed. The polynomial, primes and splitting
  types per field are in the table in `PREDICTIONS_ADDENDUM2.md`.
* `verify_cubic.py` reports **VERIFIED** for all 15 tables (p ≤ 3·10⁶, 216 816 primes, about 19 s per field). It was run three times in
  fresh processes, twice before the runs and once after, with identical shas (`logs/types_verify_addendum2_{run1,run2,after}.out`).

**Diagnostics on the coefficients** (all exact, 0 mismatches):
* Theta series (n ≤ 20 000) over the form class group of discriminant d_K.
  * New `diag_theta2.py`: Gauss composition, ker ψ = cubes, index 3 checked. It covers all 15 fields, including h = 9, 12, 15 for
    −199, −231, −239 (3-rank 1 in every case).
  * The frozen `diag_theta.py` independently covers the 12 fields with h ∈ {3, 6}.
* **LMFDB raw a_p** for the first 303 primes (p ≤ 1999), from the LMFDB `download_qexp` files. These are the raw Sage files, not
  summaries, stored under `diagnostics/lmfdb_qexp_addendum2/`. They agree with our tables at every prime, for all 15 newforms:
  116.1.d.b, 135.1.d.a, 139.1.b.a, 140.1.h.a, 152.1.g.b, 172.1.b.a, 175.1.d.a, 199.1.b.a, 200.1.g.b, 204.1.g.b, 211.1.b.a, 212.1.d.b,
  216.1.h.b, 231.1.h.b, 239.1.b.a (`diag_lmfdb_qexp_ext2.py`, `logs/lmfdb_qexp_compare_addendum2.json`).
  * Each Artin field is 3.1.|d|.1.
  * Where the Artin page was read (172, 175, 200, 204, 212, 216, 231), the root number is 1 and the listed Artin polynomial defines the
    same field.
  * These were fetched after the pre-registration, during the runs. They are diagnostics only.
  * One HTML-page summary misreported a_25 (= 0 here and in the raw file). Only the raw files were used.

**Results** (core window = [H − 2, H + 10]; predictions from the main term, ±2):

| d_K | P(x) | Tollis H | core: zeros (pred.), min margin | new contiguous height | zeros in [0,110] | min margin [0,110] | gain |
|---|---|---|---|---|---|---|---|
| −116 | x³ − x² − 2 | 93.73 | 20 (20), 1.802 | **110** | 149 | 1.797 | +16.3 |
| −135 | x³ + 3x − 1 | 93.12 | 20 (20), 1.867 | **110** | 151 | 1.797 | +16.9 |
| −139 | x³ + x² + x − 2 | 93.40 | 19 (20), 1.801 | **110** | 152 | 1.798 | +16.6 |
| −140 | x³ + 2x − 2 | 93.35 | 21 (20), 1.802 | **110** | 152 | 1.798 | +16.7 |
| −152 | x³ − x² − 2x − 2 | 94.20 | 21 (20), 1.800 | **110** | 153 | 1.797 | +15.8 |
| −172 | x³ + x² − x − 3 | 93.79 | 20 (20), 1.791 | **110** | 155 | 1.797 | +16.2 |
| −175 | x³ − x² + 2x − 3 | 93.20 | 21 (20), 1.801 | **110** | 156 | 1.797 | +16.8 |
| −199 | x³ − x² + 4x − 1 | 92.30 | 21 (21), 1.802 | **110** | 158 | 1.797 | +17.7 |
| −200 | x³ + x² + 2x − 2 | 93.67 | 21 (21), 1.801 | **110** | 158 | 1.798 | +16.3 |
| −204 | x³ − x² + x − 3 | 93.07 | 20 (21), 1.800 | **110** | 158 | 1.798 | +16.9 |
| −211 | x³ − 2x − 3 | 92.83 | 21 (21), 1.865 | **110** | 158 | 1.797 | +17.2 |
| −212 | x³ − x² + 4x − 2 | 93.27 | 21 (21), 1.865 | **110** | 159 | 1.795 | +16.7 |
| −216 | x³ + 3x − 2 | 94.07 | 21 (21), 1.800 | **110** | 159 | 1.795 | +15.9 |
| −231 | x³ + x² − 3 | 93.14 | 21 (21), 1.801 | **110** | 161 | 1.796 | +16.9 |
| −239 | x³ − x − 3 | 93.83 | 20 (21), 1.802 | **110** | 161 | 1.794 | +16.2 |

* Every chunk count is within the pre-registered ±2 of the main term; the largest deviation is 1.2. Per-chunk counts are in
  `logs/union_K*_0_110.json`.
* The minimum hardened margin over all 3660 new certificates is 1.791 (the −172 core window). It does not drift down with conductor.

**Claims** (same form and caveats as above):
* For d_K ∈ {−116, −135, −139, −140, −152, −172, −175, −199, −200, −204, −211, −212, −216, −231, −239}, every zero of L = ζ_K/ζ with
  |Im s| ≤ 110 lies on the critical line and is simple.
* With Platt–Trudgian, **GRH for ζ_K holds for |Im s| ≤ 110**. This is independent of Tollis.
* Simplicity of ζ_K's zeros is not claimed. Several fields have ζ/L near-coincidences down to 0.0005 (−135).

**Agreement with Tollis's row** (diagnostic, `logs/diag_tollis_K*.json`, `logs/tollis_compare_addendum2.json`; gaps taken over zeros
≤ his height H):

| d_K | first zero (ours / Tollis) | L-zeros ≤ 92 (ours / Nb−25) | Least Gap | Greatest Gap | Least Gap* | Greatest Gap* |
|---|---|---|---|---|---|---|
| −116 | 3.115683 / 3.11568 | 119 / 119 | 0.01069 / 0.01069 | 2.11816 / 2.11816 | 0.06694 / 0.06693 | 2.11816 / 2.11816 |
| −135 | 2.040286 / 2.04028 | 121 / 121 | 0.00050 / 0.00050 | 2.36295 / 2.36295 | 0.08348 / 0.08348 | 2.36295 / 2.36295 |
| −139 | 2.661798 / 2.66179 | 121 / 121 | 0.00171 / 0.00171 | 1.90768 / 1.90768 | 0.12775 / 0.12775 | 1.90768 / 1.90768 |
| −140 | 2.277904 / 2.27790 | 122 / 122 | 0.02047 / 0.02046 | 2.59247 / 2.59247 | 0.19018 / **0.05948** (see below) | 2.59247 / 2.59247 |
| −152 | 2.811961 / 2.81196 | 123 / 123 | 0.00546 / 0.00546 | 1.91306 / 1.91305 | 0.17549 / 0.17549 | 1.91306 / 1.91305 |
| −172 | 2.356709 / 2.35670 | 125 / 125 | 0.00617 / 0.00616 | 1.84139 / 1.84139 | 0.13394 / 0.13394 | 1.84139 / 1.84139 |
| −175 | 1.810804 / 1.81080 | 125 / 125 | 0.02071 / 0.02071 | 2.39881 / 2.39880 | 0.18227 / 0.18226 | 2.39881 / 2.39880 |
| −199 | 1.671613 / 1.67161 | 127 / 127 | 0.01449 / 0.01448 | 2.62086 / 2.62086 | 0.19531 / 0.19531 | 2.62086 / 2.62086 |
| −200 | 2.522349 / 2.52234 | 127 / 127 | 0.01053 / 0.01052 | 1.78618 / 1.78618 | 0.11448 / 0.11447 | 1.78618 / 1.78618 |
| −204 | 2.512567 / 2.51256 | 127 / 127 | 0.00346 / 0.00346 | 1.84823 / 1.84822 | 0.08541 / 0.08541 | 1.84823 / 1.84822 |
| −211 | 2.299067 / 2.29906 | 128 / 128 | 0.01657 / 0.01656 | 1.68545 / 1.68544 | 0.12543 / 0.12543 | 1.68545 / 1.68544 |
| −212 | 2.465409 / 2.46540 | 127 / 127 | 0.02509 / 0.02508 | 1.79747 / 1.79746 | 0.10592 / 0.10591 | 1.79747 / 1.79746 |
| −216 | 2.796566 / 2.79656 | 128 / 128 | 0.00313 / 0.00312 | 1.62193 / 1.62192 | 0.06707 / 0.06707 | 1.62193 / 1.62192 |
| −231 | 1.844816 / 1.84481 | 129 / 129 | 0.00524 / 0.00523 | 2.34090 / 2.34089 | 0.12323 / 0.12322 | 2.34090 / 2.34089 |
| −239 | 2.127218 / 2.12721 | 129 / 129 | 0.01478 / 0.01478 | 2.69767 / 2.69767 | 0.15970 / 0.15969 | 2.69767 / 2.69767 |

* **B2-diag met exactly for all 15 fields.** Our zero counts in (0, 92] equal Tollis's Nb ≤ 92 minus 25. This includes −212, whose Nb
  (152) is below −211's (153) and 1.6 below the main term.
* Every first zero agrees to within his 5-decimal truncation.
* 59 of the 60 gap entries agree to ≤ 1e−5 (rounding and truncation, as above).
* **The one difference, −140 Least Gap\*.** Tollis's 0.05948 is the pair of L zeros at **97.603209 / 97.662692** (gap 0.059483), which
  lies *above* his certified height 93.35. Below 93.35 our least Gap* is 0.19018 (78.665 / 78.855). This is the same situation as −31 and
  −83 above: his zero lists went past his "GRH Height". We reproduce that pair, and it is now certified.
* For several fields (e.g. −116), his Least Gap comes from zeros in (92, H]. It matches ours only when computed up to H, not 92.

**Lean-flagged conditions.** `lean_gap_check.py` over the whole tree (`logs/lean_gap_check_addendum2.json`; earlier logs untouched):
* 6420 certificate files (6400 real, 3660 of them new) and 194 672 intervals;
* 0 central certificates;
* **0 violations** of conditions (1)–(4).

**Resources and timings.** All runs used nice −n 19 with one heavy process at a time. They ran from 10:03 to 19:02, 9.0 h of wall time.

| | generator | replay |
|---|---|---|
| total | 358 min | 180 min |
| core window | 2.0–4.4 min | ~1 min |
| per chunk | 1.2–4.8 min | 0.8–1.2 min |
| peak memory | 498 MB | 195 MB |

* Cost grows with height and somewhat with conductor. The slowest run was the −231 chunk [100, 110] at 288 s to generate; the [100, 110]
  chunks took 114–288 s, against about 80–90 s for −108. Nothing slowed down enough to matter.
* The runs take 37 MB of disk (runs/ is now 64 MB in total); 11 GB is still free.
* Per-run lines are in `runs/SUMMARY_ADDENDUM2.log`, which records end times; the original `runs/SUMMARY.log` is untouched.

**Updated scope.** **All 25 complex cubic fields of Tollis's Table 6.2 (d_K = −23 … −239) are now verified to |Im s| ≤ 110**, and
−23 to 200. Every one is independent of Tollis on [0, ~94], and every one reproduces his row. Totally real fields: unchanged (see "Not done
/ scope"). The novelty caveat is the same as above: it rests on a literature search, not a guarantee.
