# Atlas degree-2 pipeline for ζ_K / ζ, K a complex cubic field: theory (written before coding, 2026-10-08)

Goal: extend Tollis (Math. Comp. 66 (1997) 1295–1321, Table 6.2, p. 1318) for the complex cubic fields of smallest |d_K|.
Everything not stated here is inherited unchanged from `../deg2/THEORY_DEG2.md` (D§n) and `../ec389a/THEORY_389A.md` (E§n);
the code is a copy of the frozen ec389a pipeline with the form data replaced (and the 389-specific central machinery removed).

## 0. Fields (Tollis Table 6.2, signature (1,1); his polynomial P, his "GRH Height", his first zero)

| d_K | P(x) (Tollis) | Tollis height | Tollis first zero | Nb ≤ 92 (ζ_K) | disc(P) | 2-part / index check |
|---|---|---|---|---|---|---|
| −23 | x³ + x² − 1 | 93.81 | 5.11568 | 121 | −23 | squarefree ⇒ index 1 |
| −31 | x³ − x² − 1 | 94.11 | 4.16621 | 125 | −31 | squarefree ⇒ index 1 |
| −44 | x³ − x² − x − 1 | 93.98 | 4.04199 | 130 | −44 | Dedekind criterion at 2 |
| −59 | x³ + 2x − 1 | 93.78 | 3.43180 | 134 | −59 | squarefree ⇒ index 1 |
| −76 | x³ − 2x − 2 | 93.89 | 3.27623 | 138 | −76 | Dedekind criterion at 2 |
| −83 | x³ − x² + x − 2 | 93.73 | 2.91606 | 139 | −83 | squarefree ⇒ index 1 |

(Optional extras, same table: −87 (x³+x²+2x−1, 93.38), −104 (x³−x−2, 93.06), −107 (x³−x²+3x−2, 93.34), −108 (x³−2, 94.26).)
The abstract and §5 say "height 92"; Table 6.2 gives the per-field heights above. We cite both.

## 1. The L-function: L(s) := ζ_K(s)/ζ(s), defined from K alone

For a cubic field K, define L(s) = ζ_K(s)/ζ(s). This is the Artin L-function L(s, ρ) of the 2-dimensional irreducible
representation ρ of Gal(K̃/Q) ≅ S_3 (K non-Galois; ζ_K = L(s,1)L(s,ρ) because Ind_{S_2}^{S_3} 1 = 1 ⊕ ρ).
We never need to *identify* a modular form to run the pipeline; the identification with a weight-1 newform is a diagnostic (§6).

**Euler product (exact local factors).** For every prime p, with p O_K = Π 𝔭_i^{e_i}, f_i = f(𝔭_i|p):

    L_p(s)^{-1} = Π_i (1 − p^{−f_i s}) / (1 − p^{−s}),        x := p^{−s}.

| decomposition of p in K | Π(1−x^{f_i})/(1−x) | a_p | χ(p) | type |
|---|---|---|---|---|
| 𝔭₁𝔭₂𝔭₃ (f = 1,1,1) | (1−x)² | **2** | +1 | good, split completely |
| 𝔭₁𝔭₂ (f = 1, 2) | 1 − x² | **0** | −1 | good |
| 𝔭 (f = 3), inert | 1 + x + x² | **−1** | +1 | good |
| 𝔭₁²𝔭₂ (f = 1, 1) | 1 − x | **1** | 0 | ramified, conductor exponent 1 |
| 𝔭³ (f = 1) | 1 | **0** | 0 | totally ramified, conductor exponent ≥ 2 |

So L_p(s)^{-1} = 1 − a_p x + χ(p) x² with χ(p) = (d_K/p) for p ∤ d_K (Stickelberger: (d_K/p) = (−1)^{3 − #factors}),
and a_p ∈ {1, 0} at the ramified primes. This is the rule asked for (2 / 0 / −1) together with the ramified cases;
it is **derived**, not assumed: it is just ζ_K's Euler factor divided by ζ's.

**Computing the decomposition (Dedekind–Kummer).** K = Q[x]/(P). For p ∤ [O_K : Z[α]], the factorization of P mod p,
P ≡ Π g_i^{e_i}, gives p O_K = Π 𝔭_i^{e_i} with f_i = deg g_i. For each of the six fields disc(P) = d_K exactly (computed above),
so the index is 1 and Dedekind–Kummer applies at **every** p. Index 1 is proved as follows: if disc(P) is squarefree (up to sign) the index,
whose square divides disc(P), is 1; for −44 and −76 (4 ∥ disc) we verify **Dedekind's criterion** at p = 2 exactly: with
P ≡ Π ḡ_i^{e_i} mod p, g = Π g_i, h = Π g_i^{e_i−1} (monic lifts), F = (g h − P)/p, p ∤ index ⇔ gcd(F̄, ḡ, h̄) = 1 in F_p[x].
(An independent sanity argument: index 2 would give a cubic field of discriminant −11 or −19, and none exists, |d| ≥ 23.)
For p ∤ d_K, P is separable mod p and the type is fixed by r = #roots of P in F_p: r = 3 → (1,1,1), r = 1 → (1,2), r = 0 → (3).
r = deg gcd(x^p − x, P) mod p.

**Analytic properties (trusted classical facts).**
* L(s) is entire: Aramata–Brauer (ζ_K/ζ is entire for every number field K); equivalently ρ = Ind_{Q(√d_K)}^{Q} ψ for a ring-class
  character ψ of order 3, so L(s) = L(s, ψ) is a Hecke L-function, entire because ψ ≠ 1.
* Functional equation, derived from Hecke's FE for ζ_K and Riemann's for ζ (signature (1,1): Γ-factor Γ_R(s)Γ_C(s) for ζ_K, Γ_R(s)
  for ζ; both completed functions are invariant under s ↦ 1 − s, root number 1):
      Λ_K(s) = |d_K|^{s/2} Γ_R(s) Γ_C(s) ζ_K(s),  ξ(s) = Γ_R(s) ζ(s),  Γ_C(s) = 2(2π)^{−s}Γ(s)
  ⇒  **Λ(s) := (√|d_K| / 2π)^s Γ(s) L(s) = Λ(1 − s)**: conductor N = |d_K|, Γ_C, weight k = 1, **root number ε = +1 (a theorem, no lookup)**.
  This is exactly the deg2 normalization with k = 1 (D§0), as for 23.1.b.a; the arithmetic and analytic normalizations coincide (center 1/2).
* Coefficients are real (a_p, χ(p) ∈ Z), so the zero set is symmetric under ρ ↦ ρ̄, 1 − ρ̄ (D§0 atoms unchanged); Z(t) = e^{πt/2}Λ(1/2+it) is
  real (D§1).
* Λ is of finite order and bounded in vertical strips away from the poles of Γ, so Mellin inversion of the FE gives
  θ(1/y) = y θ(y), θ(y) = Σ a_n e^{−2πny/√N}, which is all Lemma T's series (D§1) uses. (Equivalently θ(y) = f(iy/√N) for the weight-1
  newform f with L(s,f) = L(s), Fricke eigenvalue +1 — Hecke/Weil–Langlands for dihedral forms; not needed.)
* |a_n| ≤ d(n) (a_{p^m} = Σ α^iβ^{m−i}, |α|,|β| ≤ 1) ≤ 2√n = 2n^{k/2}: Lemma T's coefficient bound holds; |c(n)| ≤ 2Λ(n) for −L'/L
  (good p: c(p^m) = (α^m+β^m) log p; ramified: c(p^m) = a_p^m log p with a_p ∈ {0, 1}).

**Consequence for ζ_K.** ζ_K = ζ·L with both factors entire apart from ζ's pole at 1, so the multiset of nontrivial zeros of ζ_K is
that of ζ plus that of L. With RH for ζ up to 3·10¹²
(Platt–Trudgian, trusted), a certificate "every zero of L with ordinate in [a, b] is on the line" gives GRH for ζ_K on [a, b].
Simplicity of ζ_K's zeros is **not** claimed (a ζ zero could coincide with an L zero; Tollis's "Least Gap" 0.00008 for −87 is
exactly such a near-coincidence between a ζ zero and an L zero).

## 2. What is new vs 23.1.b.a (deg2)

1. The a_n come from the cubic polynomial (Dedekind–Kummer, §1), not from an η-product. For −23 the two must agree
   (η(z)η(23z) = the weight-1 form of K); this is checked exactly for n ≤ 6000 (diagnostic + regression test).
2. Two fields (−44, −76) have **non-fundamental** discriminant: d_K = d₀ f² with d₀ = −11, −19, f = 2. At p = 2: 2O_K = 𝔭³ (a_2 = 0,
   conductor exponent 2, local factor 1); the quadratic character χ(p) = (d_K/p) has conductor |d₀| but the Artin conductor is |d_K|.
   Nothing in the pipeline depends on fundamentality: N = |d_K| enters only through the FE, which §1 derives for every complex cubic.
   The A-split replay check (D§1) tests N, ε and a_n together, so a wrong a_2 or N = 11/19 is caught (negative control).
3. Larger conductors (up to 83 vs 23): ~ (1/π) log(√N t/2πe) more zeros per unit (≈ 1.6 vs 1.4 at t ≈ 100); prime cut-offs and the
   row machinery are unchanged (the sech prime-side truncation is conductor-independent; the constant term (1/2a)log(N/4π²) grows slightly).
4. No central-zero machinery: the targets avoid t = 0. Validation windows containing 0 use **no** reduction (m0 = 0, which is always sound);
   if L(1/2) were 0, the central cell would simply fail to certify. The verifiers' central policy is pinned to expect_m0 = 0.

## 3. Weight-1 newform (diagnostic identification)

For h(d_K) = 3 (all six fields: h(−23) = h(−31) = h(−44) = h(−59) = h(−76) = h(−83) = 3), the ring class group of the order of
discriminant d_K is cyclic of order 3 and the newform is
    f = ½(θ_{Q₀} − θ_{Q₁}),    θ_Q = Σ_{x,y ∈ Z} q^{Q(x,y)},
Q₀ the principal form and Q₁ either non-principal reduced form of discriminant d_K (θ_{Q₁} = θ_{Q₁⁻¹}). Its level is |d_K| and its nebentypus
is the Kronecker character (d_K/·) (odd, as weight 1 requires). We compare these theta coefficients with the Dedekind–Kummer a_n for all
n ≤ 20 000 (exact integers) and, when reachable, with LMFDB (labels expected of the form |d|.1.<char>.a; root number +1; analytic rank 0;
listed low zeros vs our sign changes). Tollis's "First Zero" column is a second, independent diagnostic: our first sign change of Z must
match it (ζ has no zero below 14.13, so ζ_K's first zero is L's).

## 4. Pipeline (unchanged from ec389a/deg2 except form data)

Lemma T series with A = 1 and the A = 1.2 split in the replay; sech rows a ∈ {0.8, 1, 1.25} (P = 3e5, 1e6, 2e6; replay ×1.5) and Lorentzian
ε = 1.5 rows; Lemma N with N = |d_K|; far allowances; Lemma 1 sign changes (step 0.02, bisect to 1e−9); LP (untrusted HiGHS) + Arb
verifier; independent replay (fresh process) plain + hardened; exact Fraction tiling; union across chunks.

## 5. Conditions enforced on every certificate (Lean-surfaced, formal/README findings 1–3, plus central)

(1) (C) on the closed box with d0 = 0 (d_range = [0, 1/2]); (2) cell ⊂ window; (3) every interval ⊂ window, t1 < t2, sorted, disjoint;
(4) no central reduction recorded on any certificate (m0 = 0). Enforced in `replay_verify.py`/`verify_deg2.py`; re-checked in exact rationals
on the stored JSON by `lean_gap_check.py`.

## 6. Rigor ledger

**Proved here** (given Arb/FLINT): the a_p table for p ≤ 3·10⁶ (`verify_cubic.py`: pure-Python root counts via x^p mod P and gcd,
brute-force double check for p < 20 000, Stickelberger consistency, multiplicity analysis + Dedekind's criterion at ramified primes);
the Euler factors (§1, elementary); everything in D§9 (Lemma T, explicit formula, quadrature bound, prime truncation, Lemma N, far
allowances, certificate algebra; Lemma 2 carried over).
**Trusted:** Arb/FLINT (python-flint 0.9.0); Dedekind–Kummer theorem and Dedekind's index criterion; Stickelberger (used only as a
consistency check); Hecke's FE for ζ_K and Riemann's for ζ; Aramata–Brauer (or Hecke L-function entire-ness); Phragmén–Lindelöf / Mellin
inversion for the theta relation; Rosser–Schoenfeld; Trefethen's Gauss–Legendre bound; Iwaniec–Kowalski Thm 5.6 (Lorentzian rows);
for ζ_K: RH for ζ to 3·10¹² (Platt–Trudgian). HiGHS and the generator untrusted. LMFDB, theta series and Tollis's columns: diagnostics only.

## 7. Totally real cubic fields (Tollis Table 6.1): scope note

* Cyclic fields (d = 49, 81, 169, 361, 961) are abelian: ζ_K = ζ·L(s,χ)L(s,χ̄) with χ a cubic Dirichlet character of conductor 7, 9, 13,
  19, 31. GRH for these Dirichlet L-functions is covered far beyond Tollis's ~93 by Platt's rigorous Dirichlet computations (to be
  confirmed and cited in RESULTS; not re-done here).
* Non-Galois totally real fields (148, 229, 257, ...): ρ has Γ-factor Γ_R(s)² (an even Maass form of eigenvalue 1/4), not Γ_C.
  The Lemma-T evaluator relies on incomplete gamma functions (the Mellin kernel of Γ(s)); Γ_R(s)² needs the incomplete Mellin transform of
  K₀, which Arb does not provide. The explicit-formula rows would port easily (ψ(s/2) terms), the Z evaluator would not. **Out of scope for
  this pass** unless a rigorous K₀-incomplete-Mellin evaluator is built.
