"""Complex cubic fields of Tollis, Math. Comp. 66 (1997), Table 6.2 (p. 1318), and the splitting-type table of each (THEORY_TOLLIS.md §1).
Type codes per prime p (Dedekind-Kummer on Tollis's polynomial P; disc(P) = d_K, index 1):
   0: p = P1 P2 P3   (f = 1,1,1)   a_p =  2, chi(p) = +1
   1: p = P1 P2      (f = 1,2)     a_p =  0, chi(p) = -1
   2: p inert        (f = 3)       a_p = -1, chi(p) = +1
   3: p = P1^2 P2                  a_p =  1, ramified (bad), L_p = (1 - p^-s)^-1
   4: p = P^3                      a_p =  0, ramified (bad), L_p = 1
  -1: not prime.
BUILD (untrusted search; verify_cubic.py proves the table): FLINT nmod_poly.factor of P mod p for every prime p <= PMAX.
usage: python cubic.py build NAME    -> types/NAME.npy"""
import sys, os, json, time, hashlib
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
PMAX = 3000010
# P(x) as integer coefficients, high -> low (Tollis's column P(x)); Tollis GRH height, first zero, Nb <= 92 (zeros of zeta_K)
FIELDS = {
    'K23':  dict(d=-23,  P=[1, 1, 0, -1],  tollis=93.81, first=5.11568, nb92=121),
    'K31':  dict(d=-31,  P=[1, -1, 0, -1], tollis=94.11, first=4.16621, nb92=125),
    'K44':  dict(d=-44,  P=[1, -1, -1, -1], tollis=93.98, first=4.04199, nb92=130),
    'K59':  dict(d=-59,  P=[1, 0, 2, -1],  tollis=93.78, first=3.43180, nb92=134),
    'K76':  dict(d=-76,  P=[1, 0, -2, -2], tollis=93.89, first=3.27623, nb92=138),
    'K83':  dict(d=-83,  P=[1, -1, 1, -2], tollis=93.73, first=2.91606, nb92=139),
    'K87':  dict(d=-87,  P=[1, 1, 2, -1],  tollis=93.38, first=2.68368, nb92=140),
    'K104': dict(d=-104, P=[1, 0, -1, -2], tollis=93.06, first=3.31991, nb92=142),
    'K107': dict(d=-107, P=[1, -1, 3, -2], tollis=93.34, first=2.61608, nb92=143),
    'K108': dict(d=-108, P=[1, 0, 0, -2],  tollis=94.26, first=2.82161, nb92=143),
}
AP = {0: 2, 1: 0, 2: -1, 3: 1, 4: 0}
CHI = {0: 1, 1: -1, 2: 1, 3: 0, 4: 0}

def disc(P):
    a, b, c, d = P; assert a == 1
    return b * b * c * c - 4 * c ** 3 - 4 * b ** 3 * d - 27 * d * d + 18 * b * c * d

def primes_upto(n):
    s = np.ones(n + 1, bool); s[:2] = False
    for i in range(2, int(n ** 0.5) + 1):
        if s[i]: s[i * i::i] = False
    return np.nonzero(s)[0]

def type_of(fac):
    """fac = [(deg, exp), ...] of P mod p -> type code"""
    fac = sorted(fac)
    if fac == [(1, 1), (1, 1), (1, 1)]: return 0
    if fac == [(1, 1), (2, 1)]: return 1
    if fac == [(3, 1)]: return 2
    if fac == [(1, 1), (1, 2)]: return 3
    if fac == [(1, 3)]: return 4
    raise ValueError(fac)

def build(name):
    from flint import nmod_poly
    P = FIELDS[name]['P']; assert disc(P) == FIELDS[name]['d']
    typ = np.full(PMAX + 1, -1, np.int8); t0 = time.time()
    for p in primes_upto(PMAX):
        p = int(p)
        f = nmod_poly(P[::-1], p)
        _, fl = f.factor()
        typ[p] = type_of([(g.degree(), e) for g, e in fl])
    os.makedirs(os.path.join(HERE, 'types'), exist_ok=True)
    fn = os.path.join(HERE, 'types', name + '.npy'); np.save(fn, typ)
    sha = hashlib.sha256(open(fn, 'rb').read()).hexdigest()
    print(json.dumps(dict(name=name, file=fn, sha256=sha, seconds=round(time.time() - t0, 1),
                          counts={int(k): int((typ == k).sum()) for k in range(5)})))

if __name__ == '__main__':
    if sys.argv[1] == 'build':
        for n in sys.argv[2:]: build(n)
