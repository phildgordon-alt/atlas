# diagnostic: compare LMFDB raw aps_data (dimension-1 newforms, basis [1]) with our a_p tables
import sys, os, glob, ast, json, numpy as np
sys.path.insert(0, '/Users/kiosk/atlas_mark2/diagnostic/new_territory/tollis')
import fields_ext2; fields_ext2.install(); import forms
out = []
for f in sorted(glob.glob('/Users/kiosk/atlas_mark2/diagnostic/new_territory/tollis/diagnostics/lmfdb_qexp_addendum2/*.sage.txt')):
    lab = os.path.basename(f).split('.sage')[0]; nm = 'K' + lab.split('.')[0]
    line = [l for l in open(f) if l.startswith('aps_data')][0]
    aps = [int(x[0]) if len(x) == 1 else None for x in ast.literal_eval(line.split('=', 1)[1].strip())]
    F = forms.form(nm, 1000); pr = [int(p) for p in forms.primes_upto(10000)][:len(aps)]
    mism = [(p, a, int(F['ap'][p])) for p, a in zip(pr, aps) if a != int(F['ap'][p])]
    out.append(dict(label=lab, field=nm, primes_compared=len(aps), p_max=pr[-1], mismatches=mism))
    print(json.dumps(out[-1]))
json.dump(out, open('/Users/kiosk/atlas_mark2/diagnostic/new_territory/tollis/logs/lmfdb_qexp_compare_addendum2.json', 'w'), indent=1)
