"""DIAGNOSTIC (THEORY_TOLLIS.md §3): the Dedekind-Kummer a_n of L = zeta_K/zeta versus the weight-1 theta series of binary quadratic forms
f = (1/2) sum_C psi(C) theta_C over the primitive form classes of discriminant D = d_K, psi a class-group character of order 3.
h(D) = 3: f = (theta_{Q0} - theta_{Q1})/2.  h(D) = 6 (cyclic): f = (theta_{g^0} + theta_{g^3} - theta_{g^1} - theta_{g^2})/2, the order-2
class g^3 being the unique non-principal ambiguous class; classes of order 6 vs 3 are found by composing with the ambiguous class
(here: by the sign pattern psi(g^k) = omega^k, Re = 1, -1/2, -1/2, 1, -1/2, -1/2 => weight +1 on classes of order 1, 2 and -1/2 otherwise).
Also, for K23: the eta product eta(z) eta(23z) (deg2/forms.py, copied as forms_eta_deg2.py).  usage: python diag_theta.py NMAX NAME..."""
import sys, json, math
from math import gcd
import numpy as np
import cubic, forms

def reduced_forms(D):
    out = []; a = 1
    while 3 * a * a <= -D:
        for b in range(-a + 1, a + 1):
            if (b * b - D) % (4 * a): continue
            c = (b * b - D) // (4 * a)
            if c < a: continue
            if b < 0 and (a == c): continue
            if gcd(gcd(a, abs(b)), c) != 1: continue
            out.append((a, b, c))
        a += 1
    return out

def theta(Q, nmax):
    a, b, c = Q; t = np.zeros(nmax + 1, np.int64)
    # a x^2 + b x y + c y^2 <= nmax ; positive definite: |y| <= sqrt(4 a nmax / -D)
    D = b * b - 4 * a * c; ymax = int(math.isqrt(4 * a * nmax // (-D))) + 1
    for y in range(-ymax, ymax + 1):
        # a x^2 + b y x + c y^2 - n = 0
        disc = b * b * y * y - 4 * a * (c * y * y - nmax)
        if disc < 0: continue
        r = math.isqrt(disc); x0 = (-b * y - r) // (2 * a) - 1; x1 = (-b * y + r) // (2 * a) + 1
        for x in range(x0, x1 + 1):
            v = a * x * x + b * x * y + c * y * y
            if 0 <= v <= nmax: t[v] += 1
    return t

def order_in_classgroup(Q, forms_list):
    """order of the class of Q via repeated composition is overkill for h <= 6; use: ambiguous (order <= 2) iff b = 0 or a = b or a = c"""
    a, b, c = Q
    return 2 if (b == 0 or a == b or a == c) else 3   # 3 here means 'order 3 or 6' (non-ambiguous)

def main():
    nmax = int(sys.argv[1]); out = []
    for nm in sys.argv[2:]:
        D = cubic.FIELDS[nm]['d']; fl = reduced_forms(D); h = len(fl)
        F = forms.form(nm, 1000); typ = None
        a = forms.an_table(F['ap'], F['chi'], F['bad'], nmax)
        if h == 3:
            th = [theta(Q, nmax) for Q in fl]; f2 = th[0] - th[1]
            assert (th[1] == th[2]).all()
        elif h == 6:
            amb = [Q for Q in fl if order_in_classgroup(Q, fl) == 2]
            assert len(amb) == 2, amb                     # principal + order-2 class (cyclic C6)
            f2 = np.zeros(nmax + 1, np.int64)
            for Q in fl:
                t = theta(Q, nmax); f2 += 2 * t if Q in amb else -t
            # f2 = 2 sum_amb theta - sum_nonamb theta = 4 f   (Re psi = 1 on ambiguous classes, -1/2 on the four others)
        else:
            out.append(dict(name=nm, D=D, h=h, skipped='class number not 3 or 6')); continue
        if h == 3:
            mism = [n for n in range(1, nmax + 1) if f2[n] % 2 or f2[n] // 2 != a[n]]
        else:
            mism = [n for n in range(1, nmax + 1) if f2[n] % 4 or f2[n] // 4 != a[n]]
        rec = dict(name=nm, D=D, h=h, forms=fl, nmax=nmax, mismatches=len(mism), first_mismatches=mism[:10], a_1_to_30=a[1:31])
        if nm == 'K23':
            import forms_eta_deg2 as fe
            eta = fe.eta_quotient_coeffs(min(nmax, 6000), 23, 1)
            rec['eta_mismatches_n_le_6000'] = sum(1 for n in range(1, min(nmax, 6000) + 1) if eta[n] != a[n])
        out.append(rec); print(json.dumps(rec), flush=True)

if __name__ == '__main__':
    main()
