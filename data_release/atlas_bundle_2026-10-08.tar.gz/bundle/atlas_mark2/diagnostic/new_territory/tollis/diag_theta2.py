"""DIAGNOSTIC (ADDENDUM 2; THEORY_TOLLIS.md §3 generalised to any class number): Dedekind-Kummer a_n of L = zeta_K/zeta versus the
weight-1 theta series f = (1/2) sum_C psi(C) theta_C over the primitive form classes C of discriminant D = d_K, psi a character of order 3
of the form class group Cl(D).  Since theta_C = theta_{C^-1}, f = (1/2) sum_C Re psi(C) theta_C, Re psi = 1 on ker psi, -1/2 elsewhere:
    4 f = 2 sum_{C in ker psi} theta_C - sum_{C not in ker psi} theta_C.
When the 3-rank of Cl(D) is 1 (exactly one cubic field of discriminant D), ker psi = Cl(D)^3 (the cubes), of index 3; this is checked.
The class group is built from the reduced forms with Gauss/Dirichlet composition (Cohen, GTM 138, Alg. 5.4.7) and reduction; the group
law is sanity-checked (identity, inverses, closure, |Cl| = h).  Shares no code with cubic.py / verify_cubic.py; uses diag_theta.theta and
diag_theta.reduced_forms and forms.an_table.   usage: python run_ext2.py diag_theta2.py NMAX NAME..."""
import sys, json
from math import gcd
import numpy as np
import cubic, forms, diag_theta

def xgcd(a, b):
    x0, y0, x1, y1 = 1, 0, 0, 1
    while b:
        q = a // b; a, b = b, a - q * b; x0, x1 = x1, x0 - q * x1; y0, y1 = y1, y0 - q * y1
    return a, x0, y0          # a = x0*a_in + y0*b_in

def reduce_form(f):
    a, b, c = f
    while True:
        if not (-a < b <= a):                     # normalise b into (-a, a]
            k = (a - b) // (2 * a); c = c + k * b + k * k * a; b = b + 2 * k * a
        if a > c:
            a, b, c = c, -b, a; continue
        if a == c and b < 0: b = -b
        return (a, b, c)

def compose(f1, f2, D):
    a1, b1, c1 = f1; a2, b2, c2 = f2
    if a1 > a2: a1, b1, c1, a2, b2, c2 = a2, b2, c2, a1, b1, c1
    s = (b1 + b2) // 2; n = b2 - s
    if a2 % a1 == 0: y1 = 0; d = a1
    else: d, u, v = xgcd(a2, a1); y1 = u
    if s % d == 0: y2 = -1; x2 = 0; d1 = d
    else: d1, x2, v = xgcd(s, d); y2 = -v
    v1 = a1 // d1; v2 = a2 // d1; r = (y1 * y2 * n - x2 * c2) % v1
    b3 = b2 + 2 * v2 * r; a3 = v1 * v2
    num = b3 * b3 - D; assert num % (4 * a3) == 0
    return reduce_form((a3, b3, num // (4 * a3)))

def main():
    nmax = int(sys.argv[1])
    for nm in sys.argv[2:]:
        D = cubic.FIELDS[nm]['d']; fl = diag_theta.reduced_forms(D); h = len(fl); S = set(fl)
        e = reduce_form((1, D % 2, (D % 2 - D) // 4))
        assert e in S
        for f in fl:                                              # group-law sanity: closure, identity, inverse
            assert compose(f, e, D) == f and compose(f, reduce_form((f[0], -f[1], f[2])), D) == e
            for g in fl: assert compose(f, g, D) in S and compose(f, g, D) == compose(g, f, D)
        cubes = {compose(compose(f, f, D), f, D) for f in fl}
        assert all(compose(compose(x, y, D), z, D) == compose(x, compose(y, z, D), D) for x in fl[:4] for y in fl for z in fl[:4])
        rec = dict(name=nm, D=D, h=h, index_of_cubes=h // len(cubes) if h % len(cubes) == 0 else None)
        if h % 3 or h // len(cubes) != 3:
            rec['skipped'] = '3-rank != 1'; print(json.dumps(rec), flush=True); continue
        F = forms.form(nm, 1000); a = forms.an_table(F['ap'], F['chi'], F['bad'], nmax)
        f4 = np.zeros(nmax + 1, np.int64)
        for Q in fl:
            t = diag_theta.theta(Q, nmax); f4 += 2 * t if Q in cubes else -t
        mism = [n for n in range(1, nmax + 1) if f4[n] % 4 or f4[n] // 4 != a[n]]
        rec.update(kernel=sorted(cubes), nmax=nmax, mismatches=len(mism), first_mismatches=mism[:10], a_1_to_30=a[1:31])
        print(json.dumps(rec), flush=True)

if __name__ == '__main__':
    main()
