"""DIAGNOSTIC: compare a field's sign-change intervals (all run dirs given) with Tollis Table 6.2: first zero, number of zeta_K zeros <= 92
(= #L zeros <= 92 + 25 zeta zeros <= 92), and least / greatest gaps with (Gap) and without (Gap*) the zeta zeros, over zeros <= LIMIT
(Tollis's own range for the gap columns is not stated precisely; reported for LIMIT = 92 and LIMIT = his height).
usage: python diag_tollis.py FIELD RUNDIR [RUNDIR ...]"""
import sys, os, json
import cubic
ZETA = [14.134725, 21.022040, 25.010858, 30.424876, 32.935062, 37.586178, 40.918719, 43.327073, 48.005151, 49.773832, 52.970321,
        56.446248, 59.347044, 60.831779, 65.112544, 67.079811, 69.546402, 72.067158, 75.704691, 77.144840, 79.337375, 82.910381,
        84.735493, 87.425275, 88.809111, 92.491899, 94.651344]
nm = sys.argv[1]; T = cubic.FIELDS[nm]; mids = set()
for d in sys.argv[2:]:
    for a, b in json.load(open(os.path.join(d, 'intervals.json')))['intervals']:
        m = (a + b) / 2
        if m > 0: mids.add(m)
L = []
for m in sorted(mids):
    if not L or m - L[-1] > 1e-6: L.append(m)        # same zero seen from overlapping windows
def gaps(z, lim):
    z = [x for x in z if x <= lim]; g = [b - a for a, b in zip(z, z[1:])]
    return (round(min(g), 5), round(max(g), 5)) if g else None
out = dict(field=nm, d=T['d'], tollis_height=T['tollis'], first_zero=L[0] if L else None, tollis_first_zero=T['first'],
           L_zeros_le_92=sum(1 for x in L if x <= 92), predicted_from_tollis=T['nb92'] - 25, zetaK_zeros_le_92=sum(1 for x in L if x <= 92) + 25,
           tollis_nb92=T['nb92'], max_ordinate_seen=L[-1] if L else None)
for lim in (92.0, T['tollis'], 95.0):
    out[f'gap_star_le_{lim}'] = gaps(L, lim); out[f'gap_le_{lim}'] = gaps(sorted(L + ZETA), lim)
print(json.dumps(out))
