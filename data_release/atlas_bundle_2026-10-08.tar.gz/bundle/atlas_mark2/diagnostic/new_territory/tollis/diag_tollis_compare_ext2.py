import json, os
os.chdir('/Users/kiosk/atlas_mark2/diagnostic/new_territory/tollis')
T = {116: (0.01069, 2.11816, 0.06693, 2.11816), 135: (0.00050, 2.36295, 0.08348, 2.36295), 139: (0.00171, 1.90768, 0.12775, 1.90768),
     140: (0.02046, 2.59247, 0.05948, 2.59247), 152: (0.00546, 1.91305, 0.17549, 1.91305), 172: (0.00616, 1.84139, 0.13394, 1.84139),
     175: (0.02071, 2.39880, 0.18226, 2.39880), 199: (0.01448, 2.62086, 0.19531, 2.62086), 200: (0.01052, 1.78618, 0.11447, 1.78618),
     204: (0.00346, 1.84822, 0.08541, 1.84822), 211: (0.01656, 1.68544, 0.12543, 1.68544), 212: (0.02508, 1.79746, 0.10591, 1.79746),
     216: (0.00312, 1.62192, 0.06707, 1.62192), 231: (0.00523, 2.34089, 0.12322, 2.34089), 239: (0.01478, 2.69767, 0.15969, 2.69767)}
rows = []
for n, t in T.items():
    K = f'K{n}'
    if not os.path.exists(f'logs/diag_tollis_{K}.json'): continue
    d = json.load(open(f'logs/diag_tollis_{K}.json')); u = json.load(open(f'logs/union_{K}_0_110.json'))
    H = d['tollis_height']; g = d[f'gap_le_{H}']; gs = d[f'gap_star_le_{H}']
    def ok(a, b): return abs(a - b) <= 2e-5
    rows.append(dict(K=K, covered=u['covered'], gaps=u['gaps'], cells=u['cells'], zeros110=u['distinct_sign_changes_in_range'],
                     per_chunk=[p['zeros_in_target'] for p in u['per_chunk']], minm=min(p['min_margin'] for p in u['per_chunk']),
                     first=round(d['first_zero'], 6), tfirst=d['tollis_first_zero'], n92=d['L_zeros_le_92'], tn92=d['predicted_from_tollis'],
                     gapH=g, gapstarH=gs, tollis=t, gap92=d['gap_le_92.0'], gapstar92=d['gap_star_le_92.0'],
                     match=dict(first=abs(d['first_zero'] - d['tollis_first_zero']) < 1.5e-5, n92=d['L_zeros_le_92'] == d['predicted_from_tollis'],
                                lg=ok(g[0], t[0]), gg=ok(g[1], t[1]), lgs=ok(gs[0], t[2]), ggs=ok(gs[1], t[3]))))
    print(json.dumps(rows[-1]))
json.dump(rows, open('logs/tollis_compare_addendum2.json', 'w'), indent=1)
