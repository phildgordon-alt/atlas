"""ADDENDUM 2 (2026-10-08): form-data registration for the 15 remaining complex cubic fields of Tollis, Math. Comp. 66 (1997), Table 6.2
(p. 1318), d_K = -116 ... -239.  DATA ONLY.  The frozen pipeline (CODE_SHA256_FROZEN.txt) is not modified: its field registry cubic.FIELDS and
its sha file TYPES_SHA256.json list only the first 10 fields, so this module ADDS the 15 new entries at run time, in memory:
  * cubic.FIELDS[name]  (same keys/semantics as the frozen entries: d, P high->low, Tollis height, first zero, Nb <= 92);
  * forms.FORMS[name] = dict(N=|d|, k=1, eps=+1)  (exactly the frozen rule FORMS = {nm: dict(N=-d, k=1, eps=1)});
  * forms.SHA_FILE -> TYPES_SHA256_ADDENDUM2.json = the 10 frozen entries of TYPES_SHA256.json (copied verbatim; checked equal at install)
    + the 15 new ones (written only from two fresh VERIFIED verify_cubic.py runs; forms._load still asserts the sha at every load).
It refuses to touch any existing entry (asserts no key overlap), so the 10 earlier fields and every frozen file behave exactly as before.
usage: python run_ext2.py SCRIPT.py ARGS...   (runs a frozen script as __main__ with the registration installed)"""
import os

HERE = os.path.dirname(os.path.abspath(__file__))
SHA_FILE2 = os.path.join(HERE, 'TYPES_SHA256_ADDENDUM2.json')
# Tollis Table 6.2 (p. 1318), rows 11-25: P(x) high -> low, D_K, GRH Height, Nb <= 92, First Zero
FIELDS2 = {
    'K116': dict(d=-116, P=[1, -1, 0, -2],  tollis=93.73, first=3.11568, nb92=144),
    'K135': dict(d=-135, P=[1, 0, 3, -1],   tollis=93.12, first=2.04028, nb92=146),
    'K139': dict(d=-139, P=[1, 1, 1, -2],   tollis=93.40, first=2.66179, nb92=146),
    'K140': dict(d=-140, P=[1, 0, 2, -2],   tollis=93.35, first=2.27790, nb92=147),
    'K152': dict(d=-152, P=[1, -1, -2, -2], tollis=94.20, first=2.81196, nb92=148),
    'K172': dict(d=-172, P=[1, 1, -1, -3],  tollis=93.79, first=2.35670, nb92=150),
    'K175': dict(d=-175, P=[1, -1, 2, -3],  tollis=93.20, first=1.81080, nb92=150),
    'K199': dict(d=-199, P=[1, -1, 4, -1],  tollis=92.30, first=1.67161, nb92=152),
    'K200': dict(d=-200, P=[1, 1, 2, -2],   tollis=93.67, first=2.52234, nb92=152),
    'K204': dict(d=-204, P=[1, -1, 1, -3],  tollis=93.07, first=2.51256, nb92=152),
    'K211': dict(d=-211, P=[1, 0, -2, -3],  tollis=92.83, first=2.29906, nb92=153),
    'K212': dict(d=-212, P=[1, -1, 4, -2],  tollis=93.27, first=2.46540, nb92=152),
    'K216': dict(d=-216, P=[1, 0, 3, -2],   tollis=94.07, first=2.79656, nb92=153),
    'K231': dict(d=-231, P=[1, 1, 0, -3],   tollis=93.14, first=1.84481, nb92=154),
    'K239': dict(d=-239, P=[1, 0, -1, -3],  tollis=93.83, first=2.12721, nb92=154),
}

def install():
    import cubic, forms                     # forms.FORMS is built from cubic.FIELDS at import time, i.e. before the update below
    assert not (set(FIELDS2) & set(cubic.FIELDS)) and not (set(FIELDS2) & set(forms.FORMS)), 'addendum-2 fields must be new'
    for nm, v in FIELDS2.items():
        assert cubic.disc(v['P']) == v['d'], ('disc(P) != Tollis D_K', nm)
    cubic.FIELDS.update(FIELDS2)
    forms.FORMS.update({nm: dict(N=-v['d'], k=1, eps=1) for nm, v in FIELDS2.items()})
    import json
    old = json.load(open(os.path.join(HERE, 'TYPES_SHA256.json'))); new = json.load(open(SHA_FILE2))
    assert all(new[k] == v for k, v in old.items()) and set(new) == set(old) | set(FIELDS2), 'sha file mismatch'
    forms.SHA_FILE = SHA_FILE2
