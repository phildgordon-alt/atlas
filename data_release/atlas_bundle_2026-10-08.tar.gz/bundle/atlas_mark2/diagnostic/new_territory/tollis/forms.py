"""Form data for L(s) = zeta_K(s)/zeta(s), K a complex cubic field of Tollis's Table 6.2 (THEORY_TOLLIS.md §1).
Weight k = 1 (Gamma(s) = Gamma_C up to constants), level N = |d_K|, root number eps = +1 (from the FEs of zeta_K and zeta).
Same interface as ../ec389a/forms.py: F['a'] = a_n (n <= AN_MAX, Lambda series), F['ap'] = a_p array (p <= PMAX, arith.Arith),
F['char'](p) = chi(p) for good p, F['bad'] = {p: a_p} for p | d_K, F['central_m0'] = 0 (no central reduction anywhere).
The splitting-type table types/NAME.npy must have the sha256 recorded in TYPES_SHA256.json, written only from a VERIFIED verify_cubic.py run.
Negative controls: perturb(F, p, delta) changes a_p (and every a_n); env NC_RULE = 'abelian' (a_p := 1 + chi(p), i.e. rho replaced by the
reducible 1 + chi_d) or 'swap' (split completely <-> inert: 2 <-> -1) replaces the splitting rule; F['eps'] / F['N'] may be overridden."""
import os, json, hashlib
import numpy as np
import cubic

HERE = os.path.dirname(os.path.abspath(__file__))
AN_MAX = 6000
CENTRAL_M0 = 0
primes_upto = cubic.primes_upto
SHA_FILE = os.path.join(HERE, 'TYPES_SHA256.json')
FORMS = {nm: dict(N=-v['d'], k=1, eps=1) for nm, v in cubic.FIELDS.items()}
AP_SHA256 = None        # set per form by form(); replay_deg2 reads F['ap_sha']

def _load(name):
    fn = os.path.join(HERE, 'types', name + '.npy'); raw = open(fn, 'rb').read()
    sha = hashlib.sha256(raw).hexdigest(); want = json.load(open(SHA_FILE))[name]
    assert sha == want, 'type table hash mismatch for ' + name
    return np.load(fn), sha

def _local(ap, chi, bad, M):
    """a_{p^e} for p <= M: good p: a_{p^{e+1}} = a_p a_{p^e} - chi(p) a_{p^{e-1}};  bad p: a_p^e"""
    loc = {}
    for p in primes_upto(M):
        p = int(p); seq = [1, int(ap[p])]; q = p * p
        while q <= M:
            seq.append(seq[-1] * int(ap[p]) if p in bad else seq[-1] * int(ap[p]) - int(chi[p]) * seq[-2]); q *= p
        loc[p] = seq
    return loc

def an_table(ap, chi, bad, M):
    spf = list(range(M + 1))
    for i in range(2, int(M ** 0.5) + 1):
        if spf[i] == i:
            for j in range(i * i, M + 1, i):
                if spf[j] == j: spf[j] = i
    loc = _local(ap, chi, bad, M); a = [0] * (M + 1); a[1] = 1
    for n in range(2, M + 1):
        p = spf[n]; m = n; e = 0
        while m % p == 0: m //= p; e += 1
        a[n] = loc[p][e] * a[m]
    return a

def form(name, M):
    F = dict(FORMS[name]); typ, sha = _load(name); assert M < len(typ), 'need a_p up to M'
    rule = os.environ.get('NC_RULE')
    ap = np.zeros(len(typ), np.int64); chi = np.zeros(len(typ), np.int64)
    for code in range(5):
        ap[typ == code] = cubic.AP[code]; chi[typ == code] = cubic.CHI[code]
    if rule == 'abelian':
        good = (typ >= 0) & (typ <= 2); ap[good] = 1 + chi[good]
    elif rule == 'swap':
        s0 = typ == 0; s2 = typ == 2; ap[s0] = -1; ap[s2] = 2
    elif rule: raise ValueError(rule)
    d = cubic.FIELDS[name]['d']; bad = {int(p): int(ap[p]) for p in primes_upto(-d) if d % int(p) == 0}
    F.update(ap=ap, chi=chi, bad=bad, name=name, ap_sha=sha, central_m0=CENTRAL_M0, nc_rule=rule)
    F['char'] = lambda p, _c=chi: int(_c[p])
    F['a'] = an_table(ap, chi, bad, AN_MAX)
    return F

def perturb(F, p, delta):
    G = dict(F); ap = np.array(F['ap']); ap[p] += delta; G['ap'] = ap
    G['bad'] = {q: int(ap[q]) for q in F['bad']}
    G['a'] = an_table(ap, F['chi'], G['bad'], AN_MAX)
    return G
