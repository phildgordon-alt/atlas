"""Negative control C7: corrupt one entry of a copy of types/K31.npy (p = 1009: type changed) and check that verify_cubic.verify FAILS on it
and that forms._load refuses it (sha mismatch).  Works on a temporary copy; the real table is untouched (sha re-checked at the end)."""
import os, json, shutil, hashlib, tempfile
import numpy as np
import cubic, verify_cubic, forms
real = os.path.join(cubic.HERE, 'types', 'K31.npy'); sha0 = hashlib.sha256(open(real, 'rb').read()).hexdigest()
tmp = tempfile.mkdtemp(); os.makedirs(os.path.join(tmp, 'types'))
t = np.load(real); p = 1009; old = int(t[p]); t[p] = (old + 1) % 3; np.save(os.path.join(tmp, 'types', 'K31.npy'), t)
cubic.HERE = tmp; r = verify_cubic.verify('K31')
forms.HERE = tmp
try:
    forms._load('K31'); load = 'LOADED (bad)'
except AssertionError as e: load = 'REFUSED: ' + str(e)
shutil.rmtree(tmp)
print(json.dumps(dict(corrupted_p=p, old_type=old, new_type=int(t[p]), verify=r['verdict'], errors=r['errors'][:3], forms_load=load,
                      real_table_unchanged=hashlib.sha256(open(real, 'rb').read()).hexdigest() == sha0)))
