#!/bin/zsh
# Negative controls (tollis) on validation windows K31 [0,10] and K44 [0,10] (W = [-6,16]). Corrupted replays never write replay.json.
P=/Users/kiosk/projects/atlas-rerun/.venv/bin/python
cd /Users/kiosk/atlas_mark2/diagnostic/new_territory/tollis
V=runs/val/K31_0_10; V44=runs/val/K44_0_10; O=runs/nc; mkdir -p $O
G() { nice -n 19 $P -B -u gen_cert.py K31 0 10 "$@"; }
RP() { nice -n 19 $P -B -u replay_deg2.py "$@"; }
# C1 fake sign change (5.5, 5.6) (zeros at 4.166 and 6.926): generator injection; forged into all real certificates (w = 0.5)
mkdir -p $O/fake; cp $V/rows.json $V/intervals.json $O/fake/
NC_FAKE=5.5,5.6 G $O/fake > $O/fake_gen.out 2>&1
ls $O/fake/certs/cell_*.json >/dev/null 2>&1 && RP $O/fake 0 10 replay_NC.json > $O/fake_replay.out 2>&1
$P -B nc_forge.py $V $O/forged 5.5 5.6 0.5 > /dev/null
RP $O/forged 0 10 replay_NC.json > $O/forged_replay.out 2>&1
# C2 perturbed a_2 (K31: a_2 = -1 -> 0): replay rows + Z; rows only (true Z); generator
NC_AP=2:1 RP $V 0 10 replay_NC_a2.json > $O/a2_replay.out 2>&1
NC_AP=2:1 NC_ROWS_ONLY=1 RP $V 0 10 replay_NC_a2_rowsonly.json > $O/a2_rowsonly_replay.out 2>&1
mkdir -p $O/a2gen; cp $V/intervals.json $O/a2gen/
NC_AP=2:1 G $O/a2gen > $O/a2_gen.out 2>&1
# C3 wrong splitting rule: 'abelian' (a_p = 1 + chi(p): rho -> 1 + chi_d) and 'swap' (split <-> inert): replay rows + Z (forms-level, so Z too), generator with the true intervals (rows only)
for R in abelian swap; do
  NC_RULE=$R RP $V 0 10 replay_NC_rule_$R.json > $O/rule_${R}_replay.out 2>&1
  mkdir -p $O/rule_${R}gen; cp $V/intervals.json $O/rule_${R}gen/
  NC_RULE=$R G $O/rule_${R}gen > $O/rule_${R}_gen.out 2>&1
done
# C4 wrong conductor N = 30, 32 (K31) and N = 11 (K44: the fundamental discriminant of its resolvent field Q(sqrt -11))
NC_N=30 RP $V 0 10 replay_NC_N30.json > $O/N30_replay.out 2>&1
NC_N=32 RP $V 0 10 replay_NC_N32.json > $O/N32_replay.out 2>&1
NC_N=11 RP $V44 0 10 replay_NC_N11.json > $O/K44_N11_replay.out 2>&1
# C5 K44 ramified rule: a_2 = 0 (2 = P^3) -> 1 (as if 2 = P1^2 P2): replay rows + Z
NC_AP=2:1 RP $V44 0 10 replay_NC_a2.json > $O/K44_a2_replay.out 2>&1
# C6 wrong root number eps = -1
NC_EPS=-1 RP $V 0 10 replay_NC_eps.json > $O/eps_replay.out 2>&1
# C7 type table: one flipped entry must make verify_cubic FAIL and forms refuse to load (hash)
$P -B nc_table.py > $O/table_nc.out 2>&1
echo NC_DONE > $O/done
