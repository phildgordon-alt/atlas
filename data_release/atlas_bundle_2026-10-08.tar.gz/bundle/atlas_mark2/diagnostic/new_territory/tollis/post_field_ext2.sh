#!/bin/zsh
# ADDENDUM 2 copy of post_field.sh (diag_tollis.py launched via run_ext2.py for the new field registrations). Post-processing per field (light): exact union over the 11 contiguous chunks [0,110] (and to 200 for K23 if present) + Tollis diagnostic.
P=/Users/kiosk/projects/atlas-rerun/.venv/bin/python
cd /Users/kiosk/atlas_mark2/diagnostic/new_territory/tollis
K=$1; HI=${2:-110}; D=()
for j in $(seq 0 $((HI/10-1))); do D+=runs/contig/$K/c_$((10*j))_$((10*j+10)); done
$P -B union.py 0 $HI $D > logs/union_${K}_0_${HI}.json
$P -B run_ext2.py diag_tollis.py $K $D $(ls -d runs/core/${K}_* | grep -v "\.out") > logs/diag_tollis_${K}.json
python3 -c "
import json;u=json.load(open('logs/union_${K}_0_${HI}.json'));d=json.load(open('logs/diag_tollis_${K}.json'))
print('$K', 'covered',u['covered'],u['gaps'],'cells',u['cells'],'zeros',u['distinct_sign_changes_in_range'],[p['zeros_in_target'] for p in u['per_chunk']],'minmargin %.3f'%min(p['min_margin'] for p in u['per_chunk']), 'shas',len(u['ap_table_shas']),len(u['replay_verify_shas']))
print('   gap95',d['gap_le_95.0'],d['gap_star_le_95.0']); print('   first',round(d['first_zero'],6),d['tollis_first_zero'],' L<=92',d['L_zeros_le_92'],'pred',d['predicted_from_tollis'],' gap*',d['gap_star_le_92.0'],' gap',d['gap_le_92.0'])"
