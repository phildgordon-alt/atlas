"""ADDENDUM 2 launcher: install the 15 new field registrations (fields_ext2.install) and run a frozen script unchanged as __main__.
usage: python -B -u run_ext2.py SCRIPT.py ARGS...      special: python run_ext2.py build NAME...  (cubic.build for the new fields)
Before the script runs, the frozen modules it imports (cubic, forms) are already in sys.modules with the new entries added; nothing else
is altered (importing forms loads no table; tables are loaded, sha-checked, by forms.form)."""
import sys, os, runpy
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import fields_ext2

if __name__ == '__main__':
    if sys.argv[1] == 'build':
        fields_ext2.install()
        import cubic
        for nm in sys.argv[2:]:
            assert nm in fields_ext2.FIELDS2
            cubic.build(nm)
    else:
        fields_ext2.install()
        script = os.path.join(HERE, sys.argv[1])
        sys.argv = [script] + sys.argv[2:]
        runpy.run_path(script, run_name='__main__')
