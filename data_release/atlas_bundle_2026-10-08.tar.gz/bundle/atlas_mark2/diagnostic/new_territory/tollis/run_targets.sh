#!/bin/zsh
# Pre-registered target runs (PREDICTIONS.md).  Reads PLAN lines "FIELD TLO THI RUNDIR"; generator then fresh-process replay per line;
# one heavy process at a time, nice 19; skips lines whose replay.json exists; stops if runs/STOP exists.
P=/Users/kiosk/projects/atlas-rerun/.venv/bin/python
cd /Users/kiosk/atlas_mark2/diagnostic/new_territory/tollis
while read K lo hi R; do
  [ -z "$K" ] && continue; [[ "$K" == \#* ]] && continue
  [ -f $R/replay.json ] && continue
  [ -f runs/STOP ] && break
  mkdir -p $R
  /usr/bin/time -l nice -n 19 $P -B -u gen_cert.py $K $lo $hi $R > $R.out 2>&1
  /usr/bin/time -l nice -n 19 $P -B -u replay_deg2.py $R $lo $hi > $R.replay.out 2>&1
  echo "$K $lo $hi $R $(grep SUMMARY $R.replay.out | grep -o '"closed": [a-z]*') $(grep SUMMARY $R.replay.out | grep -o '"passed_both": [0-9]*')/$(grep SUMMARY $R.replay.out | grep -o '"certificates": [0-9]*' | awk '{print $2}') gen_s=$(grep ' real' $R.out | awk '{print $1}') rep_s=$(grep ' real' $R.replay.out | awk '{print $1}') gen_peak=$(grep 'peak memory' $R.out | awk '{print $1}') rep_peak=$(grep 'peak memory' $R.replay.out | awk '{print $1}')" >> runs/SUMMARY.log
done < $1
