#!/bin/zsh
# ADDENDUM 2 runner: identical to the frozen run_targets.sh except that gen_cert.py and replay_deg2.py are launched through run_ext2.py
# (which only registers the 15 new fields, fields_ext2.py) and that it stops when free disk < 2 GB.  Lines "FIELD TLO THI RUNDIR";
# generator then fresh-process replay per line; one heavy process at a time, nice 19; skips lines whose replay.json exists; stops if runs/STOP exists.
P=/Users/kiosk/projects/atlas-rerun/.venv/bin/python
cd /Users/kiosk/atlas_mark2/diagnostic/new_territory/tollis
while read K lo hi R; do
  [ -z "$K" ] && continue; [[ "$K" == \#* ]] && continue
  [ -f $R/replay.json ] && continue
  [ -f runs/STOP ] && break
  FREE=$(df -k . | tail -1 | awk '{print $4}'); [ $FREE -lt 2000000 ] && { echo "STOP: free disk $FREE kB < 2 GB" >> runs/SUMMARY_ADDENDUM2.log; break; }
  mkdir -p $R
  /usr/bin/time -l nice -n 19 $P -B -u run_ext2.py gen_cert.py $K $lo $hi $R > $R.out 2>&1
  /usr/bin/time -l nice -n 19 $P -B -u run_ext2.py replay_deg2.py $R $lo $hi > $R.replay.out 2>&1
  echo "$K $lo $hi $R $(grep SUMMARY $R.replay.out | grep -o '"closed": [a-z]*') $(grep SUMMARY $R.replay.out | grep -o '"passed_both": [0-9]*')/$(grep SUMMARY $R.replay.out | grep -o '"certificates": [0-9]*' | awk '{print $2}') gen_s=$(grep ' real' $R.out | awk '{print $1}') rep_s=$(grep ' real' $R.replay.out | awk '{print $1}') gen_peak=$(grep 'peak memory' $R.out | awk '{print $1}') rep_peak=$(grep 'peak memory' $R.replay.out | awk '{print $1}') end=$(date +%H:%M)" >> runs/SUMMARY_ADDENDUM2.log
done < $1
