#!/bin/zsh
# Validation windows [0,10] for every core field (W = [-6,16]; no central reduction): generator then fresh-process replay. Serial, nice 19.
P=/Users/kiosk/projects/atlas-rerun/.venv/bin/python
cd /Users/kiosk/atlas_mark2/diagnostic/new_territory/tollis; mkdir -p runs/val
for K in "$@"; do R=runs/val/${K}_0_10; mkdir -p $R
  /usr/bin/time -l nice -n 19 $P -B -u gen_cert.py $K 0 10 $R > $R.out 2>&1
  /usr/bin/time -l nice -n 19 $P -B -u replay_deg2.py $R 0 10 > $R.replay.out 2>&1
  echo "$K $(grep SUMMARY $R.replay.out | grep -o '"closed": [a-z]*') $(grep SUMMARY $R.replay.out | grep -o '"passed_both": [0-9]*') gen_s=$(grep ' real' $R.out | awk '{print $1}') rep_s=$(grep ' real' $R.replay.out | awk '{print $1}') gen_peak=$(grep 'peak memory' $R.out | awk '{print $1}') rep_peak=$(grep 'peak memory' $R.replay.out | awk '{print $1}')" >> runs/val/SUMMARY.log
done
