"""PROOF of the splitting-type table types/NAME.npy (THEORY_TOLLIS.md §1, §6).  Pure Python integers; shares no code with cubic.build
(which used FLINT's factorization).  For every prime p <= PMAX:
  * p | d_K: multiplicities of the roots of P mod p by brute force (P, P', P'' evaluated at every residue): double + simple root -> type 3,
    triple root -> type 4; anything else is an error.  Dedekind's criterion is verified for every p with p^2 | disc(P) (so p does not divide
    the index and Dedekind-Kummer applies); disc(P) = d_K is re-checked, so for all other p the index is prime to p automatically.
  * p !| d_K: P is separable mod p; r = deg gcd(x^p - x, P) mod p computed by square-and-multiply in F_p[x]/(P) and a Euclidean gcd;
    r = 3 -> type 0, r = 1 -> type 1, r = 0 -> type 2 (r = 2 is impossible and is an error).  For p < 20000 r is also counted by brute force.
  * Stickelberger consistency (p odd, p !| d): Kronecker (d/p) = +1 iff r != 1;  p = 2 (d odd): (d/2) = +1 iff d = +-1 mod 8.
usage: python verify_cubic.py NAME [NAME ...]   -> VERIFIED / FAILED (+ sha256 of the table) as JSON"""
import sys, os, json, time, hashlib
import numpy as np
import cubic

def pmod(a, P, p):
    """reduce polynomial a (list low->high) modulo monic cubic P (low->high, P[3] = 1) over F_p"""
    a = [x % p for x in a]
    for i in range(len(a) - 1, 2, -1):
        c = a[i]
        if c:
            for j in range(3): a[i - 3 + j] = (a[i - 3 + j] - c * P[j]) % p
        a[i] = 0
    return (a + [0, 0, 0])[:3]

def pmul(a, b, P, p):
    r = [0] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        if x:
            for j, y in enumerate(b): r[i + j] += x * y
    return pmod(r, P, p)

def xpow(P, p):
    """x^p mod (P, p) as [c0, c1, c2]"""
    res = [1, 0, 0]; base = [0, 1, 0]; e = p
    while e:
        if e & 1: res = pmul(res, base, P, p)
        base = pmul(base, base, P, p); e >>= 1
    return res

def strip(a):
    a = list(a)
    while a and a[-1] == 0: a.pop()
    return a

def pgcd_deg(a, b, p):
    a = strip([x % p for x in a]); b = strip([x % p for x in b])
    while b:
        inv = pow(b[-1], p - 2, p)
        while len(a) >= len(b):
            c = a[-1] * inv % p; s = len(a) - len(b)
            for i in range(len(b)): a[s + i] = (a[s + i] - c * b[i]) % p
            a = strip(a)
        a, b = b, a
    return len(a) - 1

def jacobi(a, n):
    assert n > 0 and n % 2 == 1
    a %= n; t = 1
    while a:
        while a % 2 == 0:
            a //= 2
            if n % 8 in (3, 5): t = -t
        a, n = n, a
        if a % 4 == 3 and n % 4 == 3: t = -t
        a %= n
    return t if n == 1 else 0

def kron(d, p):
    if p == 2: return 0 if d % 2 == 0 else (1 if d % 8 in (1, 7) else -1)
    return jacobi(d, p)

def ev(P, x, p):
    return (((P[3] * x + P[2]) * x + P[1]) * x + P[0]) % p

def dedekind_criterion(Phl, p):
    """True iff p does not divide [O_K : Z[alpha]] (Dedekind's criterion), pure Python; P has only linear factors with multiplicity mod p
    (the case occurring here: p | disc(P), so P mod p has a repeated root; a cubic with a repeated factor splits into linear factors)."""
    P = Phl[::-1]                                         # low -> high
    roots = [(x, _mult_exact(P, x, p)) for x in range(p) if ev(P, x, p) == 0]
    assert sum(m for _, m in roots) == 3, ('P mod p not split into linear factors', p, roots)
    def mul(a, b):
        r = [0] * (len(a) + len(b) - 1)
        for i, u in enumerate(a):
            for j, v in enumerate(b): r[i + j] += u * v
        return r
    g = [1]; h = [1]
    for x, m in roots:
        g = mul(g, [-x, 1])
        for _ in range(m - 1): h = mul(h, [-x, 1])
    gh = mul(g, h); gh = gh + [0] * (4 - len(gh))
    Fp = [(gh[i] - P[i]) for i in range(4)]
    assert all(c % p == 0 for c in Fp)
    F = [c // p for c in Fp]
    # gcd(F, g, h) over F_p: = 1 iff no repeated root x (those dividing h) is a root of F
    bad = [x for x, m in roots if m >= 2 and ev(F + [0] * (4 - len(F)), x, p) == 0]
    return not bad, roots

def _mult_exact(P, x, p):
    """multiplicity of the root x of P (low->high, cubic) mod p, by repeated synthetic division by (X - x)"""
    a = [c % p for c in P]; m = 0
    while len(a) > 1 and sum(c * pow(x, i, p) for i, c in enumerate(a)) % p == 0:
        hi = a[::-1]; q = [hi[0]]
        for c in hi[1:-1]: q.append((c + q[-1] * x) % p)
        a = q[::-1]; m += 1
    return m

def verify(name):
    t0 = time.time(); info = cubic.FIELDS[name]; Phl = info['P']; d = info['d']; P = Phl[::-1]
    fn = os.path.join(cubic.HERE, 'types', name + '.npy'); raw = open(fn, 'rb').read(); sha = hashlib.sha256(raw).hexdigest()
    typ = np.load(fn); errs = []
    D = cubic.disc(Phl)
    if D != d: errs.append(('disc(P) != d_K', D, d))
    # sieve (own)
    n = len(typ) - 1; s = bytearray([1]) * (n + 1); s[0] = s[1] = 0
    for i in range(2, int(n ** 0.5) + 1):
        if s[i]: s[i * i::i] = bytearray(len(range(i * i, n + 1, i)))
    nprime = 0; ded = {}
    for p in range(2, n + 1):
        if not s[p]:
            if typ[p] != -1: errs.append(('nonprime typed', p));
            continue
        nprime += 1
        if d % p == 0:
            ok_ded = True
            if D % (p * p) == 0:
                ok_ded, roots = dedekind_criterion(Phl, p); ded[p] = dict(p_not_dividing_index=ok_ded, roots=roots)
                if not ok_ded: errs.append(('Dedekind criterion fails', p))
            ms = sorted(_mult_exact(P, x, p) for x in range(p) if ev(P, x, p) == 0)
            want = 3 if ms == [1, 2] else (4 if ms == [3] else None)
            if want is None or typ[p] != want: errs.append(('ramified type', p, ms, int(typ[p])))
            continue
        xp = xpow(P, p); g = [(xp[0]) % p, (xp[1] - 1) % p, xp[2] % p]       # x^p - x mod P
        r = pgcd_deg(P, g, p) if strip(g) else 3
        if p < 20000:
            rb = sum(1 for x in range(p) if ev(P, x, p) == 0)
            if rb != r: errs.append(('root count mismatch', p, r, rb))
        want = {3: 0, 1: 1, 0: 2}.get(r)
        if want is None or typ[p] != want: errs.append(('type', p, r, int(typ[p])))
        k = kron(d, p)
        if (k == 1) != (r != 1): errs.append(('Stickelberger', p, k, r))
        if len(errs) > 20: break
    ram = [p for p in range(2, 200) if s[p] and d % p == 0]
    out = dict(name=name, d=d, table=fn, sha256=sha, primes=nprime, pmax=n, ramified={p: int(typ[p]) for p in ram}, dedekind=ded,
               verdict='VERIFIED' if not errs else 'FAILED', errors=errs[:20], seconds=round(time.time() - t0, 1))
    return out

if __name__ == '__main__':
    for nm in sys.argv[1:]:
        print(json.dumps(verify(nm)), flush=True)
