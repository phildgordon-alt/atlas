# Amendment 1 (2026-10-06, before any T1/T4 result exists)
Add method C' = MAP-FREE argument principle (argprinciple/mapfree.py: unit pieces, recursive midpoint bisection of boxes
symmetric about sigma=1/2, accept N<=1; no zero data) to T2 (as a 4th method) and T4 (as a 3rd method, same 2 h cap,
window [T, T+2], d = 0.2). Reason: the T2 run showed the argument principle needs no map in practice; a fair head-to-head must
include the strongest classical competitor. P4 is unchanged (B/A); add P4b: time(C')/time(A) does not decrease with height.

## Amendment 2 (2026-10-06, before any T1/T2-Atlas/T4 result)
Atlas side of T1/T2/T4 uses GUARD_FACTOR per the pre-registered rule in guard_v2/PREDICTIONS.md (1.1 if G1 met, else 2.0);
the value used is written to usefulness_tests/guard_factor_used.txt. Queue: run_queue3.sh.

## Amendment 3 (2026-10-06, before any T2-Atlas/T4 result)
Propagation restricted to the target +- margin via PROP_RANGE (T4: [T-1, T+3]; T2 663318: [663317.9, 663319.1]) and band start
pinned to the ledger band (T0=T). Bins left out stay open (sound; only weakens the far allowance). Rationale: full-band propagation
costs ~9x more for a 1-2 unit target (seen at 6.8e6). Pipeline timings in T4 therefore count propagation over the target only.

## Amendment 4 (2026-10-06, before any T1/T2-Atlas/T4 result exists)
Atlas side of T1/T2/T4 = atlas_v3 (atlas_v3/atlas_v3.py; sign-change LP + column generation + bottom level + direct fallback;
acceptance A1-A3 passed). Timed end to end (ledgers + unions + propagation + ladder + replay + tiling). Code hashes: V3_FREEZE.sha256.
Supersedes the T0-only lslab pipeline and Amendments 2 (guard factor) for the Atlas side. Methods B (direct) and C' (argument principle) unchanged.

## Amendment 5 (2026-10-07 07:30)
T4 Atlas side switched to atlas_v4 (atlas_v4/atlas_v4.py, frozen in atlas_v4/V4_FREEZE.sha256). Observed before this amendment:
atlas_v3 at 1e4 did not finish in ~5300 s (one piece's bottom level timed out at 1800 s twice) — recorded in t4_timing.log as not
finished; no v3 result at 1e5-1e7. DISCLOSURE: during v4 development, 2-unit windows at 1e5/1e6/1e7 were run with v4 (5-6 s each), so
v4's T4 timings are not blind. Methods B (direct, 2 h cap) and C' (map-free argument principle, 2 h cap) unchanged and not yet run at any T4 height.
Order after T4: v4 acceptance (atlas_v4/run_acceptance.sh, waits on t4.done) -> plant test -> degree-2 runs.
