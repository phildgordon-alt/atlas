# Atlas usefulness tests — pre-registered 2026-10-06 (before any of these runs)
Purpose: measure Atlas against the alternatives head-on instead of extrapolating from leftover-box mop-up (boundary_study).
All certificates rigorous (Arb); zero ordinates are never certificate inputs (diagnostic use only, stated per test).

## T1 Full-window head-to-head (d >= 0.001)
Windows: [9000,9010], [9100,9110], [9200,9210] (fresh). Task: certify no zero with |beta-1/2| in [0.001, 0.5] on the whole window.
A = Atlas pipeline (base 6 kernels -> off-centre -> propagation -> t0 ladder with pole guard on remaining open columns; no direct eval).
B = direct rigorous evaluation alone, tiled in 0.01-wide columns x [0.001, 0.5], adaptive bisection, 400k evaluations cap per column.
Metrics: wall time to full coverage (or coverage reached), single process each, same machine.
Prediction P1: A reaches full coverage in less total wall time than B on each window (B may also fail to finish columns near zeros).

## T2 Near-collision benchmark (on the line and simple, d in [0, 0.2])
Cases: Lehmer pair (7005.0629/7005.1006, normalized gap 0.042) and the tightest pair in Odlyzko's first 2,001,052 zeros
(663318.5083/663318.5113, normalized gap 0.0054). Methods: A = Atlas ladder; B = direct evaluation for d >= 0.001;
C = rigorous argument-principle counting on boxes symmetric about the line (zero ordinates used ONLY to place C's boxes, which
makes C a map-based method — stated as such).
Prediction P2: A certifies both columns d in [0, 0.2] (on line + simple); B fails to clear d >= 0.001 on both within cap;
C needs boxes resolving the pair spacing (record evaluations/time).

## T3 L-function pilot (arithmetic side)
A non-self-dual primitive Dirichlet character (complex chi, small modulus): Atlas base layer (sech kernels; arithmetic side from
-L'/L) on a window near height ~10^3–10^4. Prediction P3: Atlas certifies a positive fraction (>= 50 %) of the window at
d >= 0.001 with rigorous replay. (Build-dependent; if the evaluator cannot be made rigorous, reported as NOT RUN, not as failure.)

## T4 Height scaling
Heights 1e4, 1e5, 1e6, 1e7; one 2-unit window each. Measure time per unit height for A (base + off-centre + propagation + t0 ladder)
and B (direct, as T1) to reach full coverage at d >= 0.001 (or coverage reached within 2 h per method per height).
Prediction P4: the ratio time(B)/time(A) does not decrease with height (Atlas's relative advantage holds or grows).
