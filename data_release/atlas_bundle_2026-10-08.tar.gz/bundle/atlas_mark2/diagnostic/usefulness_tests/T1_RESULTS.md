# T1 full-window head-to-head — RESULTS (2026-10-07), scored against PREDICTIONS.md P1 (+ Amendments 1-4)
| window | A Atlas v3 (full coverage + simplicity) | B direct (task d in [0.001,0.5]) | C' arg principle map-free (abs(delta)<=0.2) |
|---|---|---|---|
| [9000,9010] | COMPLETE, 3686 s, 105 certs, hardened replay 105/105, 0 seams, 0.82 GB | INCOMPLETE 992/1000 columns, 3436 s | 11 zeros on line+simple, 2.6 s |
| [9100,9110] | COMPLETE, 4357 s, 103/103, 0 seams, 0.87 GB | INCOMPLETE 990/1000, 4387 s | 11 zeros, 2.7 s |
| [9200,9210] | COMPLETE, 4127 s, 104/104, 0 seams, 0.72 GB | INCOMPLETE 995/1000, 3446 s | 12 zeros, 3.3 s |

P1 (A reaches full coverage in less wall time than B): **MET** by the registered metric — B never reached full coverage. In raw time A
and B are comparable (~1 h each per window); A also proves on-line + simple at d < 0.001, which B cannot.
Atlas time breakdown ([9000,9010]): ledgers 57 s, unions 17 s, propagation 115 s, ladder + replay + tiling ~3490 s over ~100 pieces
(each 0.1-wide bin gets its own bottom-level simplicity certificate).
C' (amendment; strongest classical competitor) is ~1000x faster than both on these windows.
