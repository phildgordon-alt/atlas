# T2 near-collision benchmark — RESULTS (2026-10-06), scored against PREDICTIONS.md (+ Amendments 1-4)
| case | A Atlas (v3) | B direct (d >= 0.001, 400k cap/col) | C arg principle, map-placed | C' arg principle, map-free |
|---|---|---|---|---|
| Lehmer [7005.06,7005.10] | on line + simple, 10 s (v3 A1; old ladder 531 s) | FAILED (stops at d 0.02-0.05) | 0.33 s | window [7000,7010]: 2.7 s |
| 663318 pair [663318.4,663318.6] | on line + simple over target x [0,0.5], 883 s end to end (ledgers 246 s, propagation 536 s, cases 29 s, ladder+replay+tiling ~70 s), 3 certificates, hardened replay 3/3, 0 seams, peak 1.03 GB | FAILED: 0/20 columns within cap, 1880 s | 24 s | 39 s |
P2: A certifies both (MET); B fails both (MET); C resolves the pair with one cut each (recorded). **P2 MET.**
Head-to-head reading: on near-collisions Atlas succeeds where direct evaluation fails, but the argument principle is ~20x faster
than Atlas end to end at 663318 (39 s vs 883 s). Atlas's time is dominated by the explicit-formula base ledgers and propagation
(~89%); the sign-change ladder itself took about a minute.
