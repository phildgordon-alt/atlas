# T4 height scaling — RESULTS (2026-10-07), scored against PREDICTIONS.md P4 + Amendment 1 (P4b) + Amendment 5 (Atlas = v4)
Windows [T, T+2]; 2 h cap per method per height; single process each, serial, same machine.

| T | A Atlas v4 (whole strip, on line + simple) | C' arg principle map-free (abs(delta) <= 0.2) | B direct (d in [0.001,0.5]) | B/A | C'/A |
|---|---|---|---|---|---|
| 1e4 | 5 s (closed, 0.14 GB) | 5 s (3 zeros) | 1635 s, INCOMPLETE 197/200 | 327 | 1.0 |
| 1e5 | 10 s (closed) | 5 s (2 zeros) | 2618 s, INCOMPLETE 189/200 | 262 | 0.5 |
| 1e6 | 10 s (closed) | 90 s (4 zeros) | CAPPED 7202 s | >= 720 | 9 |
| 1e7 | 10 s (closed) | 847 s (5 zeros) | CAPPED 7202 s | >= 720 | 85 |
(Wall times include process start-up; v4's in-process wall: 3.8 / 5.2 / 6.3 / 6.3 s. atlas_v3 at 1e4 did not finish in ~5300 s; Amendment 5.)

P4 (B/A non-decreasing with height): **NOT MET as stated** — 327 -> 262 from 1e4 to 1e5, then >= 720.
P4b (C'/A non-decreasing): **NOT MET as stated** — 1.0 -> 0.5 from 1e4 to 1e5, then 9 and 85.
Both failures are at the low end where all times are a few seconds (start-up dominated). From 1e5 to 1e7 Atlas v4's time is flat
(~6 s in process) while the argument principle grows ~170x and direct evaluation exceeds the cap. At 1e7 Atlas v4 is ~85x faster than
the map-free argument principle (which also only covered abs(delta) <= 0.2).
Caveats: v4 timings at 1e5-1e7 not blind (dev runs, disclosed in Amendment 5). Zero counts cross-checked (diagnostic): mpmath gives 2
zeros in [1e5, 1e5+2], matching.
Why flat: v4's certificates use sech rows (prime side at Re s > 1, height-insensitive) plus a handful of Z sign-change evaluations;
the argument principle needs many Taylor jets of zeta on the box edges, each ~sqrt(T).
