"""
Rigorous argument-principle zero counting for the Riemann zeta function.

Method (classical "certified winding number"):
  The rectangle boundary is split into straight pieces [a,b] with midpoint m,
  unit direction u and half-length r.  On each piece we use a rigorous Taylor
  model of zeta around m:

      zeta(m + h) = sum_{k=0}^{K} c_k h^k + E(h),  |h| <= r,
      c_k = zeta^{(k)}(m)/k!   (Arb ball jet at the exact point m),
      |E(h)| <= M q^{K+1}/(1-q),  q = r/R,  M >= sup_{|s-m|<=R} |zeta(s)|,

  where M is an upper bound from one Arb ball evaluation of zeta on the square
  of half-width R around m (the square contains the disc; Cauchy estimates
  |c_k| <= M/R^k give the tail bound).  Writing v = c_1 u r and
  rho = sum_{k=2}^{K} |c_k| r^k + tail, the image zeta([a,b]) is contained in
  the convex set  S = [c_0 - v, c_0 + v] + D(0, rho)  (Minkowski sum of a segment
  and a disc).  If dist(0, [c_0-v, c_0+v]) > rho (checked with Arb lower
  bounds), then 0 is not in S, so
    (i)  zeta has no zero on the piece, and
    (ii) S lies in an open half-plane through 0, so the continuous change of
         arg zeta along the piece has modulus < pi and equals the principal
         value Arg(zeta(b)/zeta(a)), which we enclose with Arb using rigorous
         enclosures of zeta(a), zeta(b) (Taylor polynomial at +-u r plus tail).
  Pieces that fail the test are bisected.  The winding number
  N = (1/2pi) sum Delta_arg is enclosed in an arb interval; the count is
  CERTIFIED only if that interval contains exactly one integer.

All arithmetic is Arb ball arithmetic (python-flint).  Box corners are the
exact binary values of the Python floats passed in.
"""
import math
import time

from flint import acb, acb_series, arb, ctx

PREC = 96
ctx.prec = PREC
ctx.cap = 40
R_MAX = 0.25  # max radius of Cauchy discs (Arb ball zeta hangs for radius ~0.5 at t~7e3)


class Stats:
    def __init__(self):
        self.jets = 0           # Arb Taylor-jet evaluations of zeta at exact points
        self.jet_terms = 0      # sum of jet lengths
        self.balls = 0          # Arb ball (sup-bound) evaluations of zeta
        self.pieces_ok = 0      # contour pieces certified
        self.pieces_split = 0   # contour pieces that had to be bisected
        self.patches_split = 0  # Taylor-model patches that had to be bisected
        self.t_start = time.time()

    @property
    def evals(self):
        return self.jets + self.balls

    def as_dict(self):
        return dict(jets=self.jets, jet_terms=self.jet_terms, balls=self.balls,
                    total_evals=self.evals, pieces_ok=self.pieces_ok,
                    pieces_split=self.pieces_split, patches_split=self.patches_split,
                    wall_s=round(time.time() - self.t_start, 3))


K_DEFAULT = 24        # Taylor order of the patch models
INNER_MAX = 600       # max sub-pieces inside one patch before the patch is split
INNER_DEPTH = 14      # max bisection depth inside one patch


def _patch_model(m, u, r, K, stats):
    """Rigorous Taylor model of g(x) = zeta(m + u x), x real, |x| <= r.
    Returns (a, eps): coefficients a_k (acb balls) and eps with
    |g(x) - sum a_k x^k| <= eps for |x| <= r;  or None if no finite bound."""
    z = acb_series([m, 1], prec=K + 1).zeta()
    c = z.coeffs()
    while len(c) < K + 1:
        c.append(acb(0))
    stats.jets += 1
    stats.jet_terms += K + 1
    R = 4 * r
    ball = acb(arb(m.real.mid(), R), arb(m.imag.mid(), R)).zeta()  # square contains disc |s-m|<=R
    stats.balls += 1
    if not ball.is_finite():
        return None
    M = abs(ball).upper()                  # M >= sup_{|s-m|<=R} |zeta(s)|
    q = arb(r) / arb(R)
    eps = (M * q ** (K + 1) / (1 - q)).upper()   # Cauchy: |c_k| <= M/R^k
    a = []
    uk = acb(1)
    for k in range(K + 1):
        a.append(c[k] * uk)
        uk *= u
    return a, eps


def _shift(a, delta):
    """Coefficients of x -> sum a_k (delta + x)^k (Taylor shift, Horner scheme)."""
    b = list(a)
    n = len(b)
    for i in range(n - 1):
        for j in range(n - 2, i - 1, -1):
            b[j] = b[j] + delta * b[j + 1]
    return b


def _test_piece(b, rr, eps):
    """b: shifted coefficients at the piece centre, rr: half-length (arb), eps: model error.
    Returns certified Delta-arg (arb) along the piece, or None."""
    K = len(b) - 1
    higher = arb(0)
    rk = rr * rr
    for k in range(2, K + 1):
        higher += abs(b[k]) * rk
        rk *= rr
    rho = higher + arb(eps)
    c0 = b[0]
    v = b[1] * rr
    av = abs(v)
    if av > 0:
        w = v.conjugate() * c0
        tau = -w.real / (av * av)
        if tau > 1 or tau < -1:
            # perpendicular foot certainly outside: nearest point is an endpoint
            dist = arb(min(abs(c0 - v).lower(), abs(c0 + v).lower()))
        else:
            dist = abs(w.imag) / av          # distance to the line: valid lower bound
    else:
        dist = abs(c0)
    if not (dist > rho):
        return None
    E = acb(arb(0, eps), arb(0, eps))
    def ev(x):
        s = acb(0)
        for k in range(K, -1, -1):
            s = s * x + b[k]
        return s + E
    za = ev(-rr)
    zb = ev(rr)
    d = (zb * za.conjugate()).arg()
    if not d.is_finite() or d.rad() > 0.05:
        return None
    return d


def segment_delta_arg(a, b, stats, K=K_DEFAULT, r_min=1e-12, max_patches=20000):
    """Certified continuous change of arg zeta along the axis-parallel segment a->b
    (also certifies zeta != 0 on it).  Returns (arb, ok)."""
    a = complex(a)
    b = complex(b)
    if a.real == b.real:
        u = acb(0, 1) if b.imag > a.imag else acb(0, -1)
        lo, hi = a.imag, b.imag
        vert = True
    elif a.imag == b.imag:
        u = acb(1) if b.real > a.real else acb(-1)
        lo, hi = a.real, b.real
        vert = False
    else:
        raise ValueError("segment must be axis-parallel")
    sgn = 1 if hi > lo else -1
    total = arb(0)
    # parameter x runs along the segment in direction u: point = a + u*(x - 0),
    # x in [0, L].  We store patches as (x0, x1) arb (exact dyadics).
    Lh = arb(abs(hi - lo))
    stack = [(arb(0), Lh)]
    npatch = 0
    while stack:
        x0, x1 = stack.pop()
        npatch += 1
        if npatch > max_patches:
            return total, False
        r = (x1 - x0) / 2
        if r < r_min:
            return total, False
        if 4 * r > R_MAX:
            stack.append((x0, x0 + r)); stack.append((x0 + r, x1))
            continue
        xm = x0 + r
        if vert:
            m = acb(a.real, arb(lo) + sgn * xm)
        else:
            m = acb(arb(lo) + sgn * xm, a.imag)
        model = _patch_model(m, u, r.mid(), K, stats)
        ok = model is not None
        sub_total = arb(0)
        if ok:
            coeffs, eps = model
            inner = [(-r, r, 0)]
            cnt = 0
            while inner:
                y0, y1, dep = inner.pop()
                cnt += 1
                yr = (y1 - y0) / 2
                ym = y0 + yr
                bsh = _shift(coeffs, ym) if ym != 0 else coeffs
                dlt = _test_piece(bsh, yr, eps)
                if dlt is not None:
                    sub_total += dlt
                    stats.pieces_ok += 1
                    continue
                stats.pieces_split += 1
                if dep >= INNER_DEPTH or cnt > INNER_MAX:
                    ok = False
                    break
                inner.append((y0, ym, dep + 1)); inner.append((ym, y1, dep + 1))
        if ok:
            total += sub_total
        else:
            stats.patches_split += 1
            stack.append((x0, xm)); stack.append((xm, x1))
    return total, True


_cache = {}


def _seg(a, b, stats, K):
    key = (a, b, K)
    rkey = (b, a, K)
    if key in _cache:
        return _cache[key]
    if rkey in _cache:
        d, ok = _cache[rkey]
        return -d, ok
    d, ok = segment_delta_arg(a, b, stats, K=K)
    _cache[key] = (d, ok)
    return d, ok


def count_zeros(t0, t1, sig0, sig1, stats=None, K=None, verbose=False):
    """Certified number of zeros (with multiplicity) of zeta in the open rectangle
    sig0 < Re s < sig1, t0 < Im s < t1, together with a proof that zeta has no
    zero on its boundary.  Returns dict with 'N' (int or None on failure)."""
    if stats is None:
        stats = Stats()
    if K is None:
        K = K_DEFAULT
    corners = [complex(sig0, t0), complex(sig1, t0), complex(sig1, t1), complex(sig0, t1)]
    tot = arb(0)
    ok_all = True
    for i in range(4):
        d, ok = _seg(corners[i], corners[(i + 1) % 4], stats, K)
        if not ok:
            ok_all = False
            break
        tot += d
    res = dict(box=(t0, t1, sig0, sig1), N=None, enclosure=None, contour_zero_free=ok_all)
    if ok_all:
        w = tot / (2 * arb.pi())
        res['enclosure'] = str(w)
        n = round(float(w.mid()))
        if w.rad() < 0.5 and w.contains(n) and not w.contains(n - 1) and not w.contains(n + 1):
            res['N'] = n
    if verbose:
        print('count_zeros', res, stats.as_dict(), flush=True)
    return res


def certify_pair(t0, t1, d, eps_list=None, stats=None, verbose=True, min_h=1e-7):
    """Certify 'all zeros of zeta with t0 <= Im s <= t1, |Re s - 1/2| <= d lie on the
    critical line and are simple' (closed box: the boundary is certified zero-free)."""
    if stats is None:
        stats = Stats()
    s0, s1 = 0.5 - d, 0.5 + d
    log = {}
    total = count_zeros(t0, t1, s0, s1, stats, verbose=verbose)
    log['total'] = total
    if total['N'] is None:
        log['certified'] = False
        log['stats'] = stats.as_dict()
        return log
    # strip check (right strip, left by symmetry s -> 1 - conj(s) of xi)
    if eps_list is None:
        eps_list = [d / 2, d / 20, d / 200, 1e-4]
    strips = []
    for eps in eps_list:
        if eps >= d:
            continue
        st = Stats()
        rs = count_zeros(t0, t1, 0.5 + eps, s1, st, verbose=verbose)
        strips.append(dict(eps=eps, N=rs['N'], stats=st.as_dict()))
        stats.jets += st.jets; stats.balls += st.balls; stats.jet_terms += st.jet_terms
        stats.pieces_ok += st.pieces_ok; stats.pieces_split += st.pieces_split; stats.patches_split += st.patches_split
        if rs['N'] != 0:
            break
    log['strips'] = strips
    good = [s['eps'] for s in strips if s['N'] == 0]
    log['eps_certified'] = min(good) if good else None
    # bisection in t on symmetric boxes
    leaves = []
    queue = [(t0, t1, total['N'])]
    failed = False
    while queue:
        a, b, n = queue.pop()
        if n <= 1:
            leaves.append((a, b, n))
            continue
        if b - a < min_h:
            failed = True
            leaves.append((a, b, n))
            break
        done = False
        for off in (0.0, 0.1, -0.1, 0.23, -0.23, 0.37, -0.37):
            c = a + (b - a) * (0.5 + off)
            lo = count_zeros(a, c, s0, s1, stats, verbose=verbose)
            if lo['N'] is None:
                continue
            hi = count_zeros(c, b, s0, s1, stats, verbose=verbose)
            if hi['N'] is None:
                continue
            assert lo['N'] + hi['N'] == n, (lo, hi, n)
            queue.append((a, c, lo['N']))
            queue.append((c, b, hi['N']))
            done = True
            break
        if not done:
            failed = True
            leaves.append((a, b, n))
            break
    leaves.sort()
    log['leaves'] = leaves
    log['certified'] = (not failed) and all(l[2] <= 1 for l in leaves)
    log['zeros_on_line_simple'] = sum(l[2] for l in leaves) if log['certified'] else None
    log['stats'] = stats.as_dict()
    return log


def count_zeros_integral(t0, t1, sig0, sig1):
    """Independent cross-check: N = (1/2 pi i) \\oint zeta'/zeta ds with Arb's
    rigorous integrator acb.integral (zeta'/zeta is meromorphic, so non-analytic
    balls automatically give non-finite values).  Practical only at low height."""
    def f(x, analytic):
        j = acb_series([x, 1], prec=2).zeta().coeffs()
        return j[1] / j[0]
    corners = [acb(sig0, t0), acb(sig1, t0), acb(sig1, t1), acb(sig0, t1)]
    tot = acb(0)
    for i in range(4):
        tot += acb.integral(f, corners[i], corners[(i + 1) % 4])
    return tot / (2 * acb.pi() * acb(0, 1))
