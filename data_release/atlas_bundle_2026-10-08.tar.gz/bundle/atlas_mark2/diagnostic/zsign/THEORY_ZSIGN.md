# Sign changes of Hardy's Z as on-line lower bounds in the slab LP — theory (written before coding, 2026-10-06)

## 0. Setting (unchanged from lehmer_7000/ladder/verify.py, lslab.py)

Window W = [wlo, whi] (heights). Every zero of xi with height in W is an **atom** a = (x, d, f):
x = height, d = |Re rho - 1/2| >= 0, f = 1 for an on-line zero (d = 0; a zero of multiplicity k is k atoms, or one f = 2
atom at d = 0 in an "off" box), f = 2 for an off-line pair {rho, 1 - conj(rho)} (d > 0).

Inherited facts (proved upstream, trusted here exactly as in the old ladder):

* (H_model) every atom lies in one of the model's var boxes: "on" [lo,hi] x {0} (f = 1) or "off" [lo,hi] x [0,cap] (f = 2).
* (H_rows) for each test-function row j with per-atom kernel U_j (sech rows: Re h_a; Lorentzian rows: uL),
  the window sum S_j = sum_a f_a U_j(x_a, d_a) satisfies S_j <= Ehi_j + [j Lorentzian] Fa_j and S_j >= Elo_j - Fa_j.
* (H_count) N := sum_a f_a <= Nwin.

Hypothesis to refute: an off-line pair a* = (x*, d*, 2) with (x*, d*) in the candidate region R = [x0,x1] x [d0,d1], **d* > 0**.

## 1. New input: rigorous sign changes of Z

Z(t) = e^{i theta(t)} zeta(1/2 + it), theta(t) = Im logGamma(1/4 + it/2) - (t/2) log pi.  Z is real-analytic and real on R,
e^{i theta} never vanishes, so the zeros of Z on R are exactly the heights of on-line zeros, with the same multiplicity
(d/dt zeta(1/2+it) = i zeta'(s), so orders agree). Any branch of logGamma gives the same e^{i theta} (branches differ by 2 pi i k).

**Lemma 1.** If Arb balls give Z(t1) > 0 > Z(t2) (or the reverse) strictly, t1 < t2, then the open interval I = (t1, t2)
contains on-line zeros of total multiplicity n_I that is **odd**, in particular **n_I >= 1**.
*Proof.* Z has finitely many zeros in [t1, t2] (analytic, not identically 0), none at t1, t2. Z keeps its sign across even-order
zeros and flips across odd-order ones; the sign flips overall, so the number of odd-order zeros is odd. ∎

We use only n_I >= 1 (never more per interval). The data are intervals I_1..I_m with **I_i ⊂ W** (needed: n_i counts atoms, i.e.
window zeros; an interval reaching outside W could have its zero outside W, which the rows treat as far). Write
n_i = sum over atoms with d = 0 and x in I_i of f_a  (= number of on-line zeros in I_i with multiplicity) >= 1.

## 2. Certificate

Unknowns: yup_j, ylow_j >= 0, c_j = yup_j - ylow_j, yc >= 0 (count multiplier), and **w_i >= 0, one per sign-change interval**.

    Phi(x,d,f)   = f (yc + sum_j c_j U_j(x,d))                        (same as verify.phi_box)
    chi_i(x,d)   = 1 if d = 0 and x in I_i, else 0
    Phi_w(x,d,f) = Phi(x,d,f) - f sum_i w_i chi_i(x,d)
    K            = sum_j [ yup_j (Ehi_j + [L]Fa_j) - ylow_j (Elo_j - Fa_j) ] + yc (Nwin - 2)   (same as verify.check)

**Theorem.** Assume (H_model), (H_rows), (H_count), Lemma-1 intervals I_i ⊂ W, w_i >= 0, and
* (R) Phi_w(x,d,f) >= 0 at every point of every var box (with that box's f);
* (C) Phi(x,d,2) - K - 2 yc + sum_i w_i > 0 for every (x,d) in R with d > 0.

Then no off-line pair of zeros has (height, displacement) in R.

*Proof.* Suppose a* exists; let A be the set of all atoms (a* included).
(i) sum_j c_j S_j = sum_j yup_j S_j - ylow_j S_j <= K - yc (Nwin - 2)            by (H_rows), yup, ylow >= 0.
(ii) sum_{a in A} Phi(a) = sum_j c_j S_j + yc N <= K - yc(Nwin-2) + yc Nwin = K + 2 yc   by (H_count), yc >= 0.
(iii) sum_{a in A} f_a sum_i w_i chi_i(a) = sum_i w_i n_i >= sum_i w_i        (exchange of finite sums; Lemma 1; w_i >= 0).
     chi_i(a*) = 0 because d* > 0, so this sum runs over A \ {a*} only.
(iv) Hence Phi(a*) + sum_{a != a*} Phi_w(a) = sum_A Phi - sum_i w_i n_i <= K + 2 yc - sum_i w_i.
(v) By (H_model) every a != a* lies in a var box, so Phi_w(a) >= 0 by (R). Therefore Phi(a*) <= K + 2yc - sum_i w_i,
    contradicting (C). ∎

**Reading.** The new multipliers w_i are dual variables for the primal constraints "on-line mass in I_i >= 1". In the remainder
they *raise* the requirement on the dual function over the interval (Phi >= f w_i on I_i x {0}), and the candidate margin gains
sum w_i. Equivalently: the guaranteed zero in I_i is subtracted from the row upper bounds with its worst-case (minimum over I_i)
contribution — exactly how Büthe / Hiary–Ireland–Kyi subtract known zeros, but here the zeros are discovered (sign changes), not input.

Note on the phrasing "allow the dual combination to be negative on covered on-line bins": that is **not sound** by itself.
An interval with one proven zero may contain 3, 5, ... zeros, and any extra on-line zero there still enters with Phi(a); if
Phi < 0 on I_i the extra zeros make the left side of (iv) arbitrarily negative. Only the Phi_w form above (subtract f w_i
for *every* atom in I_i, credit w_i once) is sound. With yc > 0, the count term already lets sum_j c_j U_j dip to -yc;
the sign changes let it be lower by w_i/f *relative to the credit*, never below the remainder requirement.

## 3. Multiplicity, double counting, consistency

* **Multiplicity.** A multiple on-line zero in I_i is k atoms (or an f = 2 atom at d = 0): each is charged f w_i in Phi_w,
  credit is w_i * 1 only. Sound for any k >= 1.
* **Overlapping / duplicate intervals.** (iii) holds for any family of intervals (each n_i >= 1 individually), *provided the
  remainder subtracts the SUM of w_i over all intervals containing the point*. The verifier does exactly that (sum, never max).
  Duplicating an interval therefore gains nothing (Phi >= 2w required, 2w credited). A verifier subtracting only the max would
  be unsound under duplication — negative control C3 below exercises this. The generator emits disjoint open intervals anyway.
* **Endpoints.** Z(t1), Z(t2) != 0 strictly, so I_i is open; the verifier treats I_i as the closed [t1,t2] when deciding
  whether a box meets it (subtracting more is conservative since w_i >= 0).
* **Nwin.** Unchanged and still an upper bound on the total count N including the guaranteed zeros; nothing is added to it.
  The lower bounds enter only through w. No zero is counted twice: the candidate is off-line (chi = 0), every other atom
  appears once in sum_A.
* **Far allowance.** Fa_j bounds zeros outside W. All I_i ⊂ W, so the sign-change zeros are window atoms and never also part
  of a far bound. (Using sign changes outside W to sharpen Fa would be a separate extension; not done.)
* **Candidate at d = 0.** The old check also excluded "a pair at d = 0" (a double on-line zero). The new theorem claims only
  d > 0 (what RH needs). Numerically the box enclosure over [x0,x1] x [d0,d1] is still used, so the computation is the
  closed-box one; the *claim* for the bottom level is 0 < d <= d1. Excluding double zeros inside I_i would need parity (n_i odd).
* **Reduction.** With m = 0 the conditions are exactly verify.check's (rem: Phi >= 0; cand: Phi - K - 2yc > 0).

## 4. What the verifier checks rigorously (Arb, verify_zs.py)

1. Each interval: Z(t1), Z(t2) enclosures with strictly opposite signs (recomputed, independent formula in the replay:
   e^{i theta} = Gamma(1/4+it/2)/|Gamma(1/4+it/2)| * pi^{-it/2}, different precision); t1 < t2; wlo <= t1, t2 <= whi; w_i >= 0.
2. (R) over every var box by recursive bisection: Arb lower bound of Phi over the box minus f * sum_{i: box has d0 = 0 and
   [b0,b1] ∩ [t1_i,t2_i] != ∅} w_i must be >= 0.
3. (C) over the candidate box: Arb lower bound of Phi(.,.,2) - K - 2yc + sum_i w_i > 0 (w_i entered as exact binary64 values).

## 5. Trust ledger

Proved here (Arb): Lemma-1 sign changes; (R); (C); the Theorem's algebra.
Trusted / inherited (same as old ladder): case model (var boxes, caps — base layer + propagation ledgers), sech row enclosures
Elo/Ehi and their far bounds F, Nwin (Trudgian S(T) bound), farL Lorentzian far allowance (Trudgian + ledger c_in), Arb/flint
correctness. Lorentzian row enclosures are recomputed in Arb (lp.Phi) as before.
