#!/bin/sh
# Atlas open-data bundle: quick verification of a representative subset (a few minutes, one process at a time, nice 19).
# usage: PY=/path/to/python3.12-with-python-flint-0.9.0 ./quick_verify.sh
# Never overwrites a stored record: v4 replays write <run>/replay_bundle/; the degree-2 replay runs on a scratch copy in $OUT; unions go to $OUT.
set -u
B=$(cd "$(dirname "$0")" && pwd); cd "$B"
PY=${PY:-python3}; OUT=${OUT:-$B/quick_verify_out}; mkdir -p "$OUT"
export PYTHONDONTWRITEBYTECODE=1
NT=$B/atlas_mark2/diagnostic/new_territory; V4R=$B/atlas_mark2/diagnostic/atlas_v4/runs
FAIL=0; ok() { echo "  OK   $1"; }; bad() { echo "  FAIL $1"; FAIL=$((FAIL+1)); }
T0=$(date +%s)

echo "[0] environment"
$PY -c "import flint, numpy, scipy, mpmath, sys; print('  python', sys.version.split()[0], '| python-flint', flint.__version__, '| numpy', numpy.__version__, '| scipy', scipy.__version__, '| mpmath', mpmath.__version__)" || { echo "python-flint missing: set PY"; exit 2; }

echo "[1] SHA256SUMS (every bundled file)"
if command -v sha256sum >/dev/null 2>&1; then S="sha256sum -c --quiet"; else S="shasum -a 256 -c --quiet"; fi
if nice -n 19 $S SHA256SUMS >"$OUT/sha_check.txt" 2>&1; then ok "all files match SHA256SUMS"; else bad "SHA256SUMS mismatch (see $OUT/sha_check.txt)"; fi

echo "[2] zeta, atlas_v4: independent replays (models + rows rebuilt, pinned verifier plain + hardened, exact tiling, claim B)"
for r in w7000.00/lehmer_full_pair w7000.00/c7002 w6820046.00/rosser w663310.00/t2_663318; do
  if nice -n 19 $PY tools/replay_v4.py "$V4R/$r" replay_bundle >"$OUT/v4_$(basename $r).txt" 2>&1; then ok "$r: $(tail -1 "$OUT/v4_$(basename $r).txt")"
  else bad "$r: $(tail -1 "$OUT/v4_$(basename $r).txt")"; fi
done
grep -q "release/bundle\|bundle/atlas_mark2" "$V4R/w7000.00/lehmer_full_pair/replay_bundle/replay4.log" 2>/dev/null && grep "^\[bundle\]" "$V4R/w7000.00/lehmer_full_pair/replay_bundle/replay4.log" | head -1 | sed 's/^/  /'

echo "[3] L(s, 11.a): fresh-process replay of chunk [0, 10] (rows recomputed, A = 1.2 endpoint check, verifier plain + hardened; ~1-2 min)"
if sh tools/replay_deg2.sh deg2 runs/contig/c_0_10 0 10 "$OUT/replay" >"$OUT/deg2_c_0_10.txt" 2>&1 && \
   $PY -c "import json,sys; s=json.load(open('$OUT/replay/deg2/runs/contig/c_0_10/replay.json'))['summary']; print(s['closed'], s['passed_both'], s['certificates']); sys.exit(0 if s['closed'] and s['passed_both']==s['certificates'] else 1)" >"$OUT/deg2_c_0_10.sum" 2>&1
then ok "11.a [0,10]: closed, passed_both/certificates = $(cut -d' ' -f2,3 "$OUT/deg2_c_0_10.sum" | tr ' ' '/') (replayed on a scratch copy in $OUT/replay)"; else bad "11.a [0,10] replay (see $OUT/deg2_c_0_10.txt)"; fi

echo "[3b] zeta_K/zeta, d_K = -239 (tollis ADDENDUM 2, launched through run_ext2.py): fresh-process replay of chunk [100, 110] (~1-2 min)"
if sh tools/replay_deg2.sh tollis+ext2 runs/contig/K239/c_100_110 100 110 "$OUT/replay" >"$OUT/tollis_K239_c_100_110.txt" 2>&1 && \
   $PY -c "import json,sys; s=json.load(open('$OUT/replay/tollis/runs/contig/K239/c_100_110/replay.json'))['summary']; print(s['closed'], s['passed_both'], s['certificates']); sys.exit(0 if s['closed'] and s['passed_both']==s['certificates']==20 else 1)" >"$OUT/tollis_K239_c_100_110.sum" 2>&1
then ok "K239 [100,110]: closed, passed_both/certificates = $(cut -d' ' -f2,3 "$OUT/tollis_K239_c_100_110.sum" | tr ' ' '/') (via run_ext2.py; scratch copy in $OUT/replay)"; else bad "K239 [100,110] replay (see $OUT/tollis_K239_c_100_110.txt)"; fi

echo "[4] 389.a1 / 37.a1 central zero"
(cd "$NT/ec389a" && nice -n 19 $PY -B modsym.py verify 389.a1 logs/modsym/389.a1.json) >"$OUT/modsym.txt" 2>&1
grep -q '"verdict": "L_E_1_IS_ZERO_PROVED"' "$OUT/modsym.txt" && ok "389.a1 L(E,1) = 0 (modular-symbol certificate re-verified in exact Fractions)" || bad "modsym verify"
(cd "$NT/ec389a" && nice -n 19 $PY -B central.py) >"$OUT/central389.txt" 2>&1
grep -q '"Lambda_pp_nonzero": true' "$OUT/central389.txt" && ok "389.a1 Lambda''(1) != 0 => central order exactly 2" || bad "389 central"
(cd "$NT/ec37a" && nice -n 19 $PY -B central.py) >"$OUT/central37.txt" 2>&1
grep -q '"nonzero": true' "$OUT/central37.txt" && ok "37.a1 Lambda'(1) != 0 => central zero simple" || bad "37 central"

echo "[5] exact unions over the STORED replay records (Fractions), compared with the stored union logs where they exist"
U=$NT/tollis/union.py
union() { name=$1; lo=$2; hi=$3; ref=$4; shift 4
  nice -n 19 $PY -B "$U" "$lo" "$hi" "$@" >"$OUT/union_$name.json" 2>&1 || { bad "union $name"; return 1; }
  res=$($PY -c "import json; d=json.load(open('$OUT/union_$name.json')); print(d['covered'] and d['all_chunks_closed'], d['cells'], d['distinct_sign_changes_in_range'])")
  if [ -n "$ref" ]; then same=$($PY -c "import json; print(json.load(open('$OUT/union_$name.json'))==json.load(open('$ref')))"); else same="(no stored log)"; fi
  case "$res" in True*) ok "$name [$lo,$hi]: covered, cells/sign changes = $(echo $res | cut -d' ' -f2,3 | tr ' ' '/'), identical to stored log: $same";; *) bad "$name: $res"; return 1;; esac; }
D=""; for k in $(seq 0 29); do D="$D runs/contig/c_$((10*k))_$((10*k+10))"; done
(cd "$NT/deg2" && union 11a 0 300 "" $D) || FAIL=$((FAIL+1))
# the stored 11.a record (runs/contig/UNION_0_300.json, written later from the per-chunk replay records) has its own format: compare fields
if $PY -c "
import json,os,sys
u=json.load(open('$OUT/union_11a.json')); r=json.load(open('$NT/deg2/runs/contig/UNION_0_300.json'))
pc=lambda L: [(os.path.basename(c['chunk']), tuple(c['target']), c['closed'], c['certificates'], c['passed_both']) for c in L]
ok = (u['covered'], u['gaps'], u['cells'], u['all_chunks_closed'], u['distinct_sign_changes_in_range'], len(u['per_chunk'])) == \
     (r['covered'], r['gaps'], r['cells'], r['all_chunks_closed'], r['distinct_sign_change_intervals_in_targets'], r['chunks']) and pc(u['per_chunk']) == pc(r['per_chunk'])
sys.exit(0 if ok else 1)" >"$OUT/union_11a_vs_record.txt" 2>&1
then ok "11a [0,300]: recomputed union agrees with the stored record UNION_0_300.json (cells, gaps, 388, per-chunk verdicts)"; else bad "11a union vs UNION_0_300.json (see $OUT/union_11a_vs_record.txt)"; fi
D="runs/val_0_10"; for k in $(seq 1 19); do D="$D runs/chunks/c_$((10*k))_$((10*k+10))"; done
(cd "$NT/ec37a" && union 37a 0 200 "$NT/ec37a/logs/union.json" $D) || FAIL=$((FAIL+1))
D=""; for k in $(seq 0 19); do D="$D runs/chunks/c_$((10*k))_$((10*k+10))"; done
(cd "$NT/ec389a" && union 389a 0 200 "$NT/ec389a/logs/union_0_200.json" $D) || FAIL=$((FAIL+1))
for K in K23 K31 K44 K59 K76 K83 K87 K104 K107 K108 K116 K135 K139 K140 K152 K172 K175 K199 K200 K204 K211 K212 K216 K231 K239; do
  D=""; for k in $(seq 0 10); do D="$D runs/contig/$K/c_$((10*k))_$((10*k+10))"; done
  (cd "$NT/tollis" && union "tollis_$K" 0 110 "$NT/tollis/logs/union_${K}_0_110.json" $D) || FAIL=$((FAIL+1))
done
D=""; for k in $(seq 0 19); do D="$D runs/contig/K23/c_$((10*k))_$((10*k+10))"; done
(cd "$NT/tollis" && union tollis_K23_200 0 200 "$NT/tollis/logs/union_K23_0_200.json" $D) || FAIL=$((FAIL+1))

echo "[6] Lean: certificate-file audit (only if the Lean project has been built; see README)"
if [ -x "$B/lean/.lake/build/bin/atlas_audit" ]; then
  (cd "$B/lean" && nice -n 19 .lake/build/bin/atlas_audit audit/data/deg2.txt audit/data/ec37a.txt audit/data/ec389a.txt audit/data/tollis.txt audit/data/tollis_extra.txt audit/data/tollis_ext_unions.txt audit/data/v4_acceptance.txt audit/data/v4_other.txt audit/data/deg2_nc.txt audit/data/ec37a_nc.txt audit/data/ec389a_nc.txt audit/data/tollis_nc.txt) >"$OUT/lean_audit.txt" 2>&1 \
    && ok "atlas_audit exit 0 (0 violations outside the *_nc control datasets)" || bad "atlas_audit (see $OUT/lean_audit.txt)"
else echo "  SKIP atlas_audit not built (lean/: lake build atlas_audit)"; fi

echo "done in $(( $(date +%s) - T0 )) s; failures: $FAIL; outputs in $OUT"
exit $FAIL
