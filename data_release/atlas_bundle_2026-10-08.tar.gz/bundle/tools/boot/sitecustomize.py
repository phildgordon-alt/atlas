# Bundle bootstrap (not part of the original pipeline). Active only when ATLAS_BUNDLE_DIAG is set.
# atlas_v4/lib/model4.py falls back to the hard-coded path /Users/kiosk/atlas_mark2/diagnostic when it runs from a copy in
# replay_check/ (it does on every replay). Pre-importing the BUNDLED engine modules makes `import integer_mechanism` and
# `import certify_sech_interferometer` resolve to the bundle copies on any host, including the original one.
import os, sys
_d = os.environ.get('ATLAS_BUNDLE_DIAG')
if _d:
    import importlib.util
    for _m in ('integer_mechanism', 'certify_sech_interferometer'):
        if _m not in sys.modules:
            _s = importlib.util.spec_from_file_location(_m, os.path.join(_d, _m + '.py'))
            _mod = importlib.util.module_from_spec(_s); sys.modules[_m] = _mod; _s.loader.exec_module(_mod)
    sys.stderr.write('[bundle] engine modules: ' + ', '.join(sys.modules[m].__file__ for m in ('integer_mechanism', 'certify_sech_interferometer')) + '\n')
