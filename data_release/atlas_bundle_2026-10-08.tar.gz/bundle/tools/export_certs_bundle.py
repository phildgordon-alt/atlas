#!/usr/bin/env python3
"""Bundle wrapper for lean/export/export_certs.py (DIAG hard-coded to /Users/kiosk/atlas_mark2/diagnostic). Executes the unmodified
source with only that literal replaced by the bundled tree.  usage: python3 tools/export_certs_bundle.py OUTDIR
Note: the bundle holds a subset of the v4 runs the original export saw (v4_other: only the 4 T4 runs and lehmer_full_pair). Every
other dataset (deg2, ec37a, ec389a, tollis, tollis_extra = all 19 fields -87 ... -239, v4_acceptance and the *_nc files) reproduces
lean/audit/data/*.txt byte for byte (checked 2026-10-08 after tollis ADDENDUM 2). For the union targets of the 19 fields see
tools/export_tollis_unions.py (dataset tollis_ext_unions, also reproduced byte for byte)."""
import sys
from pathlib import Path
B = Path(__file__).resolve().parents[1]
OLD = "DIAG = '/Users/kiosk/atlas_mark2/diagnostic'"
src = (B / 'lean' / 'export' / 'export_certs.py').read_text(); assert src.count(OLD) == 1
assert len(sys.argv) > 1 and Path(sys.argv[1]).resolve() != (B / 'lean' / 'audit' / 'data').resolve(), 'give a NEW output dir'
g = {'__name__': '__main__', '__file__': str(B / 'lean' / 'export' / 'export_certs.py')}
exec(compile(src.replace(OLD, 'DIAG = %r' % str(B / 'atlas_mark2' / 'diagnostic')), g['__file__'], 'exec'), g)
