#!/usr/bin/env python3
"""Bundle-only driver for the Lean audit: exact unions for the 19 Tollis fields outside the six pre-registered ones.

The unmodified exporter (lean/export/export_certs.py = formal/export/export_certs.py) puts the fields d_K = -87 ... -239 into the
dataset `tollis_extra` with one exact-tiling TARGET per run but no union targets (it was written while those fields were still
running). This driver loads that exporter's source UNCHANGED (only the DIAG path literal is replaced, as in export_certs_bundle.py),
does not run its main(), and calls its own deg2_dataset() to write one extra dataset, `tollis_ext_unions`:
  every core window and every [0,110] chunk of the 19 fields (the same certificate records as tollis_extra), one TARGET per run, and
  one union TARGET union_K<d>_0_110 = [0,110] x [0,1/2] per field.
usage: python3 tools/export_tollis_unions.py OUTDIR [DIAG]
  DIAG defaults to the bundled tree atlas_mark2/diagnostic; pass /Users/kiosk/atlas_mark2/diagnostic to export from the original host.
Then: atlas_audit OUTDIR/tollis_ext_unions.txt   (expected: 0 violations, every target covered)."""
import sys, os, glob
from pathlib import Path
B = Path(__file__).resolve().parents[1]
OLD = "DIAG = '/Users/kiosk/atlas_mark2/diagnostic'"
SRC = B / 'lean' / 'export' / 'export_certs.py'
src = SRC.read_text(); assert src.count(OLD) == 1
out = sys.argv[1]
diag = sys.argv[2] if len(sys.argv) > 2 else str(B / 'atlas_mark2' / 'diagnostic')
g = {'__name__': 'export_certs_lib', '__file__': str(SRC)}
src = src.replace(OLD, 'DIAG = %r' % diag)
src = src.replace("OUT = sys.argv[1] if len(sys.argv) > 1 else", "OUT = %r if True else" % os.path.abspath(out), 1)
exec(compile(src, str(SRC), 'exec'), g)

R = g['NT'] + '/tollis'
PRE = ('K23', 'K31', 'K44', 'K59', 'K76', 'K83')
EXT = ['K87', 'K104', 'K107', 'K108', 'K116', 'K135', 'K139', 'K140', 'K152', 'K172', 'K175', 'K199', 'K200', 'K204', 'K211',
       'K212', 'K216', 'K231', 'K239']
def done(d): return os.path.isdir(d) and os.path.exists(os.path.join(d, 'replay.json'))
runs, unions = [], []
for k in EXT:
    core = [d for d in sorted(glob.glob(R + '/runs/core/%s_*' % k)) if os.path.isdir(d)]
    assert len(core) == 1 and done(core[0]), (k, core)
    ch = g['chunks'](R + '/runs/contig/' + k, 0, 110)
    assert all(done(d) for d in ch), k
    runs += core + ch
    unions.append((0, 110, ch))
g['deg2_dataset']('tollis_ext_unions', R, runs, unions, 0)
