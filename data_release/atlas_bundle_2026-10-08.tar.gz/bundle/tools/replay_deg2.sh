#!/bin/sh
# Bundle wrapper: fresh-process replay of one degree-2-family run (deg2 | ec37a | ec389a | tollis).
# The run directory is first COPIED to a scratch directory (without its stored replay.json) and replayed there, because some
# pipeline versions (deg2) always write RUNDIR/replay.json. The stored records in the bundle are never touched.
# usage: tools/replay_deg2.sh PIPELINE RUNDIR_RELATIVE_TO_PIPELINE TLO THI [SCRATCH=${TMPDIR:-/tmp}/atlas_replay]
# e.g.   tools/replay_deg2.sh tollis runs/contig/K23/c_0_10 0 10      -> SCRATCH/tollis/runs/contig/K23/c_0_10/replay.json
# PIPELINE "tollis+ext2" (the 15 fields d_K = -116 ... -239 of tollis ADDENDUM 2): same tollis directory, but the frozen
# replay_deg2.py is started through the launcher run_ext2.py, which registers those fields in memory (fields_ext2.py) and then
# runs replay_deg2.py unchanged as __main__, exactly as run_targets_ext2.sh did:
#        tools/replay_deg2.sh tollis+ext2 runs/contig/K239/c_100_110 100 110
set -e
B=$(cd "$(dirname "$0")/.." && pwd); PY=${PY:-python3}
PL=$1; LAUNCH=""
case "$PL" in *+ext2) PL=${PL%+ext2}; LAUNCH=run_ext2.py;; esac
SCR=${5:-${TMPDIR:-/tmp}/atlas_replay}; DST="$SCR/$PL/$2"
P="$B/atlas_mark2/diagnostic/new_territory/$PL"
rm -rf "$DST"; mkdir -p "$DST"
(cd "$P/$2" && tar cf - --exclude ./replay.json --exclude './replay_*.json' .) | (cd "$DST" && tar xf -)
cd "$P"
echo "replaying $PL/$2 in $DST${LAUNCH:+ (via $LAUNCH)}" >&2
PYTHONDONTWRITEBYTECODE=1 exec nice -n 19 "$PY" -B -u $LAUNCH replay_deg2.py "$DST" "$3" "$4"
