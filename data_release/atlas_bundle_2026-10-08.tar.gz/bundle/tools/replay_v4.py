#!/usr/bin/env python
"""Bundle wrapper for atlas_v4/replay_target4.py (the copied file is NOT modified).
usage: python tools/replay_v4.py atlas_mark2/diagnostic/atlas_v4/runs/w7000.00/lehmer_full_pair [OUTNAME=replay_bundle]
What it changes, in memory only: atlas_v4.PY (hard-coded venv path) -> this interpreter; replay_target4.TILING (hard-coded path
outside atlas_mark2) -> external/exact_tiling_check.py (same sha 0868990e..., still checked by replay_target4); the replay subprocess
gets PYTHONPATH=tools/boot so the bundled engine modules are used (see boot/sitecustomize.py).
Never use OUTNAME=replay_check: that is the stored original record (replay_target4 deletes and recreates OUTNAME)."""
import os, sys
from pathlib import Path
B = Path(__file__).resolve().parents[1]
DIAG = B / 'atlas_mark2' / 'diagnostic'; V4 = DIAG / 'atlas_v4'
run = Path(sys.argv[1]).resolve(); out = sys.argv[2] if len(sys.argv) > 2 else 'replay_bundle'
assert out != 'replay_check', 'refusing to overwrite the stored replay record'
os.environ['ATLAS_BUNDLE_DIAG'] = str(DIAG)
os.environ['PYTHONPATH'] = os.pathsep.join([str(B / 'tools' / 'boot'), str(DIAG)] + ([os.environ['PYTHONPATH']] if os.environ.get('PYTHONPATH') else []))
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'; sys.dont_write_bytecode = True
sys.path.insert(0, str(V4))
import atlas_v4 as D
D.PY = sys.executable
import replay_target4 as RT
RT.TILING = str(B / 'external' / 'exact_tiling_check.py')
sys.argv = ['replay_target4.py', str(run), out]
RT.main()
