#!/usr/bin/env python
"""Bundle wrapper for new_territory/crosscheck_11a/run.py. ap_lambda.py hard-codes
AP_DIR = '/Users/kiosk/atlas_mark2/diagnostic/usefulness_tests/argprinciple'; this wrapper executes the UNMODIFIED source of ap_lambda.py
with only that string literal replaced by the bundled directory (the sha pin of zeta_argprinciple.py is still asserted), then runs
run.py unchanged via runpy.  usage: python tools/run_crosscheck.py T_LO T_HI OUTDIR [run.py options]
WARNING: the full [0, 300] run took 7284 s; OUTDIR must not be runs/full (the stored record)."""
import sys, os, types, runpy
from pathlib import Path
B = Path(__file__).resolve().parents[1]; DIAG = B / 'atlas_mark2' / 'diagnostic'; CC = DIAG / 'new_territory' / 'crosscheck_11a'
OLD = "AP_DIR = '/Users/kiosk/atlas_mark2/diagnostic/usefulness_tests/argprinciple'"
src = (CC / 'ap_lambda.py').read_text(); assert src.count(OLD) == 1
mod = types.ModuleType('ap_lambda'); mod.__file__ = str(CC / 'ap_lambda.py'); sys.modules['ap_lambda'] = mod
sys.path.insert(0, str(CC)); sys.dont_write_bytecode = True
exec(compile(src.replace(OLD, 'AP_DIR = %r' % str(DIAG / 'usefulness_tests' / 'argprinciple')), mod.__file__, 'exec'), mod.__dict__)
assert Path(sys.argv[3]).resolve() != (CC / 'runs' / 'full').resolve(), 'refusing to overwrite the stored record'
sys.argv = [str(CC / 'run.py')] + sys.argv[1:]
runpy.run_path(str(CC / 'run.py'), run_name='__main__')
